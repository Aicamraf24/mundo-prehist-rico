package com.prehistoric.client;

import java.util.HashMap;
import java.util.Map;

import com.prehistoric.ModRegistry;
import com.prehistoric.Species;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public class PrehistoricClient implements ClientModInitializer {
	public static final Map<String, DinoSpec> SPECS = new HashMap<>();

	public static ModelLayerLocation layer(Species s) {
		return new ModelLayerLocation(ModRegistry.id("dino_" + s.id()), "main");
	}

	@Override
	public void onInitializeClient() {
		for (Species s : Species.ALL) {
			DinoSpec spec = DinoSpec.load(s.id());
			SPECS.put(s.id(), spec);
			ModelLayerRegistry.registerModelLayer(layer(s), () -> DinoModel.createLayer(spec));
			EntityRendererRegistry.register(ModRegistry.ENTITIES.get(s.id()), ctx -> new DinoRenderer(ctx, s, spec));
		}
	}

	public static Identifier texture(Species s) {
		return ModRegistry.id("textures/entity/" + s.id() + ".png");
	}
}
