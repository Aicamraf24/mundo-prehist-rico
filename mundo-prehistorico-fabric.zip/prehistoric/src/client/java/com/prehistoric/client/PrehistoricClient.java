package com.prehistoric.client;

import com.prehistoric.ModRegistry;
import com.prehistoric.Plan;
import com.prehistoric.Species;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.resources.Identifier;

public class PrehistoricClient implements ClientModInitializer {
	public static ModelLayerLocation layer(Plan plan) {
		return new ModelLayerLocation(ModRegistry.id("dino_" + plan.name().toLowerCase()), "main");
	}

	@Override
	public void onInitializeClient() {
		for (Plan plan : Plan.values()) {
			ModelLayerRegistry.registerModelLayer(layer(plan), () -> DinoModel.createLayer(plan));
		}
		for (Species s : Species.ALL) {
			EntityRendererRegistry.register(ModRegistry.ENTITIES.get(s.id()), ctx -> new DinoRenderer(ctx, s));
		}
	}

	public static Identifier texture(Species s) {
		return ModRegistry.id("textures/entity/" + s.id() + ".png");
	}
}
