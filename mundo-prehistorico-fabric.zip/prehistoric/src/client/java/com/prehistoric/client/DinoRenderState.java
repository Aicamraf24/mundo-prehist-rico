package com.prehistoric.client;

import com.prehistoric.Plan;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class DinoRenderState extends LivingEntityRenderState {
	public Plan plan = Plan.THEROPOD;
	public boolean small;
	public boolean sitting;
	public boolean saddled;
	public boolean breeding;
	public boolean inAir;
	public boolean horns;
	public boolean crest;
}
