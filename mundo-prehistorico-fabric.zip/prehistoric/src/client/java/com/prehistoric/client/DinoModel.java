package com.prehistoric.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Modelo generico dirigido por datos: cada especie define sus partes (DinoSpec).
 * Convencion de nombres: body, neck1..3, head (craneo), snout (hocico), jaw (mandibula), tail1..4, saddle,
 * leg_bl/br (+2 +3: muslo, pierna, pie) y leg_fl/fr para brazos/patas delanteras, wing_l/r (+2).
 */
public class DinoModel extends EntityModel<DinoRenderState> {
	private static final ModelPart DUMMY = new ModelPart(List.of(), Map.of());
	private final Map<String, ModelPart> parts = new HashMap<>();
	private final List<ModelPart> rootParts = new ArrayList<>();
	private final DinoSpec spec;

	public DinoModel(ModelPart root, DinoSpec spec) {
		super(root);
		this.spec = spec;
		for (DinoSpec.Part p : spec.parts) {
			ModelPart parent = p.parent == null ? root : parts.get(p.parent);
			ModelPart mp = parent.getChild(p.name);
			parts.put(p.name, mp);
			if (p.parent == null) rootParts.add(mp);
		}
	}

	public static LayerDefinition createLayer(DinoSpec spec) {
		MeshDefinition mesh = new MeshDefinition();
		Map<String, PartDefinition> defs = new HashMap<>();
		for (DinoSpec.Part p : spec.parts) {
			PartDefinition parent = p.parent == null ? mesh.getRoot() : defs.get(p.parent);
			CubeListBuilder cube = CubeListBuilder.create().texOffs(p.u, p.v)
					.addBox(p.box[0], p.box[1], p.box[2], p.box[3], p.box[4], p.box[5], CubeDeformation.NONE);
			defs.put(p.name, parent.addOrReplaceChild(p.name, cube,
					PartPose.offsetAndRotation(p.pivot[0], p.pivot[1], p.pivot[2], p.rot[0], p.rot[1], p.rot[2])));
		}
		return LayerDefinition.create(mesh, spec.texW, spec.texH);
	}

	private ModelPart g(String name) {
		return parts.getOrDefault(name, DUMMY);
	}

	@Override
	public void setupAnim(DinoRenderState s) {
		super.setupAnim(s);
		root().getAllParts().forEach(ModelPart::resetPose);

		float pos = s.walkAnimationPos;
		float spd = Math.min(1f, s.walkAnimationSpeed * 2f);
		float t = s.ageInTicks;

		g("saddle").visible = s.saddled;

		// Mirada
		ModelPart head = g("head");
		head.yRot += Mth.clamp(s.yRot, -40f, 40f) * Mth.DEG_TO_RAD * 0.7f;
		head.xRot += Mth.clamp(s.xRot, -30f, 30f) * Mth.DEG_TO_RAD * 0.7f;

		// Mandibula: abierta al atacar, respiracion suave en reposo
		g("jaw").xRot += s.aggressive ? 0.45f + Mth.sin(t * 0.6f) * 0.12f : 0.03f + Mth.sin(t * 0.08f) * 0.02f;

		// Cuello y cola (cadenas): oleaje suave
		g("neck1").yRot += Mth.sin(pos * 0.3f) * 0.06f * spd;
		g("neck2").xRot += Mth.sin(t * 0.04f) * 0.03f;
		float idle = Mth.sin(t * 0.05f) * 0.05f;
		float wag = Mth.sin(pos * 0.3f) * spd;
		g("tail1").yRot += wag * 0.2f + idle;
		g("tail2").yRot += Mth.sin(pos * 0.3f - 0.6f) * 0.25f * spd + idle;
		g("tail3").yRot += Mth.sin(pos * 0.3f - 1.2f) * 0.3f * spd + idle;
		g("tail4").yRot += Mth.sin(pos * 0.3f - 1.8f) * 0.3f * spd + idle;

		switch (s.plan) {
			case FLYER -> {
				if (s.inAir && !s.sitting) {
					float flap = Mth.sin(t * 0.7f) * 0.8f;
					g("wing_l").zRot += flap;
					g("wing_r").zRot -= flap;
					g("wing_l2").zRot += flap * 0.5f;
					g("wing_r2").zRot -= flap * 0.5f;
					g("leg_bl").xRot += 0.7f;
					g("leg_br").xRot += 0.7f;
				} else if (!s.sitting) {
					g("wing_l").zRot -= 1.0f;
					g("wing_r").zRot += 1.0f;
					walkLegs(pos, spd, true);
				}
			}
			case AQUATIC -> {
				float sway = Mth.sin(t * 0.15f);
				g("tail1").yRot += sway * 0.2f;
				g("tail2").yRot += sway * 0.3f;
				g("tail3").yRot += sway * 0.4f;
				float paddle = Mth.sin(t * 0.2f) * 0.4f;
				g("leg_fl").zRot += paddle; g("leg_bl").zRot += paddle;
				g("leg_fr").zRot -= paddle; g("leg_br").zRot -= paddle;
			}
			default -> walkLegs(pos, spd, s.plan == com.prehistoric.Plan.THEROPOD);
		}

		if (s.breeding) {
			float bob = Mth.sin(t * 0.6f);
			head.xRot += bob * 0.3f;
			g("neck1").xRot += 0.12f;
		}
		if (s.sitting) sitPose(s);
	}

	private void walkLegs(float pos, float spd, boolean biped) {
		float p = pos * 0.6662f;
		leg("leg_bl", p, 0.9f, spd);
		leg("leg_br", p + Mth.PI, 0.9f, spd);
		float armAmp = biped ? 0.25f : 0.8f;
		leg("leg_fl", p + Mth.PI, armAmp, spd);
		leg("leg_fr", p, armAmp, spd);
	}

	/** Balancea el muslo, flexiona la pierna al levantarla y mantiene el pie plano. */
	private void leg(String name, float phase, float amp, float spd) {
		float sw = Mth.cos(phase) * spd;
		float dUp = sw * amp;
		float dLo = Math.max(0f, -sw) * amp * 0.9f;
		g(name).xRot += dUp;
		g(name + "2").xRot += dLo;
		g(name + "3").xRot += -(dUp + dLo);
	}

	/** Animacion de sentarse por familia: los pequenos se acurrucan, los grandes pliegan las patas y bajan el cuerpo. */
	private void sitPose(DinoRenderState s) {
		switch (s.plan) {
			case THEROPOD -> {
				drop(spec.sitDrop);
				fold("leg_bl", -0.9f, 1.7f); fold("leg_br", -0.9f, 1.7f);
				if (s.small) {
					g("tail1").yRot += 0.9f; g("tail2").yRot += 0.6f; g("tail3").yRot += 0.4f;
					g("neck1").xRot += 0.4f; g("head").xRot += 0.3f;
				} else {
					g("tail1").xRot += 0.08f;
				}
			}
			case QUADRUPED, SAUROPOD -> {
				drop(spec.sitDrop);
				fold("leg_fl", -1.0f, 1.8f); fold("leg_fr", -1.0f, 1.8f);
				fold("leg_bl", -1.1f, 1.9f); fold("leg_br", -1.1f, 1.9f);
				g("neck1").xRot += s.plan == com.prehistoric.Plan.SAUROPOD ? 0.3f : 0.2f;
				g("head").xRot += 0.25f;
			}
			case FLYER -> {
				drop(1.0f);
				g("wing_l").zRot -= 1.3f; g("wing_r").zRot += 1.3f;
				g("wing_l2").zRot -= 0.8f; g("wing_r2").zRot += 0.8f;
				g("neck1").xRot += 0.4f; g("head").xRot += 0.5f;
			}
			case AQUATIC -> {
				drop(2.0f);
				float f = 0.9f;
				g("leg_fl").zRot += f; g("leg_bl").zRot += f;
				g("leg_fr").zRot -= f; g("leg_br").zRot -= f;
				g("head").xRot += 0.2f;
			}
		}
	}

	private void fold(String name, float up, float low) {
		g(name).xRot += up;
		g(name + "2").xRot += low;
		g(name + "3").xRot += -(up + low);
	}

	private void drop(float dy) {
		for (ModelPart p : rootParts) p.y += dy;
	}
}
