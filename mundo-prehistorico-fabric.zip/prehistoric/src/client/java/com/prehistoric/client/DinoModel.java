package com.prehistoric.client;

import com.prehistoric.Plan;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Modelo procedural por plan corporal. UV compartido por los 5 planes (atlas 128x128):
 *  body(0,0) neck(64,0) head(88,0) tail1(0,32) tail2(40,32) leg(76,32) wing(0,52) crest(52,52) horns(84,52) saddle(0,72)
 * La silla de montar es parte del modelo (hija del cuerpo) y solo se ve cuando la entidad la lleva puesta.
 */
public class DinoModel extends EntityModel<DinoRenderState> {
	private final ModelPart body, neck, head, tail1, tail2, saddle, crest, horns;
	private final ModelPart legFL, legFR, legBL, legBR, wingL, wingR;

	public DinoModel(ModelPart root) {
		super(root);
		body = root.getChild("body");
		neck = root.getChild("neck");
		head = neck.getChild("head");
		tail1 = root.getChild("tail1");
		tail2 = tail1.getChild("tail2");
		saddle = body.getChild("saddle");
		crest = body.getChild("crest");
		horns = head.getChild("horns");
		legFL = root.getChild("leg_fl");
		legFR = root.getChild("leg_fr");
		legBL = root.getChild("leg_bl");
		legBR = root.getChild("leg_br");
		wingL = root.getChild("wing_l");
		wingR = root.getChild("wing_r");
	}

	private static CubeListBuilder box(int u, int v, float x, float y, float z, int w, int h, int d) {
		return CubeListBuilder.create().texOffs(u, v).addBox(x, y, z, w, h, d, CubeDeformation.NONE);
	}

	private static final CubeListBuilder NONE = CubeListBuilder.create();

	public static LayerDefinition createLayer(Plan plan) {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition r = mesh.getRoot();
		CubeListBuilder saddleBox;
		PartDefinition b, n, t1;

		switch (plan) {
			case THEROPOD -> {
				b = r.addOrReplaceChild("body", box(0, 0, -5, -5, -8, 10, 10, 16), PartPose.offset(0, 10, 0));
				saddleBox = box(0, 72, -5, -8, -6, 10, 3, 12);
				n = r.addOrReplaceChild("neck", box(64, 0, -3, -7, -3, 6, 7, 6), PartPose.offsetAndRotation(0, 6, -7, -0.25f, 0, 0));
				n.addOrReplaceChild("head", box(88, 0, -4, -4, -9, 8, 8, 10), PartPose.offset(0, -7, 0));
				t1 = r.addOrReplaceChild("tail1", box(0, 32, -3.5f, -3, 0, 7, 6, 10), PartPose.offset(0, 8, 8));
				t1.addOrReplaceChild("tail2", box(40, 32, -2.5f, -2.5f, 0, 5, 5, 10), PartPose.offset(0, 0, 10));
				r.addOrReplaceChild("leg_bl", box(76, 32, -2, 0, -2, 4, 11, 4), PartPose.offset(-3.5f, 13, 3));
				r.addOrReplaceChild("leg_br", box(76, 32, -2, 0, -2, 4, 11, 4), PartPose.offset(3.5f, 13, 3));
				r.addOrReplaceChild("leg_fl", box(76, 32, -1, 0, -1, 2, 5, 2), PartPose.offset(-4, 12, -6));
				r.addOrReplaceChild("leg_fr", box(76, 32, -1, 0, -1, 2, 5, 2), PartPose.offset(4, 12, -6));
			}
			case QUADRUPED -> {
				b = r.addOrReplaceChild("body", box(0, 0, -6, -5, -10, 12, 10, 20), PartPose.offset(0, 13, 0));
				saddleBox = box(0, 72, -5, -8, -6, 10, 3, 12);
				n = r.addOrReplaceChild("neck", box(64, 0, -3, -3, -3, 6, 6, 5), PartPose.offset(0, 12, -9));
				n.addOrReplaceChild("head", box(88, 0, -4, -4, -9, 8, 8, 10), PartPose.offset(0, 0, -2));
				t1 = r.addOrReplaceChild("tail1", box(0, 32, -3, -2.5f, 0, 6, 5, 8), PartPose.offset(0, 11, 10));
				t1.addOrReplaceChild("tail2", box(40, 32, -2, -2, 0, 4, 4, 8), PartPose.offset(0, 0, 8));
				r.addOrReplaceChild("leg_bl", box(76, 32, -2, 0, -2, 4, 8, 4), PartPose.offset(-4.5f, 16, 6));
				r.addOrReplaceChild("leg_br", box(76, 32, -2, 0, -2, 4, 8, 4), PartPose.offset(4.5f, 16, 6));
				r.addOrReplaceChild("leg_fl", box(76, 32, -2, 0, -2, 4, 8, 4), PartPose.offset(-4.5f, 16, -6));
				r.addOrReplaceChild("leg_fr", box(76, 32, -2, 0, -2, 4, 8, 4), PartPose.offset(4.5f, 16, -6));
			}
			case SAUROPOD -> {
				b = r.addOrReplaceChild("body", box(0, 0, -8, -6, -12, 16, 12, 24), PartDefinitionHelper.at(0, -10, 0));
				saddleBox = box(0, 72, -5, -9, -6, 10, 3, 12);
				n = r.addOrReplaceChild("neck", box(64, 0, -3, -26, -3, 6, 26, 6), PartPose.offsetAndRotation(0, -14, -11, 0.25f, 0, 0));
				n.addOrReplaceChild("head", box(88, 0, -2.5f, -3, -6, 5, 5, 8), PartPose.offset(0, -26, 0));
				t1 = r.addOrReplaceChild("tail1", box(0, 32, -4, -3, 0, 8, 6, 14), PartPose.offset(0, -12, 12));
				t1.addOrReplaceChild("tail2", box(40, 32, -3, -2.5f, 0, 6, 5, 14), PartPose.offset(0, 0, 14));
				r.addOrReplaceChild("leg_bl", box(76, 32, -2.5f, 0, -2.5f, 5, 28, 5), PartPose.offset(-6, -4, 8));
				r.addOrReplaceChild("leg_br", box(76, 32, -2.5f, 0, -2.5f, 5, 28, 5), PartPose.offset(6, -4, 8));
				r.addOrReplaceChild("leg_fl", box(76, 32, -2.5f, 0, -2.5f, 5, 28, 5), PartPose.offset(-6, -4, -8));
				r.addOrReplaceChild("leg_fr", box(76, 32, -2.5f, 0, -2.5f, 5, 28, 5), PartPose.offset(6, -4, -8));
			}
			case FLYER -> {
				b = r.addOrReplaceChild("body", box(0, 0, -3, -3, -6, 6, 6, 12), PartPose.offset(0, 14, 0));
				saddleBox = box(0, 72, -4, -5, -4, 8, 2, 8);
				n = r.addOrReplaceChild("neck", box(64, 0, -1.5f, -1.5f, -4, 3, 3, 4), PartPose.offset(0, 12, -6));
				n.addOrReplaceChild("head", box(88, 0, -2.5f, -2.5f, -8, 5, 5, 8), PartPose.offset(0, 0, -3));
				t1 = r.addOrReplaceChild("tail1", box(0, 32, -1.5f, -1.5f, 0, 3, 3, 8), PartPose.offset(0, 14, 6));
				t1.addOrReplaceChild("tail2", NONE, PartPose.ZERO);
				r.addOrReplaceChild("leg_bl", box(76, 32, -1, 0, -1, 2, 6, 2), PartPose.offset(-2, 17, 2));
				r.addOrReplaceChild("leg_br", box(76, 32, -1, 0, -1, 2, 6, 2), PartPose.offset(2, 17, 2));
				r.addOrReplaceChild("leg_fl", NONE, PartPose.ZERO);
				r.addOrReplaceChild("leg_fr", NONE, PartPose.ZERO);
			}
			default -> { // AQUATIC
				b = r.addOrReplaceChild("body", box(0, 0, -5, -5, -12, 10, 10, 24), PartPose.offset(0, 16, 0));
				saddleBox = box(0, 72, -5, -8, -6, 10, 3, 12);
				n = r.addOrReplaceChild("neck", NONE, PartPose.offset(0, 16, -12));
				n.addOrReplaceChild("head", box(88, 0, -4, -4, -12, 8, 8, 12), PartPose.ZERO);
				t1 = r.addOrReplaceChild("tail1", box(0, 32, -4, -3.5f, 0, 8, 7, 14), PartPose.offset(0, 16, 12));
				t1.addOrReplaceChild("tail2", box(40, 32, -2.5f, -3, 0, 5, 6, 12), PartPose.offset(0, 0, 14));
				r.addOrReplaceChild("leg_bl", box(76, 32, -8, 0, -2, 8, 1, 5), PartPose.offset(-5, 19, 7));
				r.addOrReplaceChild("leg_br", box(76, 32, 0, 0, -2, 8, 1, 5), PartPose.offset(5, 19, 7));
				r.addOrReplaceChild("leg_fl", box(76, 32, -8, 0, -2, 8, 1, 5), PartPose.offset(-5, 19, -5));
				r.addOrReplaceChild("leg_fr", box(76, 32, 0, 0, -2, 8, 1, 5), PartPose.offset(5, 19, -5));
			}
		}
		if (plan != Plan.FLYER) {
			r.addOrReplaceChild("wing_l", NONE, PartPose.ZERO);
			r.addOrReplaceChild("wing_r", NONE, PartPose.ZERO);
		} else {
			r.addOrReplaceChild("wing_l", box(0, 52, -16, 0, -5, 16, 1, 10), PartPose.offset(-3, 12, -1));
			r.addOrReplaceChild("wing_r", box(0, 52, 0, 0, -5, 16, 1, 10), PartPose.offset(3, 12, -1));
		}
		// Silla, cresta y cuernos: siempre existen; la visibilidad se decide en setupAnim
		b.addOrReplaceChild("saddle", saddleBox, PartPose.ZERO);
		b.addOrReplaceChild("crest", box(52, 52, -1, -9, -6, 2, 5, 14), PartPose.ZERO);
		PartDefinition headDef = r.getChild("neck").getChild("head");
		headDef.addOrReplaceChild("horns", box(84, 52, -5, -7, -6, 10, 2, 4), PartPose.ZERO);
		return LayerDefinition.create(mesh, 128, 128);
	}

	private static final class PartDefinitionHelper {
		static PartPose at(float x, float y, float z) { return PartPose.offset(x, y, z); }
	}

	@Override
	public void setupAnim(DinoRenderState s) {
		super.setupAnim(s);
		root().getAllParts().forEach(ModelPart::resetPose);

		float pos = s.walkAnimationPos;
		float spd = Math.min(1f, s.walkAnimationSpeed * 2f);
		float t = s.ageInTicks;

		saddle.visible = s.saddled;
		crest.visible = s.crest;
		horns.visible = s.horns;

		// Mirada
		float yaw = Mth.clamp(s.yRot, -40f, 40f) * Mth.DEG_TO_RAD;
		float pitch = Mth.clamp(s.xRot, -30f, 30f) * Mth.DEG_TO_RAD;
		head.yRot = yaw;
		head.xRot = pitch;

		// Caminar / nadar / volar
		float swing = Mth.cos(pos * 0.6662f) * 1.1f * spd;
		legBL.xRot = swing;
		legBR.xRot = -swing;
		legFL.xRot = -swing;
		legFR.xRot = swing;
		tail1.yRot = Mth.sin(pos * 0.3f) * 0.25f * spd + Mth.sin(t * 0.05f) * 0.05f;
		tail2.yRot = tail1.yRot * 0.8f;

		switch (s.plan) {
			case FLYER -> {
				if (s.inAir && !s.sitting) {
					float flap = Mth.sin(t * 0.8f) * 0.9f;
					wingL.zRot = -flap;
					wingR.zRot = flap;
					legBL.xRot = legBR.xRot = 0.8f;
				}
			}
			case AQUATIC -> {
				float sway = Mth.sin(t * 0.15f);
				tail1.yRot = sway * 0.35f;
				tail2.yRot = sway * 0.45f;
				legFL.zRot = legBL.zRot = Mth.sin(t * 0.2f) * 0.4f;
				legFR.zRot = legBR.zRot = -Mth.sin(t * 0.2f) * 0.4f;
				legFL.xRot = legFR.xRot = legBL.xRot = legBR.xRot = 0f;
			}
			default -> {}
		}

		if (s.breeding) {
			float bob = Mth.sin(t * 0.6f);
			head.xRot += bob * 0.35f;
			body.y += bob * 0.8f;
			neck.xRot += 0.15f;
		}

		if (s.sitting) {
			sitPose(s);
		}
	}

	/** Animacion de sentarse por plan corporal; las especies pequenas se acurrucan, las grandes doblan las patas. */
	private void sitPose(DinoRenderState s) {
		switch (s.plan) {
			case THEROPOD -> {
				if (s.small) {
					lower(6f);
					legBL.xRot = legBR.xRot = -1.3f;
					legBL.y += 5f; legBR.y += 5f;
					tail1.yRot = 0.9f; tail2.yRot = 0.9f;
					neck.xRot = 0.5f; head.xRot = 0.4f;
				} else {
					lower(8f);
					legBL.xRot = legBR.xRot = -1.45f;
					legBL.y += 8f; legBR.y += 8f;
					legFL.xRot = legFR.xRot = -0.6f;
					tail1.xRot = 0.2f;
					neck.xRot = -0.1f;
				}
			}
			case QUADRUPED -> {
				lower(5f);
				legBL.y += 6f; legBR.y += 6f; legFL.y += 6f; legFR.y += 6f;
				legBL.xRot = legBR.xRot = 1.3f;
				legFL.xRot = legFR.xRot = -1.3f;
				neck.y += 5f;
				head.xRot = 0.35f;
			}
			case SAUROPOD -> {
				lower(14f);
				legBL.y += 14f; legBR.y += 14f; legFL.y += 14f; legFR.y += 14f;
				legBL.xRot = legBR.xRot = 1.5f;
				legFL.xRot = legFR.xRot = -1.5f;
				neck.xRot = 0.9f;
			}
			case FLYER -> {
				lower(2f);
				wingL.zRot = -1.35f;
				wingR.zRot = 1.35f;
				head.xRot = 0.6f;
				neck.xRot = 0.4f;
				legBL.xRot = legBR.xRot = 0f;
			}
			case AQUATIC -> {
				float bob = Mth.sin(body.xRot + 1f) ; // reposo flotando
				lower(2f);
				legFL.zRot = legBL.zRot = 1.0f;
				legFR.zRot = legBR.zRot = -1.0f;
				head.xRot = 0.25f + bob * 0.02f;
			}
		}
	}

	private void lower(float dy) {
		body.y += dy;
		neck.y += dy;
		tail1.y += dy;
		wingL.y += dy;
		wingR.y += dy;
	}
}
