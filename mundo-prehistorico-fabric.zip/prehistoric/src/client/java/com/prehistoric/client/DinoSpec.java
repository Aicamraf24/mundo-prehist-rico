package com.prehistoric.client;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/** Anatomia de una especie, leida de data/prehistoric/models/<id>.json (la genera tools/build_models.py). */
public final class DinoSpec {
	public static final class Part {
		public String name, parent, kind;
		public int u, v;
		public float[] box = new float[6];
		public float[] pivot = new float[3];
		public float[] rot = new float[3];
	}

	public int texW, texH;
	public float heightPx, sitDrop;
	public final List<Part> parts = new ArrayList<>();

	public static DinoSpec load(String id) {
		try (var in = DinoSpec.class.getResourceAsStream("/data/prehistoric/models/" + id + ".json");
				var r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
			JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
			DinoSpec s = new DinoSpec();
			s.texW = o.get("tw").getAsInt();
			s.texH = o.get("th").getAsInt();
			s.heightPx = o.get("height_px").getAsFloat();
			s.sitDrop = o.get("sit_drop").getAsFloat();
			for (JsonElement e : o.getAsJsonArray("parts")) {
				JsonObject po = e.getAsJsonObject();
				Part p = new Part();
				p.name = po.get("name").getAsString();
				p.parent = po.get("parent").isJsonNull() ? null : po.get("parent").getAsString();
				p.kind = po.get("kind").getAsString();
				p.u = po.get("u").getAsInt();
				p.v = po.get("v").getAsInt();
				fill(po.getAsJsonArray("box"), p.box);
				fill(po.getAsJsonArray("pivot"), p.pivot);
				fill(po.getAsJsonArray("rot"), p.rot);
				s.parts.add(p);
			}
			return s;
		} catch (Exception ex) {
			throw new RuntimeException("Modelo no valido: " + id, ex);
		}
	}

	private static void fill(JsonArray a, float[] out) {
		for (int i = 0; i < out.length; i++) out[i] = a.get(i).getAsFloat();
	}
}
