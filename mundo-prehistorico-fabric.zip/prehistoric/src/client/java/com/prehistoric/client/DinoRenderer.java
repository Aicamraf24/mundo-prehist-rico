package com.prehistoric.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.prehistoric.Species;
import com.prehistoric.entity.DinoEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

/**
 * Un unico renderer para las 30 especies. El modelo depende del plan corporal, la escala de la altura
 * de la especie y la textura de la especie (que incluye la zona de la silla de montar).
 */
public class DinoRenderer extends MobRenderer<DinoEntity, DinoRenderState, DinoModel> {
	private final Species species;
	private final Identifier texture;

	public DinoRenderer(EntityRendererProvider.Context ctx, Species species) {
		super(ctx, new DinoModel(ctx.bakeLayer(PrehistoricClient.layer(species.plan()))),
				Math.max(0.4f, species.width() * 0.45f));
		this.species = species;
		this.texture = PrehistoricClient.texture(species);
	}

	@Override
	public DinoRenderState createRenderState() {
		return new DinoRenderState();
	}

	@Override
	public void extractRenderState(DinoEntity entity, DinoRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.plan = species.plan();
		state.small = species.small();
		state.sitting = entity.isInSittingPose();
		state.saddled = entity.isSaddled();
		state.breeding = entity.isBreedingAnim();
		state.inAir = !entity.onGround() && !entity.isInWater();
		state.horns = species.horns();
		state.crest = species.crest();
	}

	/** Escala el modelo base del plan hasta la altura real de la especie. */
	@Override
	protected void scale(DinoRenderState state, PoseStack pose) {
		super.scale(state, pose);
		float k = species.height() / species.plan().baseHeight;
		pose.scale(k, k, k);
	}

	@Override
	public Identifier getTextureLocation(DinoRenderState state) {
		return texture;
	}
}
