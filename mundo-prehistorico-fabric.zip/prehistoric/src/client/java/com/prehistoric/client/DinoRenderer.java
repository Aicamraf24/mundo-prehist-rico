package com.prehistoric.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.prehistoric.Species;
import com.prehistoric.entity.DinoEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

/** Un renderer para las 30 especies: cada una con su propia anatomia (DinoSpec) y su textura. */
public class DinoRenderer extends MobRenderer<DinoEntity, DinoRenderState, DinoModel> {
	private final Species species;
	private final DinoSpec spec;
	private final Identifier[] textures = new Identifier[DinoEntity.VARIANTS];

	public DinoRenderer(EntityRendererProvider.Context ctx, Species species, DinoSpec spec) {
		super(ctx, new DinoModel(ctx.bakeLayer(PrehistoricClient.layer(species)), spec), Math.max(0.4f, species.width() * 0.45f));
		this.species = species;
		this.spec = spec;
		for (int i = 0; i < textures.length; i++) textures[i] = PrehistoricClient.texture(species, i);
	}

	@Override
	public DinoRenderState createRenderState() {
		return new DinoRenderState();
	}

	@Override
	public void extractRenderState(DinoEntity entity, DinoRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.plan = species.plan();
		state.small = species.small();
		state.sitting = entity.isInSittingPose();
		state.saddled = entity.isSaddled();
		state.breeding = entity.isBreedingAnim();
		state.inAir = !entity.onGround() && !entity.isInWater();
		state.aggressive = entity.isAggressive();
		state.variant = entity.getVariant();
	}

	/** Escala el modelo para que su altura coincida con la altura (hitbox) de la especie. */
	@Override
	protected void scale(DinoRenderState state, PoseStack pose) {
		super.scale(state, pose);
		float k = species.height() / (spec.heightPx / 16f);
		pose.scale(k, k, k);
	}

	@Override
	public Identifier getTextureLocation(DinoRenderState state) {
		return textures[Math.min(state.variant, textures.length - 1)];
	}
}
