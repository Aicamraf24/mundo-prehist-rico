package com.prehistoric;

/** Plan corporal: decide el modelo, la animacion de sentarse y el asiento. */
public enum Plan {
	THEROPOD(1.8f, 0.66f),
	QUADRUPED(1.0f, 0.97f),
	SAUROPOD(4.2f, 0.60f),
	FLYER(1.0f, 0.70f),
	AQUATIC(0.9f, 0.90f);

	/** Altura (en bloques) del modelo base sin escalar. */
	public final float baseHeight;
	/** Fraccion de la altura de la entidad donde se sienta el jugador. */
	public final float seatFraction;

	Plan(float baseHeight, float seatFraction) {
		this.baseHeight = baseHeight;
		this.seatFraction = seatFraction;
	}
}
