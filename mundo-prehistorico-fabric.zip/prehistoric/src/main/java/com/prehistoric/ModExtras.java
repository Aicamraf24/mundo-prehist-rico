package com.prehistoric;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import com.prehistoric.item.JurassicAmberItem;
import com.prehistoric.world.VolcanicGroundFeature;
import com.prehistoric.world.VolcanoFeature;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Escamas, armadura de escamas, Ambar Jurasico (acceso a la dimension) y el volcan. */
public final class ModExtras {
	public static final ResourceKey<Level> JURASSIC = ResourceKey.create(Registries.DIMENSION, ModRegistry.id("jurassic"));
	public static final List<Item> ITEMS = new ArrayList<>();

	public static Item DINO_SCALE, SCALE_HELMET, SCALE_CHESTPLATE, SCALE_LEGGINGS, SCALE_BOOTS, JURASSIC_AMBER;

	private static final ResourceKey<EquipmentAsset> SCALE_ASSET = ResourceKey.create(EquipmentAssets.ROOT_ID, ModRegistry.id("scale"));
	private static final ArmorMaterial SCALE_MATERIAL = new ArmorMaterial(
			18,
			Map.of(ArmorType.BOOTS, 2, ArmorType.LEGGINGS, 5, ArmorType.CHESTPLATE, 6, ArmorType.HELMET, 2, ArmorType.BODY, 5),
			12,
			SoundEvents.ARMOR_EQUIP_LEATHER,
			0.5f,
			0.0f,
			TagKey.create(Registries.ITEM, ModRegistry.id("repairs_scale_armor")),
			SCALE_ASSET);

	// ---- Roca madre: 1.5x netherita (durabilidad, proteccion, dano, velocidad de mineria)
	public static Block MOTHER_ROCK_ORE;
	public static Item MOTHER_FRAGMENT, MOTHER_INGOT;
	public static Item MR_HELMET, MR_CHESTPLATE, MR_LEGGINGS, MR_BOOTS, MR_SWORD, MR_PICKAXE, MR_AXE, MR_SHOVEL, MR_HOE;

	private static final TagKey<Item> REPAIRS_MOTHER = TagKey.create(Registries.ITEM, ModRegistry.id("repairs_mother_rock"));
	private static final ArmorMaterial MOTHER_ARMOR = new ArmorMaterial(
			56, // netherita = 37 -> x1.5 = 55.5
			Map.of(ArmorType.BOOTS, 5, ArmorType.LEGGINGS, 9, ArmorType.CHESTPLATE, 12, ArmorType.HELMET, 5, ArmorType.BODY, 28),
			15,
			SoundEvents.ARMOR_EQUIP_NETHERITE,
			4.5f,   // dureza: netherita 3.0 x1.5
			0.15f,  // resistencia al empuje: netherita 0.1 x1.5
			REPAIRS_MOTHER,
			ResourceKey.create(EquipmentAssets.ROOT_ID, ModRegistry.id("mother_rock")));
	private static final ToolMaterial MOTHER_TOOL = new ToolMaterial(
			BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
			3046,   // netherita = 2031 -> x1.5
			13.5f,  // velocidad: netherita 9.0 x1.5
			6.0f,   // bono de dano: netherita 4.0 x1.5
			15,
			REPAIRS_MOTHER);

	private static Item item(String name, Function<Item.Properties, Item.Properties> props, Function<Item.Properties, Item> factory) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ModRegistry.id(name));
		Item item = Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.apply(new Item.Properties()).setId(key)));
		ITEMS.add(item);
		return item;
	}

	public static void register() {
		DINO_SCALE = item("dino_scale", p -> p, Item::new);
		SCALE_HELMET = item("scale_helmet", p -> p.humanoidArmor(SCALE_MATERIAL, ArmorType.HELMET), Item::new);
		SCALE_CHESTPLATE = item("scale_chestplate", p -> p.humanoidArmor(SCALE_MATERIAL, ArmorType.CHESTPLATE), Item::new);
		SCALE_LEGGINGS = item("scale_leggings", p -> p.humanoidArmor(SCALE_MATERIAL, ArmorType.LEGGINGS), Item::new);
		SCALE_BOOTS = item("scale_boots", p -> p.humanoidArmor(SCALE_MATERIAL, ArmorType.BOOTS), Item::new);
		JURASSIC_AMBER = item("jurassic_amber", p -> p.stacksTo(1).rarity(Rarity.RARE), JurassicAmberItem::new);

		// Mena de roca madre (tan rara como el diamante en la dimension: ver ore_mother_rock.json)
		ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK, ModRegistry.id("mother_rock_ore"));
		MOTHER_ROCK_ORE = Registry.register(BuiltInRegistries.BLOCK, bk, new Block(BlockBehaviour.Properties.of().setId(bk)
				.strength(6.0f, 6.0f).requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE).lightLevel(s -> 3)));
		ResourceKey<Item> bik = ResourceKey.create(Registries.ITEM, ModRegistry.id("mother_rock_ore"));
		ITEMS.add(Registry.register(BuiltInRegistries.ITEM, bik, new BlockItem(MOTHER_ROCK_ORE,
				new Item.Properties().setId(bik).useBlockDescriptionPrefix())));

		MOTHER_FRAGMENT = item("mother_rock_fragment", p -> p, Item::new);
		MOTHER_INGOT = item("mother_rock_ingot", p -> p.fireResistant(), Item::new);
		MR_HELMET = item("mother_rock_helmet", p -> p.humanoidArmor(MOTHER_ARMOR, ArmorType.HELMET).fireResistant(), Item::new);
		MR_CHESTPLATE = item("mother_rock_chestplate", p -> p.humanoidArmor(MOTHER_ARMOR, ArmorType.CHESTPLATE).fireResistant(), Item::new);
		MR_LEGGINGS = item("mother_rock_leggings", p -> p.humanoidArmor(MOTHER_ARMOR, ArmorType.LEGGINGS).fireResistant(), Item::new);
		MR_BOOTS = item("mother_rock_boots", p -> p.humanoidArmor(MOTHER_ARMOR, ArmorType.BOOTS).fireResistant(), Item::new);
		MR_SWORD = item("mother_rock_sword", p -> p.sword(MOTHER_TOOL, 3.0f, -2.4f).fireResistant(), Item::new);
		MR_PICKAXE = item("mother_rock_pickaxe", p -> p.pickaxe(MOTHER_TOOL, 1.0f, -2.8f).fireResistant(), Item::new);
		MR_AXE = item("mother_rock_axe", p -> p.fireResistant(), p -> new AxeItem(MOTHER_TOOL, 5.0f, -3.0f, p));
		MR_SHOVEL = item("mother_rock_shovel", p -> p.fireResistant(), p -> new ShovelItem(MOTHER_TOOL, 1.5f, -3.0f, p));
		MR_HOE = item("mother_rock_hoe", p -> p.fireResistant(), p -> new HoeItem(MOTHER_TOOL, -4.0f, 0.0f, p));

		Registry.register(BuiltInRegistries.FEATURE, ModRegistry.id("volcano"), new VolcanoFeature(NoneFeatureConfiguration.CODEC));
		Registry.register(BuiltInRegistries.FEATURE, ModRegistry.id("volcanic_ground"), new VolcanicGroundFeature(NoneFeatureConfiguration.CODEC));
	}

	private ModExtras() {}
}
