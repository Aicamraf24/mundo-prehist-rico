package com.prehistoric;

import java.util.HashMap;
import java.util.Map;

import com.prehistoric.block.DinoEggBlock;
import com.prehistoric.block.DinoEggBlockEntity;
import com.prehistoric.entity.DinoEntity;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModRegistry {
	public static final Map<String, EntityType<DinoEntity>> ENTITIES = new HashMap<>();
	public static final Map<String, DinoEggBlock> EGG_BLOCKS = new HashMap<>();
	public static final Map<String, Item> EGG_ITEMS = new HashMap<>();
	public static BlockEntityType<DinoEggBlockEntity> EGG_BE;
	public static final Map<String, Item> SPAWN_EGGS = new HashMap<>();
	public static Item DINO_MEAT;
	public static Item COOKED_DINO_MEAT;

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(PrehistoricMod.MOD_ID, path);
	}

	public static void registerAll() {
		// Carne de dinosaurio (cruda y cocinada)
		DINO_MEAT = registerItem("dino_meat", new Item.Properties()
				.food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.2f).build()));
		COOKED_DINO_MEAT = registerItem("cooked_dino_meat", new Item.Properties()
				.food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build()));

		// Un tipo de entidad, un bloque-huevo y un item-huevo por especie
		for (Species s : Species.ALL) {
			ResourceKey<EntityType<?>> ek = ResourceKey.create(Registries.ENTITY_TYPE, id(s.id()));
			EntityType.Builder<DinoEntity> b = EntityType.Builder.of(DinoEntity::new, MobCategory.CREATURE)
					.sized(s.width(), s.height())
					.clientTrackingRange(10);
			if (s.mountable()) {
				b.passengerAttachments(s.height() * Species.seatFraction(s));
			}
			EntityType<DinoEntity> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, ek, b.build(ek));
			Species.bind(type, s);
			ENTITIES.put(s.id(), type);

			ResourceKey<Item> sk = ResourceKey.create(Registries.ITEM, id(s.id() + "_spawn_egg"));
			SPAWN_EGGS.put(s.id(), Registry.register(BuiltInRegistries.ITEM, sk,
					new SpawnEggItem(new Item.Properties().setId(sk).spawnEgg(type))));

			String eggId = "egg_" + s.id();
			ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK, id(eggId));
			DinoEggBlock block = Registry.register(BuiltInRegistries.BLOCK, bk, new DinoEggBlock(
					BlockBehaviour.Properties.of().setId(bk).strength(0.5f).noOcclusion().randomTicks(), s));
			EGG_BLOCKS.put(s.id(), block);

			ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, id(eggId));
			Item item = Registry.register(BuiltInRegistries.ITEM, ik,
					new BlockItem(block, new Item.Properties().setId(ik).useBlockDescriptionPrefix().stacksTo(16)));
			EGG_ITEMS.put(s.id(), item);
		}

		Block[] eggs = EGG_BLOCKS.values().toArray(new Block[0]);
		EGG_BE = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, id("dino_egg"),
				FabricBlockEntityTypeBuilder.create(DinoEggBlockEntity::new, eggs).build());
	}

	private static Item registerItem(String name, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, new Item(props.setId(key)));
	}

	private ModRegistry() {}
}
