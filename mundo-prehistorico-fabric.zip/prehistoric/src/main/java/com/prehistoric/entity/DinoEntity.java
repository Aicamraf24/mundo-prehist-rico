package com.prehistoric.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

import com.prehistoric.ModRegistry;
import com.prehistoric.Species;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.control.LookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Entidad unica para las 30 especies (los datos vienen de {@link Species}).
 * Extiende TamableAnimal: asi el propietario, sentarse y "recordar al dueno" usan el sistema vanilla
 * (se guarda en el NBT de la entidad, sobrevive a salir y volver a entrar al mundo).
 */
public class DinoEntity extends TamableAnimal {
	private static final EntityDataAccessor<Boolean> SADDLED = SynchedEntityData.defineId(DinoEntity.class, EntityDataSerializers.BOOLEAN);
	private static final EntityDataAccessor<Integer> BREEDING = SynchedEntityData.defineId(DinoEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> GROWTH = SynchedEntityData.defineId(DinoEntity.class, EntityDataSerializers.INT);

	public static final float NATURAL_BREED_CHANCE = 0.10f;
	private static final int BREED_CHECK_INTERVAL = 1200;   // cada 60 s por manada
	private static final int BREED_COOLDOWN = 12000;        // 10 min entre puestas de una manada
	private static final int BREED_ANIM_TICKS = 80;
	private static final int LOCAL_POPULATION_CAP = 8;      // maximo de la misma especie en 48 bloques

	public final Species species;
	private @Nullable UUID packId;
	private int packBreedCooldown;
	private boolean isLayer;

	public DinoEntity(EntityType<? extends DinoEntity> type, Level level) {
		super(type, level);
		this.species = Species.of(type);
		if (species.flying()) {
			this.moveControl = new FlyingMoveControl(this, 20, true);
			setNoGravity(true);
		} else if (species.aquatic()) {
			this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02f, 0.1f, true);
			this.lookControl = new SmoothSwimmingLookControl(this, 10);
		}
	}

	public static AttributeSupplier.Builder createAttributes(Species s) {
		AttributeSupplier.Builder b = Animal.createAnimalAttributes()
				.add(Attributes.MAX_HEALTH, s.health())
				.add(Attributes.ATTACK_DAMAGE, s.attack())
				.add(Attributes.MOVEMENT_SPEED, s.speed())
				.add(Attributes.FOLLOW_RANGE, 32.0)
				.add(Attributes.STEP_HEIGHT, s.height() > 2.0f ? 1.1 : 0.6);
		if (s.flying() || s.aquatic()) {
			b.add(Attributes.FLYING_SPEED, s.speed() * 2.0);
		}
		return b;
	}

	private Species sp() { return Species.of(getType()); }

	// ------------------------------------------------------------------ datos sincronizados
	@Override
	protected void defineSynchedData(SynchedEntityData.Builder b) {
		super.defineSynchedData(b);
		b.define(SADDLED, false);
		b.define(BREEDING, 0);
		b.define(GROWTH, 1000);
	}

	public boolean isSaddled() { return entityData.get(SADDLED); }
	public void setSaddled(boolean v) { entityData.set(SADDLED, v); }
	public boolean isBreedingAnim() { return entityData.get(BREEDING) > 0; }

	@Override
	public void onSyncedDataUpdated(EntityDataAccessor<?> acc) {
		super.onSyncedDataUpdated(acc);
		if (GROWTH.equals(acc)) refreshDimensions();
	}

	/** Escala visible y hitbox crecen de forma continua de bebe (35%) a adulto (100%). */
	@Override
	public float getAgeScale() {
		return 0.35f + 0.65f * (entityData.get(GROWTH) / 1000f);
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput out) {
		super.addAdditionalSaveData(out);
		out.putBoolean("Saddled", isSaddled());
		out.putInt("PackCooldown", packBreedCooldown);
		if (packId != null) out.putString("PackId", packId.toString());
	}

	@Override
	protected void readAdditionalSaveData(ValueInput in) {
		super.readAdditionalSaveData(in);
		setSaddled(in.getBooleanOr("Saddled", false));
		packBreedCooldown = in.getIntOr("PackCooldown", 0);
		packId = in.getString("PackId").map(UUID::fromString).orElse(null);
	}

	// ------------------------------------------------------------------ domesticacion
	/** Domestica para un jugador por UUID (funciona aunque este desconectado cuando eclosiona el huevo). */
	public void tameFor(UUID ownerId) {
		Player p = level().getPlayerByUUID(ownerId);
		if (p != null) {
			tame(p);
		} else {
			setTame(true, false);
			setOwnerReference(net.minecraft.world.entity.EntityReference.of(ownerId));
		}
		setOrderedToSit(false);
	}

	// ------------------------------------------------------------------ navegacion / IA
	@Override
	protected PathNavigation createNavigation(Level level) {
		Species s = sp();
		if (s != null && s.flying()) {
			FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
			nav.setCanOpenDoors(false);
			nav.setCanFloat(true);
			return nav;
		}
		if (s != null && s.aquatic()) {
			return new WaterBoundPathNavigation(this, level);
		}
		return super.createNavigation(level);
	}

	@Override
	protected void registerGoals() {
		Species s = sp();
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(1, new FreezeWhileBreedingGoal(this));
		goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
		if (s.fights()) {
			goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.2, true));
		} else {
			goalSelector.addGoal(3, new PanicGoal(this, 1.5));
		}
		goalSelector.addGoal(5, new FollowOwnerGoal(this, 1.1, 8.0f, 3.0f));
		goalSelector.addGoal(6, new BreedGoal(this, 1.0));
		goalSelector.addGoal(7, new FollowPackGoal(this));
		if (s.flying()) {
			goalSelector.addGoal(8, new WaterAvoidingRandomFlyingGoal(this, 1.0));
		} else if (s.aquatic()) {
			goalSelector.addGoal(8, new RandomSwimmingGoal(this, 1.0, 40));
		} else {
			goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 0.8));
		}
		goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0f));
		goalSelector.addGoal(10, new RandomLookAroundGoal(this));

		targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
		targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		targetSelector.addGoal(3, new HurtByTargetGoal(this));
		if (s.carnivore() && s.fights() && !s.small()) {
			// Depredadores letales: atacan jugadores, salvo a su dueno (los domesticados no cazan jugadores)
			targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
					(target, level) -> !isTame()));
		}
	}

	// ------------------------------------------------------------------ manadas
	public @Nullable UUID getPackId() { return packId; }

	private List<DinoEntity> packMates(double radius) {
		if (packId == null) return List.of();
		return level().getEntitiesOfClass(DinoEntity.class, getBoundingBox().inflate(radius),
				e -> e != this && e.isAlive() && packId.equals(e.packId) && !e.isTame());
	}

	private @Nullable Vec3 packCentroid() {
		List<DinoEntity> mates = packMates(48);
		if (mates.isEmpty()) return null;
		double x = 0, y = 0, z = 0;
		for (DinoEntity m : mates) { x += m.getX(); y += m.getY(); z += m.getZ(); }
		return new Vec3(x / mates.size(), y / mates.size(), z / mates.size());
	}

	/** Genera la manada completa (2 a 5, segun la especie) alrededor del primer ejemplar. */
	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance diff, EntitySpawnReason reason, @Nullable SpawnGroupData data) {
		SpawnGroupData result = super.finalizeSpawn(level, diff, reason, data);
		if (packId == null) packId = UUID.randomUUID();
		if (reason == EntitySpawnReason.NATURAL || reason == EntitySpawnReason.CHUNK_GENERATION) {
			int size = Mth.randomBetweenInclusive(random, species.packMin(), Math.min(5, species.packMax()));
			size = Math.max(2, size);
			for (int i = 1; i < size; i++) {
				spawnPackmate(level);
			}
		}
		return result;
	}

	private void spawnPackmate(ServerLevelAccessor level) {
		for (int attempt = 0; attempt < 10; attempt++) {
			double x = getX() + random.nextInt(9) - 4;
			double z = getZ() + random.nextInt(9) - 4;
			double y = getY();
			if (!species.flying() && !species.aquatic()) {
				BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(x, y, z));
				y = top.getY();
			}
			DinoEntity mate = ModRegistry.ENTITIES.get(species.id()).create(level.getLevel(), EntitySpawnReason.MOB_SUMMONED);
			if (mate == null) return;
			mate.snapTo(x, y, z, random.nextFloat() * 360f, 0f);
			if (!level.noCollision(mate.getBoundingBox())) continue;
			mate.packId = packId;
			level.addFreshEntity(mate);
			return;
		}
	}

	/** Si el atacado es de una manada, los demas reaccionan segun su especie. */
	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		boolean hurt = super.hurtServer(level, source, amount);
		if (hurt && !isTame() && source.getEntity() instanceof LivingEntity attacker) {
			for (DinoEntity mate : packMates(32)) {
				if (mate.species.fights()) {
					mate.setTarget(attacker);
				} else {
					Vec3 away = DefaultRandomPos.getPosAway(mate, 16, 7, attacker.position());
					if (away != null) mate.getNavigation().moveTo(away.x, away.y, away.z, 1.5);
				}
			}
		}
		return hurt;
	}

	// ------------------------------------------------------------------ reproduccion natural (10 %)
	private void naturalBreedingCheck(ServerLevel sl) {
		if (isTame() || isBaby() || packId == null || isBreedingAnim()) return;
		List<DinoEntity> group = new ArrayList<>(packMates(24));
		// solo el miembro con el menor UUID actua como "lider" de la comprobacion
		for (DinoEntity m : group) {
			if (m.getUUID().compareTo(getUUID()) < 0) return;
		}
		if (packBreedCooldown > 0) {
			packBreedCooldown = Math.max(0, packBreedCooldown - BREED_CHECK_INTERVAL);
			return;
		}
		if (random.nextFloat() >= NATURAL_BREED_CHANCE) return;

		group.add(this);
		List<DinoEntity> adults = new ArrayList<>();
		for (DinoEntity m : group) {
			if (!m.isBaby() && m.getAge() == 0 && !m.isBreedingAnim()) adults.add(m);
		}
		if (adults.size() < 2) return;

		int population = level().getEntitiesOfClass(DinoEntity.class, getBoundingBox().inflate(48), e -> e.getType() == getType()).size();
		if (population >= LOCAL_POPULATION_CAP) return;

		Collections.shuffle(adults);
		adults.get(0).startBreedingAnim(true);
		adults.get(1).startBreedingAnim(false);
		packBreedCooldown = BREED_COOLDOWN;
	}

	private void startBreedingAnim(boolean layer) {
		this.isLayer = layer;
		entityData.set(BREEDING, BREED_ANIM_TICKS);
		getNavigation().stop();
	}

	/** Pone un huevo fertil de la especie en el suelo cerca de los progenitores. */
	public boolean layEgg(ServerLevel sl) {
		BlockState egg = ModRegistry.EGG_BLOCKS.get(species.id()).defaultBlockState();
		BlockPos origin = blockPosition();
		for (int i = 0; i < 16; i++) {
			BlockPos p = origin.offset(random.nextInt(5) - 2, random.nextInt(3) - 1, random.nextInt(5) - 2);
			boolean freeSpace = sl.getBlockState(p).isAir() || sl.getBlockState(p).is(net.minecraft.world.level.block.Blocks.WATER);
			boolean solidBelow = sl.getBlockState(p.below()).isFaceSturdy(sl, p.below(), Direction.UP);
			if (freeSpace && solidBelow) {
				sl.setBlock(p, egg, 3);
				sl.playSound(null, p, SoundEvents.TURTLE_LAY_EGG, SoundSource.BLOCKS, 0.8f, 0.8f);
				return true;
			}
		}
		return false;
	}

	/** Cria manual: dos adultos de la misma especie alimentados con chuleta ponen un huevo. */
	@Override
	public void spawnChildFromBreeding(ServerLevel level, Animal partner) {
		layEgg(level);
		setAge(6000);
		partner.setAge(6000);
		resetLove();
		partner.resetLove();
		level.broadcastEntityEvent(this, (byte) 18);
	}

	@Override
	public boolean canMate(Animal other) {
		return other != this && other instanceof DinoEntity d && d.getType() == getType() && isInLove() && d.isInLove();
	}

	@Override
	public @Nullable AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
		return null; // nunca nace una cria directa: siempre se pasa por el huevo
	}

	// ------------------------------------------------------------------ alimentacion y crecimiento
	@Override
	public boolean isFood(ItemStack stack) {
		return stack.is(Items.PORKCHOP) || stack.is(Items.COOKED_PORKCHOP);
	}

	// ------------------------------------------------------------------ tick
	@Override
	public void aiStep() {
		super.aiStep();
		if (!(level() instanceof ServerLevel sl)) return;

		// crecimiento visible: sincroniza el progreso (la alimentacion lo adelanta via ageUp)
		if (tickCount % 10 == 0) {
			int growth = 1000;
			if (getAge() < 0) {
				float progress = 1f - (-getAge() / (float) species.babyTicks());
				growth = Mth.clamp((int) (progress * 1000f), 0, 1000);
			}
			if (growth != entityData.get(GROWTH)) {
				entityData.set(GROWTH, growth);
				refreshDimensions();
			}
		}

		// animacion de reproduccion natural
		int b = entityData.get(BREEDING);
		if (b > 0) {
			entityData.set(BREEDING, b - 1);
			if (b % 10 == 0) {
				sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight() * 0.9, getZ(), 2, 0.4, 0.3, 0.4, 0.0);
			}
			if (b == 1 && isLayer) {
				layEgg(sl);
				isLayer = false;
			}
		}

		if (!isTame() && (tickCount + getId()) % BREED_CHECK_INTERVAL == 0) {
			naturalBreedingCheck(sl);
		}

		if (species.flying()) {
			setNoGravity(!isInSittingPose() && !onGround());
			if (!isInSittingPose()) setNoGravity(true);
		}
	}

	// ------------------------------------------------------------------ interaccion: silla, montar, sentar
	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack held = player.getItemInHand(hand);
		if (isTame() && isOwnedBy(player)) {
			if (held.is(Items.SADDLE)) {
				if (species.mountable() && !isBaby() && !isSaddled()) {
					if (!level().isClientSide()) {
						setSaddled(true);
						held.consume(1, player);
						level().playSound(null, blockPosition(), SoundEvents.HORSE_SADDLE.value(), SoundSource.NEUTRAL, 1.0f, 1.0f);
					}
					return InteractionResult.SUCCESS;
				}
				return InteractionResult.PASS;
			}
			if (held.isEmpty()) {
				if (isSaddled() && !isBaby() && !player.isSecondaryUseActive()) {
					if (!level().isClientSide()) {
						setOrderedToSit(false);
						player.startRiding(this);
					}
					return InteractionResult.SUCCESS;
				}
				if (!level().isClientSide()) {
					boolean sit = !isOrderedToSit();
					setOrderedToSit(sit);
					setInSittingPose(sit);
					setJumping(false);
					getNavigation().stop();
					setTarget(null);
				}
				return InteractionResult.SUCCESS;
			}
		}
		return super.mobInteract(player, hand);
	}

	@Override
	protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
		super.dropCustomDeathLoot(level, source, recentlyHit);
		if (isSaddled()) spawnAtLocation(level, Items.SADDLE);
	}

	// ------------------------------------------------------------------ monturas
	@Override
	public @Nullable LivingEntity getControllingPassenger() {
		Entity first = getFirstPassenger();
		return first instanceof Player p && isSaddled() && isOwnedBy(p) ? p : super.getControllingPassenger();
	}

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return species.mountable() && isSaddled() && getPassengers().isEmpty();
	}

	private boolean threeDimensionalRide() {
		return species.flying() || (species.aquatic() && isInWater());
	}

	@Override
	protected Vec3 getRiddenInput(Player player, Vec3 input) {
		float x = player.xxa * 0.5f;
		float z = player.zza;
		if (z <= 0) z *= 0.25f;
		float y = 0f;
		if (threeDimensionalRide() && z > 0) {
			y = -Mth.sin(player.getXRot() * Mth.DEG_TO_RAD) * z; // el jugador sube/baja mirando arriba/abajo
		}
		return new Vec3(x, y, z);
	}

	@Override
	protected void tickRidden(Player player, Vec3 input) {
		super.tickRidden(player, input);
		setRot(player.getYRot(), player.getXRot() * 0.5f);
		this.yRotO = this.yBodyRot = this.yHeadRot = getYRot();
	}

	/** Velocidad propia de cada especie (atributo base x multiplicador de monta). */
	@Override
	protected float getRiddenSpeed(Player player) {
		return (float) (getAttributeValue(Attributes.MOVEMENT_SPEED) * species.rideSpeed());
	}

	@Override
	public void travel(Vec3 input) {
		boolean freeMovement = (species.flying() && !isInSittingPose()) || (species.aquatic() && isInWater());
		if (freeMovement) {
			if (getControllingPassenger() instanceof Player rider) {
				if (isLocalInstanceAuthoritative()) {
					Vec3 ride = getRiddenInput(rider, input);
					tickRidden(rider, ride);
					setSpeed(getRiddenSpeed(rider));
					glide(ride);
				} else {
					setDeltaMovement(Vec3.ZERO);
				}
				return;
			}
			if (isEffectiveAi()) {
				glide(input);
				return;
			}
		}
		super.travel(input);
	}

	private void glide(Vec3 input) {
		moveRelative(species.flying() ? getSpeed() : 0.02f + getSpeed() * 0.2f, input);
		move(MoverType.SELF, getDeltaMovement());
		setDeltaMovement(getDeltaMovement().scale(species.flying() ? 0.91 : 0.9));
	}

	@Override
	public boolean isPushedByFluid() { return !species.aquatic(); }

	@Override
	public boolean canBreatheUnderwater() { return species.aquatic(); }

	// ------------------------------------------------------------------ sonidos
	@Override
	protected @Nullable SoundEvent getAmbientSound() {
		if (species.aquatic()) return SoundEvents.DOLPHIN_AMBIENT;
		if (species.flying() || species.small()) return SoundEvents.PARROT_AMBIENT;
		return species.carnivore() ? SoundEvents.RAVAGER_AMBIENT : SoundEvents.HOGLIN_AMBIENT;
	}

	@Override
	protected @Nullable SoundEvent getHurtSound(DamageSource source) {
		if (species.aquatic()) return SoundEvents.DOLPHIN_HURT;
		if (species.flying() || species.small()) return SoundEvents.PARROT_HURT;
		return species.carnivore() ? SoundEvents.RAVAGER_HURT : SoundEvents.HOGLIN_HURT;
	}

	@Override
	protected @Nullable SoundEvent getDeathSound() {
		if (species.aquatic()) return SoundEvents.DOLPHIN_DEATH;
		if (species.flying() || species.small()) return SoundEvents.PARROT_DEATH;
		return species.carnivore() ? SoundEvents.RAVAGER_DEATH : SoundEvents.HOGLIN_DEATH;
	}

	// ------------------------------------------------------------------ objetivos auxiliares
	static class FreezeWhileBreedingGoal extends Goal {
		private final DinoEntity mob;

		FreezeWhileBreedingGoal(DinoEntity mob) {
			this.mob = mob;
			setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
		}

		@Override public boolean canUse() { return mob.isBreedingAnim(); }
		@Override public boolean canContinueToUse() { return mob.isBreedingAnim(); }
		@Override public void start() { mob.getNavigation().stop(); }
	}

	/** Mantiene a los miembros de una manada cerca los unos de los otros. */
	static class FollowPackGoal extends Goal {
		private final DinoEntity mob;
		private Vec3 target;
		private int cooldown;

		FollowPackGoal(DinoEntity mob) {
			this.mob = mob;
			setFlags(EnumSet.of(Flag.MOVE));
		}

		@Override
		public boolean canUse() {
			if (mob.isTame() || mob.packId == null || mob.isPassenger() || mob.isBreedingAnim()) return false;
			if (--cooldown > 0) return false;
			cooldown = 40;
			Vec3 c = mob.packCentroid();
			if (c != null && mob.position().distanceToSqr(c) > 49.0) { // mas de 7 bloques del grupo
				target = c;
				return true;
			}
			return false;
		}

		@Override
		public boolean canContinueToUse() {
			return !mob.getNavigation().isDone() && target != null && mob.position().distanceToSqr(target) > 16.0;
		}

		@Override
		public void start() {
			mob.getNavigation().moveTo(target.x, target.y, target.z, 1.1);
		}
	}
}
