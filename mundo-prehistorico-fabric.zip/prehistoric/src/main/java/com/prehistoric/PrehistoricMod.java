package com.prehistoric;

import com.prehistoric.entity.DinoEntity;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public class PrehistoricMod implements ModInitializer {
	public static final String MOD_ID = "prehistoric";
	public static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();

	private static ResourceKey<net.minecraft.world.level.biome.Biome> biome(String name) {
		return ResourceKey.create(Registries.BIOME, ModRegistry.id(name));
	}

	@Override
	public void onInitialize() {
		Species.load();
		ModRegistry.registerAll();
		ModExtras.register();
		ModTrees.register();

		for (Species s : Species.ALL) {
			EntityType<DinoEntity> type = ModRegistry.ENTITIES.get(s.id());
			FabricDefaultAttributeRegistry.register(type, DinoEntity.createAttributes(s));

			// Reglas de aparicion propias de cada especie
			if (s.aquatic()) {
				SpawnPlacements.register(type, SpawnPlacementTypes.NO_RESTRICTIONS, Heightmap.Types.OCEAN_FLOOR,
						(t, lvl, reason, pos, rnd) -> lvl.getFluidState(pos).is(FluidTags.WATER));
			} else if (s.flying()) {
				SpawnPlacements.register(type, SpawnPlacementTypes.NO_RESTRICTIONS, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
						(t, lvl, reason, pos, rnd) -> true);
			} else {
				SpawnPlacements.register(type, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
						Mob::checkMobSpawnRules);
			}

			// Las manadas (2 a 5) las compone DinoEntity#finalizeSpawn; aqui se spawnea un "lider" por intento.
			TagKey<Biome> habitat = TagKey.create(Registries.BIOME, ModRegistry.id("habitat/" + s.habitat()));
			MobCategory cat = s.aquatic() ? MobCategory.WATER_CREATURE : MobCategory.CREATURE;
			BiomeModifications.addSpawn(BiomeSelectors.tag(habitat), cat, type, s.weight(), 1, 1);
		}

		// Fauna marina: generador propio + las criaturas marinas de Minecraft en los biomas acuaticos de la dimension
		ServerTickEvents.END_LEVEL_TICK.register(MarineSpawner::tick);
		var sea = BiomeSelectors.includeByKey(biome("prehistoric_sea"), biome("prehistoric_deep_sea"), biome("prehistoric_reef"));
		BiomeModifications.addSpawn(sea, MobCategory.WATER_AMBIENT, EntityType.COD, 10, 3, 6);
		BiomeModifications.addSpawn(sea, MobCategory.WATER_AMBIENT, EntityType.SALMON, 5, 1, 4);
		BiomeModifications.addSpawn(sea, MobCategory.WATER_AMBIENT, EntityType.PUFFERFISH, 15, 1, 3);
		BiomeModifications.addSpawn(sea, MobCategory.WATER_CREATURE, EntityType.SQUID, 10, 1, 4);
		BiomeModifications.addSpawn(sea, MobCategory.WATER_CREATURE, EntityType.DOLPHIN, 5, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(biome("prehistoric_reef")), MobCategory.WATER_AMBIENT, EntityType.TROPICAL_FISH, 25, 8, 8);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(biome("prehistoric_river"), biome("jurassic_swamp")), MobCategory.WATER_AMBIENT, EntityType.SALMON, 5, 1, 5);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(biome("prehistoric_river")), MobCategory.WATER_CREATURE, EntityType.SQUID, 2, 1, 4);

		// Arbol prehistorico: 25 % de probabilidad por chunk en cualquier bioma (salvo Nether y End)
		ResourceKey<PlacedFeature> treePlaced = ResourceKey.create(Registries.PLACED_FEATURE, ModRegistry.id("prehistoric_tree"));
		BiomeModifications.addFeature(BiomeSelectors.all()
				.and(BiomeSelectors.tag(BiomeTags.IS_NETHER).negate()).and(BiomeSelectors.tag(BiomeTags.IS_END).negate()),
				GenerationStep.Decoration.VEGETAL_DECORATION, treePlaced);

		// Pestana creativa
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, ModRegistry.id("main"),
				CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
						.title(Component.translatable("itemGroup.prehistoric"))
						.icon(() -> new ItemStack(ModRegistry.EGG_ITEMS.get("trex")))
						.displayItems((params, out) -> {
							out.accept(ModRegistry.DINO_MEAT);
							out.accept(ModRegistry.COOKED_DINO_MEAT);
							for (Species s : Species.ALL) out.accept(ModRegistry.EGG_ITEMS.get(s.id()));
							for (Species s : Species.ALL) out.accept(ModRegistry.SPAWN_EGGS.get(s.id()));
							for (net.minecraft.world.item.Item i : ModExtras.ITEMS) out.accept(i);
							for (net.minecraft.world.item.Item i : ModTrees.ITEMS) out.accept(i);
						})
						.build());
	}
}
