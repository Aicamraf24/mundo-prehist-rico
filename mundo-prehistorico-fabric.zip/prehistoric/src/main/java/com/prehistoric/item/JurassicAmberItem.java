package com.prehistoric.item;

import com.prehistoric.ModExtras;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

/** Ambar Jurasico: clic derecho viaja a la dimension prehistorica y, estando alli, de vuelta al Overworld. */
public class JurassicAmberItem extends Item {
	public JurassicAmberItem(Properties props) {
		super(props);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!(level instanceof ServerLevel here) || !(player instanceof ServerPlayer sp)) {
			return InteractionResult.SUCCESS;
		}
		ServerLevel target = here.dimension().equals(ModExtras.JURASSIC)
				? here.getServer().overworld()
				: here.getServer().getLevel(ModExtras.JURASSIC);
		if (target == null) {
			sp.displayClientMessage(Component.literal("La dimension prehistorica no esta cargada."), true);
			return InteractionResult.FAIL;
		}
		BlockPos ground = target.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
				BlockPos.containing(sp.getX(), 0, sp.getZ()));
		sp.teleport(new TeleportTransition(target, new Vec3(ground.getX() + 0.5, ground.getY(), ground.getZ() + 0.5),
				Vec3.ZERO, sp.getYRot(), sp.getXRot(), TeleportTransition.DO_NOTHING));
		return InteractionResult.SUCCESS;
	}
}
