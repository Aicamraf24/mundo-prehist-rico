package com.prehistoric.item;

import com.prehistoric.ModExtras;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Ambar Jurasico: clic derecho viaja a la dimension prehistorica y, estando alli, de vuelta al Overworld.
 * Llega a las mismas coordenadas X/Z, sobre un bloque de hierba si lo hay (se busca en espiral alrededor) o, si no, sobre cualquier suelo solido.
 */
public class JurassicAmberItem extends Item {
	private static final int SEARCH_RADIUS = 24;

	public JurassicAmberItem(Properties props) {
		super(props);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!(level instanceof ServerLevel here) || !(player instanceof ServerPlayer sp)) {
			return InteractionResult.SUCCESS;
		}
		ServerLevel target = here.dimension().equals(ModExtras.JURASSIC)
				? here.getServer().overworld()
				: here.getServer().getLevel(ModExtras.JURASSIC);
		if (target == null) {
			sp.sendSystemMessage(Component.literal("La dimension prehistorica no esta cargada."), true);
			return InteractionResult.FAIL;
		}
		BlockPos spot = findSurface(target, sp.getBlockX(), sp.getBlockZ());
		if (spot == null) {
			sp.sendSystemMessage(Component.literal("No se pudo encontrar un punto de llegada en esas coordenadas."), true);
			return InteractionResult.FAIL;
		}
		sp.teleport(new TeleportTransition(target, new Vec3(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5),
				Vec3.ZERO, sp.getYRot(), sp.getXRot(), TeleportTransition.DO_NOTHING));
		return InteractionResult.SUCCESS;
	}

	/**
	 * Posicion (pies del jugador) sobre el suelo. Orden de preferencia: bloque de hierba cercano, otro suelo solido cercano,
	 * tierra firme mas lejana (hasta 96 bloques) y, si todo es oceano, la superficie del agua en las mismas X/Z.
	 */
	private static @Nullable BlockPos findSurface(ServerLevel level, int x0, int z0) {
		BlockPos fallback = null;
		// 1) Cerca: espiral de radio 24 alrededor de las mismas coordenadas
		for (int r = 0; r <= SEARCH_RADIUS; r++) {
			int step = r <= 2 ? 1 : 3;
			for (int dx = -r; dx <= r; dx += step) {
				for (int dz = -r; dz <= r; dz += step) {
					if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
					BlockPos feet = standable(level, x0 + dx, z0 + dz);
					if (feet == null) continue;
					if (level.getBlockState(feet.below()).is(Blocks.GRASS_BLOCK)) return feet;
					if (fallback == null) fallback = feet;
				}
			}
		}
		if (fallback != null) return fallback;
		// 2) Lejos: anillos de 32 a 96 bloques, una muestra cada 16 bloques (un chunk por muestra)
		for (int r = 32; r <= 96; r += 16) {
			for (int dx = -r; dx <= r; dx += 16) {
				for (int dz = -r; dz <= r; dz += 16) {
					if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
					BlockPos feet = standable(level, x0 + dx, z0 + dz);
					if (feet == null) continue;
					if (level.getBlockState(feet.below()).is(Blocks.GRASS_BLOCK)) return feet;
					if (fallback == null) fallback = feet;
				}
			}
			if (fallback != null) return fallback;
		}
		// 3) Todo es agua: aparecer nadando en la superficie, en las mismas X/Z
		level.getChunk(x0 >> 4, z0 >> 4);
		int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x0, z0);
		BlockPos water = new BlockPos(x0, top - 1, z0);
		if (top > level.getMinY() + 1 && !level.getFluidState(water).isEmpty() && !level.getFluidState(water).is(net.minecraft.tags.FluidTags.LAVA)) return water;
		return null;
	}

	/** Pies del jugador si la columna tiene suelo solido seco con 2 bloques de aire encima; null si no. */
	private static @Nullable BlockPos standable(ServerLevel level, int x, int z) {
		level.getChunk(x >> 4, z >> 4); // carga/genera el chunk antes de leer la altura (antes caia bajo la bedrock)
		int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
		if (y <= level.getMinY() + 1 || y >= level.getMaxY() - 3) return null;
		BlockPos feet = new BlockPos(x, y, z);
		BlockPos below = feet.below();
		BlockState ground = level.getBlockState(below);
		if (!level.getFluidState(below).isEmpty() || !level.getFluidState(feet).isEmpty()) return null;   // ni agua ni lava
		if (!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()) return null;
		if (!ground.isSolid() || ground.is(Blocks.MAGMA_BLOCK) || ground.is(Blocks.BEDROCK)) return null;
		return feet;
	}
}
