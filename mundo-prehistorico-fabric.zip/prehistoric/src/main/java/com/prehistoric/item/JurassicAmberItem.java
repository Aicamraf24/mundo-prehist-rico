package com.prehistoric.item;

import com.prehistoric.ModExtras;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Ambar Jurasico: clic derecho viaja a la dimension prehistorica y, estando alli, de vuelta al Overworld.
 * Llega a las mismas coordenadas X/Z, sobre un bloque de hierba si lo hay (se busca en espiral alrededor) o, si no, sobre cualquier suelo solido.
 */
public class JurassicAmberItem extends Item {
	private static final int SEARCH_RADIUS = 24;

	public JurassicAmberItem(Properties props) {
		super(props);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!(level instanceof ServerLevel here) || !(player instanceof ServerPlayer sp)) {
			return InteractionResult.SUCCESS;
		}
		ServerLevel target = here.dimension().equals(ModExtras.JURASSIC)
				? here.getServer().overworld()
				: here.getServer().getLevel(ModExtras.JURASSIC);
		if (target == null) {
			sp.sendSystemMessage(Component.literal("La dimension prehistorica no esta cargada."), true);
			return InteractionResult.FAIL;
		}
		BlockPos spot = findSurface(target, sp.getBlockX(), sp.getBlockZ());
		if (spot == null) {
			sp.sendSystemMessage(Component.literal("No se encontro un suelo seguro cerca de esas coordenadas."), true);
			return InteractionResult.FAIL;
		}
		sp.teleport(new TeleportTransition(target, new Vec3(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5),
				Vec3.ZERO, sp.getYRot(), sp.getXRot(), TeleportTransition.DO_NOTHING));
		return InteractionResult.SUCCESS;
	}

	/** Posicion (pies del jugador) sobre el suelo. Prioriza bloque de hierba; devuelve cualquier suelo solido como alternativa. */
	private static @Nullable BlockPos findSurface(ServerLevel level, int x0, int z0) {
		BlockPos fallback = null;
		for (int r = 0; r <= SEARCH_RADIUS; r++) {
			int step = r <= 2 ? 1 : 3;
			for (int dx = -r; dx <= r; dx += step) {
				for (int dz = -r; dz <= r; dz += step) {
					if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
					int x = x0 + dx, z = z0 + dz;
					level.getChunk(x >> 4, z >> 4); // carga/genera el chunk antes de leer la altura (antes caia bajo la bedrock)
					int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
					if (y <= level.getMinY() + 1 || y >= level.getMaxY() - 3) continue;
					BlockPos feet = new BlockPos(x, y, z);
					BlockPos below = feet.below();
					BlockState ground = level.getBlockState(below);
					if (!level.getFluidState(below).isEmpty() || !level.getFluidState(feet).isEmpty()) continue;   // ni agua ni lava
					if (!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()) continue;
					if (ground.is(Blocks.GRASS_BLOCK)) return feet;
					if (fallback == null && ground.isSolid() && !ground.is(Blocks.MAGMA_BLOCK) && !ground.is(Blocks.BEDROCK)) fallback = feet;
				}
			}
		}
		return fallback;
	}
}
