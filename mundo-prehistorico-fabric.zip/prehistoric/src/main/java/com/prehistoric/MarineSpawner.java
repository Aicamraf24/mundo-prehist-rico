package com.prehistoric;

import java.util.ArrayList;
import java.util.List;

import com.prehistoric.entity.DinoEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

/**
 * Generador propio de dinosaurios marinos en la dimension prehistorica. No depende del sistema de aparicion vanilla:
 * cada 5 s, cerca de cada jugador, intenta crear una manada en aguas profundas (con tope de poblacion).
 */
public final class MarineSpawner {
	private static final int INTERVAL = 100;
	private static final int CAP_NEAR_PLAYER = 8;
	private static final List<Species> MARINE = new ArrayList<>();

	public static void tick(ServerLevel level) {
		if (!level.dimension().equals(ModExtras.JURASSIC) || level.getGameTime() % INTERVAL != 0) return;
		if (MARINE.isEmpty()) for (Species s : Species.ALL) if (s.aquatic()) MARINE.add(s);
		RandomSource rnd = level.getRandom();
		for (ServerPlayer player : level.players()) {
			try {
				spawnNear(level, player, rnd);
			} catch (RuntimeException e) {
				PrehistoricMod.LOGGER.warn("MarineSpawner fallo", e);
			}
		}
	}

	private static void spawnNear(ServerLevel level, ServerPlayer player, RandomSource rnd) {
		{
			AABB area = player.getBoundingBox().inflate(96);
			if (level.getEntitiesOfClass(DinoEntity.class, area, e -> e.species.aquatic()).size() >= CAP_NEAR_PLAYER) return;
			if (rnd.nextFloat() > 0.5f) return;
			double ang = rnd.nextDouble() * Math.PI * 2;
			double dist = 24 + rnd.nextDouble() * 32;
			int x = (int) (player.getX() + Math.cos(ang) * dist), z = (int) (player.getZ() + Math.sin(ang) * dist);
			if (!level.hasChunk(x >> 4, z >> 4)) return;
			int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z);
			int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
			if (top - floor < 7 || !level.getFluidState(new BlockPos(x, top - 1, z)).is(FluidTags.WATER)) return;
			int y = floor + 3 + rnd.nextInt(Math.max(1, top - floor - 6));
			Species s = MARINE.get(rnd.nextInt(MARINE.size()));
			DinoEntity mob = ModRegistry.ENTITIES.get(s.id()).create(level, EntitySpawnReason.NATURAL);
			if (mob == null) return;
			mob.snapTo(x + 0.5, y, z + 0.5, rnd.nextFloat() * 360f, 0f);
			if (!level.getFluidState(mob.blockPosition()).is(FluidTags.WATER) || !level.noCollision(mob.getBoundingBox())) return;
			mob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()), EntitySpawnReason.NATURAL, null); // crea la manada
			level.addFreshEntityWithPassengers(mob);
		}
	}

	private MarineSpawner() {}
}
