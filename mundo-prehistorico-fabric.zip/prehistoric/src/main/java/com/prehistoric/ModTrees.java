package com.prehistoric;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TintedParticleLeavesBlock;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

/** Arbol prehistorico: tronco, madera, tablones, escalera, losa, valla, hojas y brote. */
public final class ModTrees {
	public static final ResourceKey<ConfiguredFeature<?, ?>> TREE = ResourceKey.create(Registries.CONFIGURED_FEATURE, ModRegistry.id("prehistoric_tree"));
	public static final List<Item> ITEMS = new ArrayList<>();
	public static Block LOG, STRIPPED_LOG, WOOD, STRIPPED_WOOD, PLANKS, STAIRS, SLAB, FENCE, LEAVES, SAPLING;

	private static Block block(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
		ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK, ModRegistry.id(name));
		Block b = Registry.register(BuiltInRegistries.BLOCK, bk, factory.apply(props.setId(bk)));
		ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, ModRegistry.id(name));
		ITEMS.add(Registry.register(BuiltInRegistries.ITEM, ik, new BlockItem(b, new Item.Properties().setId(ik).useBlockDescriptionPrefix())));
		return b;
	}

	public static void register() {
		LOG = block("prehistoric_log", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG));
		STRIPPED_LOG = block("stripped_prehistoric_log", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG));
		WOOD = block("prehistoric_wood", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_WOOD));
		STRIPPED_WOOD = block("stripped_prehistoric_wood", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_WOOD));
		PLANKS = block("prehistoric_planks", Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PLANKS));
		STAIRS = block("prehistoric_stairs", p -> new StairBlock(PLANKS.defaultBlockState(), p), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_STAIRS));
		SLAB = block("prehistoric_slab", SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SLAB));
		FENCE = block("prehistoric_fence", FenceBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_FENCE));
		LEAVES = block("prehistoric_leaves", p -> new TintedParticleLeavesBlock(0.01f, p), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES));
		TreeGrower grower = new TreeGrower("prehistoric", Optional.empty(), Optional.of(TREE), Optional.empty());
		SAPLING = block("prehistoric_sapling", p -> new SaplingBlock(grower, p), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING));

		StrippableBlockRegistry.register(LOG, STRIPPED_LOG);
		StrippableBlockRegistry.register(WOOD, STRIPPED_WOOD);
	}

	private ModTrees() {}
}
