package com.prehistoric.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.prehistoric.ModRegistry;
import com.prehistoric.Species;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * Huevo de una especie. Se recoge con clic derecho (sin herramientas), conserva especie y progreso
 * de incubacion en el item, y el jugador que lo coloca pasa a ser el futuro propietario.
 */
public class DinoEggBlock extends Block implements EntityBlock {
	public static final MapCodec<DinoEggBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
			propertiesCodec(),
			Codec.STRING.fieldOf("species").forGetter(b -> b.species.id())
	).apply(i, (p, id) -> new DinoEggBlock(p, Species.ALL.stream().filter(s -> s.id().equals(id)).findFirst().orElseThrow())));

	private static final VoxelShape SHAPE = Block.box(4, 0, 4, 12, 11, 12);
	public final Species species;

	public DinoEggBlock(Properties props, Species species) {
		super(props);
		this.species = species;
	}

	@Override
	protected MapCodec<? extends Block> codec() { return CODEC; }

	@Override
	protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
		return SHAPE;
	}

	@Override
	public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new DinoEggBlockEntity(pos, state);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		if (level.isClientSide() || type != ModRegistry.EGG_BE) return null;
		return (BlockEntityTicker<T>) (BlockEntityTicker<DinoEggBlockEntity>) DinoEggBlockEntity::serverTick;
	}

	/** Al colocar el huevo: restaura el progreso del item y registra al jugador como futuro dueno. */
	@Override
	public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
		super.setPlacedBy(level, pos, state, placer, stack);
		if (level.getBlockEntity(pos) instanceof DinoEggBlockEntity be) {
			CustomData data = stack.get(DataComponents.CUSTOM_DATA);
			if (data != null) {
				be.setProgress(data.copyTag().getIntOr("progress", 0));
			}
			if (placer instanceof Player p) {
				be.setOwner(p.getUUID());
			}
		}
	}

	/** Clic derecho con la mano: recoger el huevo conservando especie y progreso. */
	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (!level.isClientSide() && level.getBlockEntity(pos) instanceof DinoEggBlockEntity be) {
			ItemStack stack = new ItemStack(ModRegistry.EGG_ITEMS.get(species.id()));
			CompoundTag tag = new CompoundTag();
			tag.putInt("progress", be.getProgress());
			stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
			level.removeBlock(pos, false);
			if (!player.getInventory().add(stack)) {
				player.drop(stack, false);
			}
			level.playSound(null, pos, SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.4f, 1.2f);
		}
		return InteractionResult.SUCCESS;
	}
}
