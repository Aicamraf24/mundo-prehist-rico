package com.prehistoric.block;

import java.util.UUID;

import com.prehistoric.ModRegistry;
import com.prehistoric.Species;
import com.prehistoric.entity.DinoEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

/** Guarda progreso de incubacion y propietario. Avanza solo sobre un bloque de magma. */
public class DinoEggBlockEntity extends BlockEntity {
	/** 5 minutos a 20 ticks por segundo. */
	public static final int INCUBATION_TICKS = 5 * 60 * 20;

	private int progress;
	private @Nullable UUID owner;

	public DinoEggBlockEntity(BlockPos pos, BlockState state) {
		super(ModRegistry.EGG_BE, pos, state);
	}

	public int getProgress() { return progress; }
	public void setProgress(int p) { this.progress = Math.max(0, p); setChanged(); }
	public void setOwner(@Nullable UUID owner) { this.owner = owner; setChanged(); }

	@Override
	protected void saveAdditional(ValueOutput out) {
		super.saveAdditional(out);
		out.putInt("progress", progress);
		if (owner != null) out.putString("owner", owner.toString());
	}

	@Override
	protected void loadAdditional(ValueInput in) {
		super.loadAdditional(in);
		progress = in.getIntOr("progress", 0);
		owner = in.getString("owner").map(UUID::fromString).orElse(null);
	}

	public static void serverTick(Level level, BlockPos pos, BlockState state, DinoEggBlockEntity be) {
		if (!(level instanceof ServerLevel sl)) return;
		if (!level.getBlockState(pos.below()).is(Blocks.MAGMA_BLOCK)) return; // solo incuba sobre magma
		be.progress++;
		be.setChanged();
		if (be.progress % 40 == 0) {
			sl.sendParticles(ParticleTypes.SMALL_FLAME, pos.getX() + 0.5, pos.getY() + 0.3, pos.getZ() + 0.5, 3, 0.15, 0.1, 0.15, 0.01);
		}
		if (be.progress >= INCUBATION_TICKS) {
			try {
				be.hatch(sl, pos, state);
			} catch (RuntimeException e) {
				com.prehistoric.PrehistoricMod.LOGGER.warn("Fallo al eclosionar un huevo en {}", pos, e);
			}
		}
	}

	private void hatch(ServerLevel sl, BlockPos pos, BlockState state) {
		Species s = ((DinoEggBlock) state.getBlock()).species;
		DinoEntity baby = ModRegistry.ENTITIES.get(s.id()).create(sl, EntitySpawnReason.BREEDING);
		sl.removeBlock(pos, false);
		if (baby == null) return;
		baby.snapTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, sl.getRandom().nextFloat() * 360f, 0f);
		baby.setAge(-s.babyTicks());
		if (owner != null) {
			baby.tameFor(owner); // domesticacion automatica por incubacion
		}
		sl.addFreshEntity(baby);
		sl.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS, 1.0f, 0.9f);
		sl.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.4, pos.getZ() + 0.5, 12, 0.25, 0.2, 0.25, 0.02);
	}
}
