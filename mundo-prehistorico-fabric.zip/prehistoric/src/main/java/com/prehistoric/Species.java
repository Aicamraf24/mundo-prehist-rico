package com.prehistoric;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.world.entity.EntityType;

/** Datos de una especie. Se cargan de data/prehistoric/species.csv (la misma tabla que usa el generador de texturas). */
public record Species(String id, Plan plan, float width, float height, double health, double attack,
		double speed, double rideSpeed, boolean mountable, boolean carnivore, boolean fights,
		int packMin, int packMax, int weight, String habitat, int babyTicks,
		int color, int accent, boolean horns, boolean crest) {

	public static final List<Species> ALL = new ArrayList<>();
	private static final Map<EntityType<?>, Species> BY_TYPE = new HashMap<>();
	private static final Map<String, Float> SEAT = new HashMap<>();

	/** Fraccion de la altura donde se sienta el jugador, calculada de la anatomia (data/prehistoric/models/<id>.json). */
	public static float seatFraction(Species s) { return SEAT.getOrDefault(s.id(), 0.7f); }

	public boolean flying() { return plan == Plan.FLYER; }
	public boolean aquatic() { return plan == Plan.AQUATIC; }
	public boolean small() { return height < 1.3f; }

	public static Species of(EntityType<?> type) { return BY_TYPE.get(type); }
	public static void bind(EntityType<?> type, Species s) { BY_TYPE.put(type, s); }

	public static void load() {
		if (!ALL.isEmpty()) return;
		try (InputStream in = Species.class.getResourceAsStream("/data/prehistoric/species.csv");
				BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
			r.readLine(); // cabecera
			String line;
			while ((line = r.readLine()) != null) {
				line = line.trim();
				if (line.isEmpty()) continue;
				String[] c = line.split(",");
				ALL.add(new Species(c[0], Plan.valueOf(c[1]), Float.parseFloat(c[2]), Float.parseFloat(c[3]),
						Double.parseDouble(c[4]), Double.parseDouble(c[5]), Double.parseDouble(c[6]),
						Double.parseDouble(c[7]), c[8].equals("1"), c[9].equals("1"), c[10].equals("1"),
						Integer.parseInt(c[11]), Integer.parseInt(c[12]), Integer.parseInt(c[13]), c[14],
						Integer.parseInt(c[15]), Integer.parseInt(c[16], 16), Integer.parseInt(c[17], 16),
						c[18].equals("1"), c[19].equals("1")));
			}
		} catch (Exception e) {
			throw new RuntimeException("No se pudo leer species.csv", e);
		}
		for (Species s : ALL) {
			try (InputStream in = Species.class.getResourceAsStream("/data/prehistoric/models/" + s.id() + ".json");
					BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
				JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
				SEAT.put(s.id(), Math.min(1.0f, o.get("seat_px").getAsFloat() / o.get("height_px").getAsFloat()));
			} catch (Exception e) {
				SEAT.put(s.id(), 0.7f);
			}
		}
	}
}
