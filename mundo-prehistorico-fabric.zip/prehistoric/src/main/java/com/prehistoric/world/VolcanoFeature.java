package com.prehistoric.world;

import com.mojang.serialization.Codec;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Volcan: cono de basalto con crater de lava. Se limita a 14 bloques de radio para no salir de la region de generacion. */
public class VolcanoFeature extends Feature<NoneFeatureConfiguration> {
	public VolcanoFeature(Codec<NoneFeatureConfiguration> codec) {
		super(codec);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
		WorldGenLevel level = ctx.level();
		RandomSource rnd = ctx.random();
		BlockPos o = ctx.origin();
		int cx = (o.getX() & ~15) + 8;
		int cz = (o.getZ() & ~15) + 8;
		int radius = 12 + rnd.nextInt(3);
		int height = 18 + rnd.nextInt(8);
		int craterRadius = 4;

		int baseY = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx, cz);
		if (level.getFluidState(new BlockPos(cx, baseY - 1, cz)).is(FluidTags.WATER)) return false;
		int peak = baseY + height;
		int craterFloor = peak - 8;

		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				double dist = Math.sqrt(dx * dx + dz * dz);
				if (dist > radius) continue;
				int x = cx + dx, z = cz + dz;
				int ground = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
				double t = 1.0 - dist / radius;
				int top = baseY + (int) (Math.pow(t, 0.8) * height);
				if (dist <= craterRadius) {
					// crater: se vacia hasta el fondo y se llena de lava
					for (int y = craterFloor + 1; y <= peak; y++) {
						level.setBlock(pos.set(x, y, z), Blocks.AIR.defaultBlockState(), 2);
					}
					for (int y = ground; y < craterFloor; y++) {
						level.setBlock(pos.set(x, y, z), rock(rnd), 2);
					}
					BlockState floor = dist < craterRadius - 1 ? Blocks.LAVA.defaultBlockState() : Blocks.MAGMA_BLOCK.defaultBlockState();
					level.setBlock(pos.set(x, craterFloor, z), floor, 2);
					continue;
				}
				for (int y = ground; y <= top; y++) {
					BlockState s = rock(rnd);
					if (y == top && rnd.nextInt(40) == 0) s = Blocks.LAVA.defaultBlockState(); // hilos de lava en la ladera
					level.setBlock(pos.set(x, y, z), s, 2);
				}
			}
		}
		return true;
	}

	private static BlockState rock(RandomSource rnd) {
		int r = rnd.nextInt(100);
		if (r < 45) return Blocks.BASALT.defaultBlockState();
		if (r < 75) return Blocks.BLACKSTONE.defaultBlockState();
		if (r < 90) return Blocks.SMOOTH_BASALT.defaultBlockState();
		if (r < 97) return Blocks.TUFF.defaultBlockState();
		return Blocks.MAGMA_BLOCK.defaultBlockState();
	}
}
