package com.prehistoric.world;

import com.mojang.serialization.Codec;
import com.prehistoric.ModRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Convierte la capa superior del bioma Volcan en tierra rojiza volcanica (nylium carmesi, netherrack, tierra gruesa, basalto). */
public class VolcanicGroundFeature extends Feature<NoneFeatureConfiguration> {
	private static final ResourceKey<Biome> VOLCANO = ResourceKey.create(Registries.BIOME, ModRegistry.id("volcano"));

	public VolcanicGroundFeature(Codec<NoneFeatureConfiguration> codec) {
		super(codec);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
		WorldGenLevel level = ctx.level();
		RandomSource rnd = ctx.random();
		int x0 = ctx.origin().getX() & ~15;
		int z0 = ctx.origin().getZ() & ~15;
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		boolean placed = false;
		for (int dx = 0; dx < 16; dx++) {
			for (int dz = 0; dz < 16; dz++) {
				int x = x0 + dx, z = z0 + dz;
				int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
				pos.set(x, y, z);
				if (!level.getBiome(pos).is(VOLCANO)) continue;
				BlockState state = level.getBlockState(pos);
				if (!(state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.DIRT) || state.is(Blocks.SAND) || state.is(Blocks.PODZOL)
						|| state.is(Blocks.COARSE_DIRT) || state.is(Blocks.GRAVEL) || state.is(Blocks.STONE))) continue;
				if (!level.getFluidState(pos.above()).isEmpty()) continue; // no bajo el agua
				level.setBlock(pos, top(rnd), 2);
				for (int d = 1; d <= 2; d++) {
					pos.set(x, y - d, z);
					BlockState under = level.getBlockState(pos);
					if (under.is(Blocks.DIRT) || under.is(Blocks.GRASS_BLOCK) || under.is(Blocks.SAND)) {
						level.setBlock(pos, rnd.nextInt(3) == 0 ? Blocks.NETHERRACK.defaultBlockState() : Blocks.COARSE_DIRT.defaultBlockState(), 2);
					}
				}
				placed = true;
			}
		}
		return placed;
	}

	private static BlockState top(RandomSource rnd) {
		int r = rnd.nextInt(100);
		if (r < 42) return Blocks.CRIMSON_NYLIUM.defaultBlockState();
		if (r < 56) return Blocks.NETHERRACK.defaultBlockState();
		if (r < 84) return Blocks.COARSE_DIRT.defaultBlockState();
		if (r < 94) return Blocks.BASALT.defaultBlockState();
		if (r < 98) return Blocks.SMOOTH_BASALT.defaultBlockState();
		return Blocks.MAGMA_BLOCK.defaultBlockState();
	}
}
