#!/usr/bin/env python3
"""Roca madre: mena, fragmento, lingote, armadura y herramientas (1.5x netherita), recetas de herreria y generacion."""
import json, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A, D = f"{RES}/assets/prehistoric", f"{RES}/data/prehistoric"
for p in ["textures/block", "models/block", "blockstates", "textures/item", "models/item", "items", "equipment", "lang",
          "textures/entity/equipment/humanoid", "textures/entity/equipment/humanoid_leggings"]:
    os.makedirs(f"{A}/{p}", exist_ok=True)
for p in ["recipe", "tags/item", "loot_table/blocks", "worldgen/configured_feature", "worldgen/placed_feature"]:
    os.makedirs(f"{D}/{p}", exist_ok=True)
os.makedirs(f"{RES}/data/minecraft/tags/block/mineable", exist_ok=True)

def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)

BASE, DARK, VEIN, GLOW = (46, 34, 62), (24, 16, 34), (150, 64, 225), (205, 140, 255)

# ---------- mena (piedra con vetas violeta brillantes)
rnd = random.Random(11)
img = Image.new("RGBA", (16, 16)); d = ImageDraw.Draw(img)
for y in range(16):
    for x in range(16):
        c = rnd.choice([(120, 120, 120), (108, 108, 108), (132, 130, 128), (100, 100, 104)])
        d.point((x, y), fill=c + (255,))
for _ in range(6):
    x, y = rnd.randint(1, 12), rnd.randint(1, 12)
    d.rectangle([x, y, x + 2, y + 2], fill=DARK + (255,))
    d.point((x + 1, y + 1), fill=VEIN + (255,)); d.point((x, y), fill=GLOW + (255,)); d.point((x + 2, y + 2), fill=VEIN + (255,))
img.save(f"{A}/textures/block/mother_rock_ore.png")
wj(f"{A}/models/block/mother_rock_ore.json", {"parent": "minecraft:block/cube_all", "textures": {"all": "prehistoric:block/mother_rock_ore"}})
wj(f"{A}/blockstates/mother_rock_ore.json", {"variants": {"": {"model": "prehistoric:block/mother_rock_ore"}}})
wj(f"{A}/items/mother_rock_ore.json", {"model": {"type": "minecraft:model", "model": "prehistoric:block/mother_rock_ore"}})

# ---------- iconos
def icon(name, fn):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); dd = ImageDraw.Draw(im); fn(dd); im.save(f"{A}/textures/item/{name}.png")
fill = lambda dd, r: (dd.rectangle(r, fill=BASE + (255,), outline=DARK + (255,)), dd.point((r[0] + 1, r[1] + 1), fill=GLOW + (255,)))
def stick(dd): dd.line([(3, 13), (11, 5)], fill=(90, 60, 35, 255), width=2)
icon("mother_rock_fragment", lambda dd: (dd.polygon([(8, 2), (13, 7), (10, 13), (4, 12), (3, 6)], fill=BASE + (255,), outline=DARK + (255,)),
    dd.line([(6, 6), (9, 10)], fill=VEIN + (255,)), dd.point((7, 5), fill=GLOW + (255,))))
icon("mother_rock_ingot", lambda dd: (dd.polygon([(2, 9), (6, 5), (14, 5), (10, 11), (2, 11)], fill=BASE + (255,), outline=DARK + (255,)),
    dd.line([(5, 8), (11, 8)], fill=VEIN + (255,)), dd.point((7, 7), fill=GLOW + (255,))))
icon("mother_rock_helmet", lambda dd: (fill(dd, (3, 4, 12, 9)), fill(dd, (3, 9, 5, 12)), fill(dd, (10, 9, 12, 12))))
icon("mother_rock_chestplate", lambda dd: (fill(dd, (2, 3, 13, 5)), fill(dd, (4, 5, 11, 13)), fill(dd, (1, 3, 3, 8)), fill(dd, (12, 3, 14, 8))))
icon("mother_rock_leggings", lambda dd: (fill(dd, (3, 2, 12, 6)), fill(dd, (3, 6, 6, 14)), fill(dd, (9, 6, 12, 14))))
icon("mother_rock_boots", lambda dd: (fill(dd, (2, 7, 6, 13)), fill(dd, (9, 7, 13, 13)), fill(dd, (1, 11, 6, 13)), fill(dd, (9, 11, 14, 13))))
icon("mother_rock_sword", lambda dd: (dd.line([(3, 13), (6, 10)], fill=(90, 60, 35, 255), width=2),
    dd.line([(6, 10), (13, 3)], fill=BASE + (255,), width=3), dd.line([(7, 9), (13, 3)], fill=VEIN + (255,)), dd.line([(4, 9), (8, 13)], fill=DARK + (255,))))
icon("mother_rock_pickaxe", lambda dd: (stick(dd), dd.arc([2, 1, 14, 11], 200, 340, fill=BASE + (255,), width=3), dd.point((8, 2), fill=GLOW + (255,))))
icon("mother_rock_axe", lambda dd: (stick(dd), fill(dd, (8, 2, 13, 7)), dd.point((10, 3), fill=GLOW + (255,))))
icon("mother_rock_shovel", lambda dd: (stick(dd), fill(dd, (9, 1, 13, 6)), dd.point((10, 2), fill=GLOW + (255,))))
icon("mother_rock_hoe", lambda dd: (stick(dd), fill(dd, (7, 2, 13, 4)), dd.point((12, 3), fill=GLOW + (255,))))

names = ["mother_rock_fragment", "mother_rock_ingot", "mother_rock_helmet", "mother_rock_chestplate", "mother_rock_leggings",
         "mother_rock_boots", "mother_rock_sword", "mother_rock_pickaxe", "mother_rock_axe", "mother_rock_shovel", "mother_rock_hoe"]
for n in names:
    handheld = n.endswith(("sword", "pickaxe", "axe", "shovel", "hoe"))
    wj(f"{A}/models/item/{n}.json", {"parent": "item/handheld" if handheld else "item/generated", "textures": {"layer0": f"prehistoric:item/{n}"}})
    wj(f"{A}/items/{n}.json", {"model": {"type": "minecraft:model", "model": f"prehistoric:item/{n}"}})

# ---------- textura de armadura puesta
arm = Image.new("RGBA", (64, 32), BASE + (255,)); ad = ImageDraw.Draw(arm); r2 = random.Random(5)
for _ in range(120):
    x, y = r2.randrange(64), r2.randrange(32)
    ad.rectangle([x, y, x + r2.randint(1, 3), y], fill=r2.choice([DARK, VEIN, BASE, GLOW]) + (255,))
for sub in ("humanoid", "humanoid_leggings"):
    arm.save(f"{A}/textures/entity/equipment/{sub}/mother_rock.png")
wj(f"{A}/equipment/mother_rock.json", {"layers": {"humanoid": [{"texture": "prehistoric:mother_rock"}], "humanoid_leggings": [{"texture": "prehistoric:mother_rock"}]}})

# ---------- recetas
wj(f"{D}/tags/item/repairs_mother_rock.json", {"values": ["prehistoric:mother_rock_ingot"]})
wj(f"{D}/recipe/mother_rock_ingot.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
    "ingredients": ["prehistoric:mother_rock_fragment", "prehistoric:mother_rock_fragment"], "result": {"id": "prehistoric:mother_rock_ingot", "count": 1}})
for piece in ("helmet", "chestplate", "leggings", "boots", "sword", "pickaxe", "axe", "shovel", "hoe"):
    wj(f"{D}/recipe/mother_rock_{piece}_smithing.json", {"type": "minecraft:smithing_transform",
        "template": "minecraft:netherite_upgrade_smithing_template", "base": f"minecraft:netherite_{piece}",
        "addition": "prehistoric:mother_rock_ingot", "result": {"id": f"prehistoric:mother_rock_{piece}", "count": 1}})

# ---------- mineria: pico de diamante o mejor
wj(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", {"replace": False, "values": ["prehistoric:mother_rock_ore"]})
wj(f"{RES}/data/minecraft/tags/block/needs_diamond_tool.json", {"replace": False, "values": ["prehistoric:mother_rock_ore"]})
wj(f"{D}/loot_table/blocks/mother_rock_ore.json", {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:alternatives", "children": [
    {"type": "minecraft:item", "name": "prehistoric:mother_rock_ore", "conditions": [{"condition": "minecraft:match_tool", "predicate": {
        "predicates": {"minecraft:enchantments": [{"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}]},
    {"type": "minecraft:item", "name": "prehistoric:mother_rock_fragment", "functions": [
        {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"},
        {"function": "minecraft:explosion_decay"}]}]}]}]})

# ---------- generacion: misma frecuencia/altura que el diamante (7 vetas de tamano 4 por chunk)
wj(f"{D}/worldgen/configured_feature/ore_mother_rock.json", {"type": "minecraft:ore", "config": {"size": 4, "discard_chance_on_air_exposure": 0.5,
    "targets": [
        {"target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:stone_ore_replaceables"}, "state": {"Name": "prehistoric:mother_rock_ore"}},
        {"target": {"predicate_type": "minecraft:tag_match", "tag": "minecraft:deepslate_ore_replaceables"}, "state": {"Name": "prehistoric:mother_rock_ore"}}]}})
wj(f"{D}/worldgen/placed_feature/ore_mother_rock.json", {"feature": "prehistoric:ore_mother_rock", "placement": [
    {"type": "minecraft:count", "count": 7}, {"type": "minecraft:in_square"},
    {"type": "minecraft:height_range", "height": {"type": "minecraft:trapezoid", "min_inclusive": {"above_bottom": -80}, "max_inclusive": {"above_bottom": 80}}},
    {"type": "minecraft:biome"}]})

# ---------- idiomas
es = {"block.prehistoric.mother_rock_ore": "Mena de roca madre", "item.prehistoric.mother_rock_fragment": "Fragmento de roca madre",
      "item.prehistoric.mother_rock_ingot": "Lingote de roca madre", "item.prehistoric.mother_rock_helmet": "Casco de roca madre",
      "item.prehistoric.mother_rock_chestplate": "Peto de roca madre", "item.prehistoric.mother_rock_leggings": "Pantalones de roca madre",
      "item.prehistoric.mother_rock_boots": "Botas de roca madre", "item.prehistoric.mother_rock_sword": "Espada de roca madre",
      "item.prehistoric.mother_rock_pickaxe": "Pico de roca madre", "item.prehistoric.mother_rock_axe": "Hacha de roca madre",
      "item.prehistoric.mother_rock_shovel": "Pala de roca madre", "item.prehistoric.mother_rock_hoe": "Azada de roca madre"}
en = {"block.prehistoric.mother_rock_ore": "Mother Rock Ore", "item.prehistoric.mother_rock_fragment": "Mother Rock Fragment",
      "item.prehistoric.mother_rock_ingot": "Mother Rock Ingot", "item.prehistoric.mother_rock_helmet": "Mother Rock Helmet",
      "item.prehistoric.mother_rock_chestplate": "Mother Rock Chestplate", "item.prehistoric.mother_rock_leggings": "Mother Rock Leggings",
      "item.prehistoric.mother_rock_boots": "Mother Rock Boots", "item.prehistoric.mother_rock_sword": "Mother Rock Sword",
      "item.prehistoric.mother_rock_pickaxe": "Mother Rock Pickaxe", "item.prehistoric.mother_rock_axe": "Mother Rock Axe",
      "item.prehistoric.mother_rock_shovel": "Mother Rock Shovel", "item.prehistoric.mother_rock_hoe": "Mother Rock Hoe"}
for code, d in (("es_es", es), ("en_us", en)):
    path = f"{A}/lang/{code}.json"; lang = json.load(open(path, encoding="utf-8")); lang.update(d); wj(path, lang)
print("OK roca madre")
