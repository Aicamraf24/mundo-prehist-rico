#!/usr/bin/env python3
"""Dimension, biomas, volcan, armadura de escamas, ambar y escamas. Ejecutar despues de generate_assets.py."""
import csv, json, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A, D = f"{RES}/assets/prehistoric", f"{RES}/data/prehistoric"
for p in ["textures/entity/equipment/humanoid", "textures/entity/equipment/humanoid_leggings", "equipment", "textures/item", "models/item", "items", "lang"]:
    os.makedirs(f"{A}/{p}", exist_ok=True)
for p in ["worldgen/biome", "worldgen/configured_feature", "worldgen/placed_feature", "dimension", "recipe", "tags/item", "tags/worldgen/biome/habitat", "loot_table/entities"]:
    os.makedirs(f"{D}/{p}", exist_ok=True)

def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)

# ------------------------------------------------------------------ texturas
BASE, DARK, LIGHT = (150, 70, 55), (95, 40, 32), (200, 115, 88)
def scale_pattern(img, box=None):
    d = ImageDraw.Draw(img); w, h = img.size; rnd = random.Random(3)
    for y in range(0, h, 3):
        for x in range(-3 + (3 if (y // 3) % 2 else 0), w, 6):
            d.ellipse([x, y, x + 5, y + 4], fill=BASE + (255,), outline=DARK + (255,))
            d.point((x + 2, y + 1), fill=LIGHT + (255,))
    return img
for sub in ("humanoid", "humanoid_leggings"):
    scale_pattern(Image.new("RGBA", (64, 32))).save(f"{A}/textures/entity/equipment/{sub}/scale.png")
wj(f"{A}/equipment/scale.json", {"layers": {"humanoid": [{"texture": "prehistoric:scale"}], "humanoid_leggings": [{"texture": "prehistoric:scale"}]}})

def icon(name, draw_fn):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img); draw_fn(d); img.save(f"{A}/textures/item/{name}.png")
def piece(d, rects):
    for r in rects:
        d.rectangle(r, fill=BASE + (255,), outline=DARK + (255,))
        d.point((r[0] + 1, r[1] + 1), fill=LIGHT + (255,))
icon("dino_scale", lambda d: (d.ellipse([3, 3, 12, 13], fill=BASE + (255,), outline=DARK + (255,)), d.line([(8, 4), (8, 12)], fill=DARK + (255,)), d.point((6, 6), fill=LIGHT + (255,))))
icon("scale_helmet", lambda d: piece(d, [(3, 4, 12, 9), (3, 9, 5, 12), (10, 9, 12, 12)]))
icon("scale_chestplate", lambda d: piece(d, [(2, 3, 13, 5), (4, 5, 11, 13), (1, 3, 3, 8), (12, 3, 14, 8)]))
icon("scale_leggings", lambda d: piece(d, [(3, 2, 12, 6), (3, 6, 6, 14), (9, 6, 12, 14)]))
icon("scale_boots", lambda d: piece(d, [(2, 7, 6, 13), (9, 7, 13, 13), (1, 11, 6, 13), (9, 11, 14, 13)]))
def amber(d):
    d.polygon([(8, 1), (14, 6), (12, 14), (4, 14), (2, 6)], fill=(230, 150, 30, 255), outline=(130, 70, 10, 255))
    d.polygon([(8, 3), (11, 6), (8, 8), (5, 6)], fill=(255, 205, 90, 255)); d.rectangle([6, 9, 7, 11], fill=(90, 50, 10, 255))
icon("jurassic_amber", amber)

for n in ["dino_scale", "scale_helmet", "scale_chestplate", "scale_leggings", "scale_boots", "jurassic_amber"]:
    wj(f"{A}/models/item/{n}.json", {"parent": "item/generated", "textures": {"layer0": f"prehistoric:item/{n}"}})
    wj(f"{A}/items/{n}.json", {"model": {"type": "minecraft:model", "model": f"prehistoric:item/{n}"}})

# ------------------------------------------------------------------ recetas
S = "prehistoric:dino_scale"
shaped = lambda pat, res: {"type": "minecraft:crafting_shaped", "category": "equipment", "key": {"#": S}, "pattern": pat, "result": {"id": res, "count": 1}}
wj(f"{D}/recipe/scale_helmet.json", shaped(["###", "# #"], "prehistoric:scale_helmet"))
wj(f"{D}/recipe/scale_chestplate.json", shaped(["# #", "###", "###"], "prehistoric:scale_chestplate"))
wj(f"{D}/recipe/scale_leggings.json", shaped(["###", "# #", "# #"], "prehistoric:scale_leggings"))
wj(f"{D}/recipe/scale_boots.json", shaped(["# #", "# #"], "prehistoric:scale_boots"))
wj(f"{D}/recipe/jurassic_amber.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
    "ingredients": [S, S, "minecraft:gold_ingot", "minecraft:glowstone_dust"], "result": {"id": "prehistoric:jurassic_amber", "count": 1}})
wj(f"{D}/tags/item/repairs_scale_armor.json", {"values": ["prehistoric:dino_scale"]})

# ------------------------------------------------------------------ loot: carne + escamas
for row in csv.DictReader(open(f"{RES}/data/prehistoric/species.csv", encoding="utf-8")):
    pool = lambda item, lo, hi: {"rolls": 1, "entries": [{"type": "minecraft:item", "name": item, "functions": [
        {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]}]}
    wj(f"{D}/loot_table/entities/{row['id']}.json", {"type": "minecraft:entity", "pools": [pool("prehistoric:dino_meat", 1, 3), pool("prehistoric:dino_scale", 0, 2)]})

# ------------------------------------------------------------------ volcan
wj(f"{D}/worldgen/configured_feature/volcano.json", {"type": "prehistoric:volcano", "config": {}})
wj(f"{D}/worldgen/placed_feature/volcano.json", {"feature": "prehistoric:volcano", "placement": [
    {"type": "minecraft:rarity_filter", "chance": 5}, {"type": "minecraft:in_square"}, {"type": "minecraft:biome"}]})

# ------------------------------------------------------------------ biomas
ORES = ["minecraft:ore_coal_upper", "minecraft:ore_coal_lower", "minecraft:ore_iron_upper", "minecraft:ore_iron_middle",
        "minecraft:ore_gold", "minecraft:ore_redstone", "minecraft:ore_diamond", "minecraft:ore_lapis", "minecraft:ore_copper",
        "minecraft:ore_dirt", "minecraft:ore_gravel", "prehistoric:ore_mother_rock"]
def argb(rgb):
    """Color RGB -> entero ARGB opaco (con signo, como lo guarda el JSON). Sin alfa el agua se renderiza invisible."""
    v = 0xFF000000 | rgb
    return v - (1 << 32) if v >= (1 << 31) else v

def biome(name, temp, down, sky, fog, water, vegetal=(), surface=(), precip=True):
    steps = [[] for _ in range(11)]
    steps[4] = list(surface); steps[6] = ORES; steps[8] = ["minecraft:spring_water", "minecraft:spring_lava"]; steps[9] = list(vegetal)
    wj(f"{D}/worldgen/biome/{name}.json", {
        "has_precipitation": precip, "temperature": temp, "downfall": down,
        "attributes": {"minecraft:visual/sky_color": sky, "minecraft:visual/fog_color": fog, "minecraft:visual/water_fog_color": "#050533"},
        "effects": {"water_color": argb(water)},
        "carvers": ["minecraft:cave", "minecraft:cave_extra_underground", "minecraft:canyon"],
        "features": steps, "spawners": {}, "spawn_costs": {}})
biome("jurassic_jungle", 0.95, 0.9, "#6fb2ff", "#c0e0d0", 0x1E9BC4, ["minecraft:trees_jungle", "minecraft:patch_grass_jungle"])
biome("fossil_forest", 0.8, 0.5, "#8fb0d8", "#d8d0b8", 0x3F76E4, ["minecraft:trees_savanna", "minecraft:patch_grass_savanna"])
biome("volcano", 2.0, 0.0, "#6a3d30", "#5a3428", 0x4A5A7A, [], ["prehistoric:volcano"], precip=False)
biome("jurassic_swamp", 0.8, 0.9, "#78a7a0", "#a0c0a8", 0x4F7A5A, ["minecraft:trees_swamp", "minecraft:patch_waterlily"])
biome("prehistoric_plains", 0.8, 0.4, "#78a7ff", "#c0d8ff", 0x3F76E4, ["minecraft:trees_plains", "minecraft:patch_grass_plain", "minecraft:flower_plains"])
biome("prehistoric_sea", 0.6, 0.5, "#6fa8ff", "#c0d8ff", 0x2B5FD0, [])

# ------------------------------------------------------------------ dimension (tipo y ruido del Overworld, biomas propios)
def mn(biome_id, t, h, c, e, w):
    return {"biome": f"prehistoric:{biome_id}", "parameters": {"temperature": t, "humidity": h, "continentalness": c, "erosion": e, "depth": 0.0, "weirdness": w, "offset": 0.0}}
wj(f"{D}/dimension/jurassic.json", {"type": "minecraft:overworld", "generator": {"type": "minecraft:noise", "settings": "minecraft:overworld",
    "biome_source": {"type": "minecraft:multi_noise", "biomes": [
        mn("prehistoric_sea", [-1.0, 1.0], [-1.0, 1.0], [-1.2, -0.19], [-1.0, 1.0], [-1.0, 1.0]),
        mn("jurassic_jungle", [0.2, 1.0], [0.1, 1.0], [-0.19, 1.0], [-1.0, 0.3], [-1.0, 1.0]),
        mn("jurassic_swamp", [-0.2, 0.6], [0.3, 1.0], [-0.19, 0.1], [0.3, 1.0], [-1.0, 1.0]),
        mn("fossil_forest", [-0.3, 0.5], [-1.0, 0.2], [-0.19, 1.0], [-1.0, 1.0], [-1.0, 1.0]),
        mn("volcano", [0.5, 1.0], [-1.0, -0.2], [0.2, 1.0], [-1.0, 1.0], [-1.0, 1.0]),
        mn("prehistoric_plains", [-1.0, 0.3], [-0.3, 0.6], [-0.19, 1.0], [-1.0, 1.0], [-1.0, 1.0])]}}})

# Habitats: los dinosaurios viven solo en la dimension prehistorica
HAB = {"jungle": ["jurassic_jungle"], "forest": ["fossil_forest"], "swamp": ["jurassic_swamp"],
       "plains": ["prehistoric_plains"], "savanna": ["fossil_forest", "prehistoric_plains"],
       "badlands": ["volcano"], "river": ["jurassic_swamp"], "ocean": ["prehistoric_sea"]}
for h, ids in HAB.items():
    wj(f"{D}/tags/worldgen/biome/habitat/{h}.json", {"replace": True, "values": [f"prehistoric:{i}" for i in ids]})

# ------------------------------------------------------------------ idiomas
for code, d in (("es_es", {"item.prehistoric.dino_scale": "Escama de dinosaurio", "item.prehistoric.scale_helmet": "Casco de escamas",
        "item.prehistoric.scale_chestplate": "Peto de escamas", "item.prehistoric.scale_leggings": "Pantalones de escamas",
        "item.prehistoric.scale_boots": "Botas de escamas", "item.prehistoric.jurassic_amber": "Ámbar Jurásico"}),
        ("en_us", {"item.prehistoric.dino_scale": "Dinosaur Scale", "item.prehistoric.scale_helmet": "Scale Helmet",
        "item.prehistoric.scale_chestplate": "Scale Chestplate", "item.prehistoric.scale_leggings": "Scale Leggings",
        "item.prehistoric.scale_boots": "Scale Boots", "item.prehistoric.jurassic_amber": "Jurassic Amber"})):
    path = f"{A}/lang/{code}.json"; lang = json.load(open(path, encoding="utf-8")); lang.update(d)
    wj(path, lang)
print("OK extras")
