#!/bin/sh
# Regenera todos los assets en el orden correcto
set -e
cd "$(dirname "$0")/.."
python3 tools/generate_assets.py
python3 tools/generate_extras.py
python3 tools/generate_mother_rock.py
python3 tools/textures_v2.py
python3 tools/generate_spawn_eggs.py
