#!/usr/bin/env python3
"""Genera la anatomia de cada especie (cuerpo, cuello en tramos, craneo + hocico + mandibula, cola en tramos, patas de 3 tramos,
cuernos, golas, placas, espinas, mazas, alas...) y la guarda en data/prehistoric/models/<id>.json. Java y el pintor de texturas
leen ese mismo archivo, asi modelo y textura siempre coinciden. Proporciones basadas en anatomia paleontologica (la usada en
las peliculas de Jurassic World), no en copias de sus modelos."""
import csv, json, math, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
OUT = f"{RES}/data/prehistoric/models"
os.makedirs(OUT, exist_ok=True)
rows = {r["id"]: r for r in csv.DictReader(open(f"{RES}/data/prehistoric/species.csv", encoding="utf-8"))}
I = lambda v: max(1, int(round(v)))

class Spec:
    def __init__(self): self.parts = []
    def add(self, name, parent, kind, box, pivot=(0, 0, 0), rot=(0, 0, 0)):
        x, y, z, w, h, d = box
        self.parts.append(dict(name=name, parent=parent, kind=kind, box=[round(x, 2), round(y, 2), round(z, 2), I(w), I(h), I(d)],
                               pivot=[round(v, 2) for v in pivot], rot=[round(v, 3) for v in rot]))

# --------------------------------------------------------------------------- bloques de construccion
def head(S, parent, pivot, rot, P):
    """Craneo + hocico alargado + mandibula inferior articulada."""
    hw, hh, hd, sl, sw, snh = P["hw"], P["hh"], P["hd"], P["sl"], P["sw"], P["snh"]
    S.add("head", parent, "head", (-hw / 2, -hh * 0.55, -hd * 0.85, hw, hh, hd), pivot, rot)
    S.add("snout", "head", "snout", (-sw / 2, -snh * 0.5, -sl, sw, snh, sl), (0, hh * 0.02, -hd * 0.85))
    jh = max(2, snh * 0.34)
    S.add("jaw", "head", "jaw", (-max(2, sw * 0.82) / 2, 0, -(sl + hd * 0.5), max(2, sw * 0.82), jh, sl + hd * 0.5), (0, hh * 0.18, -hd * 0.3))

def neck(S, parent, base, segs, angs, head_P, head_rot_extra=0.0):
    """Cadena de tramos de cuello (hacia arriba y adelante) y cabeza al final."""
    par, piv, prev_len, total = parent, base, 0, 0.0
    for i, ((ln, th), a) in enumerate(zip(segs, angs)):
        name = f"neck{i + 1}"
        S.add(name, par, "skin", (-th / 2, -ln, -th / 2, th, ln, th), piv, (a, 0, 0))
        par, piv, total = name, (0, -ln, 0), total + a
    head(S, par, piv, (-total + head_rot_extra, 0, 0), head_P)

def tail(S, parent, pivot, lens, widths, heights, rots, kind="skin"):
    par, piv = parent, pivot
    for i, (ln, w, h, r) in enumerate(zip(lens, widths, heights, rots)):
        name = f"tail{i + 1}"
        S.add(name, par, kind, (-w / 2, -h / 2, 0, w, h, ln), piv, (r, 0, 0))
        par, piv = name, (0, 0, ln)

def bip_legs(S, hip_y, x, z, th, sn, ft, w, a0=-0.7, a1=1.3, toe_w=None):
    toe_w = toe_w or w * 1.2
    for s, sx in (("l", -1), ("r", 1)):
        n = f"leg_b{s}"
        S.add(n, None, "skin", (-w / 2, 0, -w / 2, w, th, w), (sx * x, hip_y, z), (a0, 0, 0))
        S.add(n + "2", n, "skin", (-w * 0.4, 0, -w * 0.4, w * 0.8, sn, w * 0.8), (0, th, 0), (a1, 0, 0))
        S.add(n + "3", n + "2", "foot", (-toe_w / 2, -w * 0.5, -ft, toe_w, w * 0.5, ft + w * 0.3), (0, sn, 0), (-(a0 + a1), 0, 0))
    return hip_y

def bip_height(th, sn, a0=-0.7, a1=1.3): return th * math.cos(a0) + sn * math.cos(a0 + a1)

def arms(S, y, x, z, al, fl, aw, claw=0, a0=-0.5, a1=-1.0):
    for s, sx in (("l", -1), ("r", 1)):
        n = f"leg_f{s}"
        S.add(n, None, "skin", (-aw / 2, 0, -aw / 2, aw, al, aw), (sx * x, y, z), (a0, 0, 0))
        S.add(n + "2", n, "skin", (-aw * 0.4, 0, -aw * 0.4, aw * 0.8, fl, aw * 0.8), (0, al, 0), (a1, 0, 0))
        if claw: S.add(n + "3", n + "2", "bone", (-aw * 0.25, 0, -aw * 0.25, max(1, aw * 0.5), claw, max(1, aw * 0.5)), (0, fl, 0), (0.3, 0, 0))

def quad_legs(S, bw, bd, hip_f, hip_b, lf, lr, wf, wr, ang_b=(-0.3, 0.55), foot=True):
    for s, sx in (("l", -1), ("r", 1)):
        for tag, hy, ln, w, z, (a0, a1) in (("f", hip_f, lf, wf, -bd * 0.33, (0.0, 0.0)), ("b", hip_b, lr, wr, bd * 0.33, ang_b)):
            n = f"leg_{tag}{s}"
            up, lo = ln * 0.52, ln * 0.48
            S.add(n, None, "skin", (-w / 2, 0, -w / 2, w, up, w), (sx * bw * 0.42, hy, z), (a0, 0, 0))
            S.add(n + "2", n, "skin", (-w * 0.42, 0, -w * 0.42, w * 0.84, lo, w * 0.84), (0, up, 0), (a1, 0, 0))
            if foot: S.add(n + "3", n + "2", "foot", (-w * 0.55, -w * 0.45, -w * 0.9, w * 1.1, w * 0.45, w * 1.2), (0, lo, 0), (-(a0 + a1), 0, 0))

def quad_h(ln, a0, a1): return ln * 0.52 * math.cos(a0) + ln * 0.48 * math.cos(a0 + a1)

def saddle(S, bh, bw, bd):
    S.add("saddle", "body", "saddle", (-min(bw * 0.8, 12) / 2, -3, -min(bd * 0.28, 7), min(bw * 0.8, 12), 3, min(bd * 0.56, 14)), (0, -bh / 2, -bd * 0.02))

def ridge(S, parent, n, z0, z1, hmax, t, y, kind="plate", prof=None, depth=None, tilt=0.0):
    for i in range(n):
        f = i / max(n - 1, 1)
        h = hmax * (prof(f) if prof else math.sin(math.pi * (0.15 + 0.7 * f)))
        z = z0 + (z1 - z0) * f
        dd = depth or max(3, (z1 - z0) / max(n, 1) * 0.9)
        S.add(f"{parent}_{kind}{i}", parent, kind, (-t / 2, -h, -dd / 2, t, max(2, h), dd), (0, y, z), (0, 0, tilt))

# --------------------------------------------------------------------------- arquetipos
def build_bip(S, P):
    a0, a1 = P.get("a", (-0.7, 1.3))
    leg_h = bip_height(P["th"], P["sn"], a0, a1)
    hip_y = 24 - leg_h
    bw, bh, bd = P["bw"], P["bh"], P["bd"]
    yb = hip_y - bh * P.get("lift", 0.18)
    S.add("body", None, "skin", (-bw / 2, -bh / 2, -bd * 0.5, bw, bh, bd), (0, yb, -bd * 0.05), (P.get("pitch", 0.0), 0, 0))
    saddle(S, bh, bw, bd)
    bip_legs(S, hip_y, bw * 0.5 + P["lw"] * 0.1, 0, P["th"], P["sn"], P["ft"], P["lw"], a0, a1, P.get("toe"))
    if P.get("arm"): arms(S, yb - bh * 0.05, bw * 0.5, -bd * 0.42, *P["arm"])
    neck(S, None, (0, yb - bh * 0.28, -bd * 0.5 - bd * 0.05 + 2), P["neck"], P["nang"], P)
    L = P["tl"]
    tail(S, None, (0, yb - bh * 0.04, bd * 0.45 - bd * 0.05), [L * 0.38, L * 0.34, L * 0.28], [P["tw"], P["tw"] * 0.7, P["tw"] * 0.42],
         [P["tt"], P["tt"] * 0.72, P["tt"] * 0.45], [P.get("tr", -0.04), 0.02, 0.04])
    return dict(sit=leg_h * 0.5, hip=yb)

def build_quad(S, P):
    bw, bh, bd = P["bw"], P["bh"], P["bd"]
    af, ab = P.get("af", (0, 0)), P.get("ab", (-0.3, 0.55))
    hf, hb = quad_h(P["lf"], *af), quad_h(P["lr"], *ab)
    hip_f, hip_b = 24 - hf, 24 - hb
    yb = min(hip_f, hip_b) - bh * 0.3
    S.add("body", None, "skin", (-bw / 2, -bh / 2, -bd * 0.5, bw, bh, bd), (0, yb, 0), (-math.atan2(hip_b - hip_f, bd) * 0.8, 0, 0))
    saddle(S, bh, bw, bd)
    quad_legs(S, bw, bd, hip_f, hip_b, P["lf"], P["lr"], P["wf"], P["wr"], ab)
    neck(S, None, (0, yb - bh * 0.1, -bd * 0.5 + 2), P["neck"], P["nang"], P)
    L = P["tl"]
    tail(S, None, (0, yb - bh * 0.05, bd * 0.5 - 2), [L * 0.4, L * 0.33, L * 0.27], [P["tw"], P["tw"] * 0.7, P["tw"] * 0.45],
         [P["tt"], P["tt"] * 0.7, P["tt"] * 0.45], [P.get("tr", 0.05), 0.02, 0.03])
    return dict(sit=min(hf, hb) * 0.55, hip=yb)

def build_sauro(S, P):
    P.setdefault("ab", (-0.15, 0.3))
    return build_quad(S, P)

def build_flyer(S, P):
    bw, bh, bd = P["bw"], P["bh"], P["bd"]
    yb = 24 - P["lh"] - bh * 0.5
    S.add("body", None, "skin", (-bw / 2, -bh / 2, -bd * 0.5, bw, bh, bd), (0, yb, 0), (-0.15, 0, 0))
    saddle(S, bh, bw, bd)
    neck(S, None, (0, yb - bh * 0.2, -bd * 0.5 + 1), P["neck"], P["nang"], P)
    tail(S, None, (0, yb, bd * 0.5 - 1), [P["tl"]], [P["tw"]], [P["tw"]], [0.05])
    for s, sx in (("l", -1), ("r", 1)):
        n = f"wing_{s}"
        S.add(n, None, "skin", (-bw * 0.1 if sx > 0 else -P["wa"], -1.5, -3, P["wa"], 3, 6), (sx * bw * 0.45, yb - bh * 0.3, -bd * 0.15), (0, 0, 0))
        S.add(n + "2", n, "membrane", ((0 if sx > 0 else -P["wb"]) + (bw * 0.0), -0.5, -P["wc"] * 0.25, P["wb"], 1, P["wc"]), (sx * (P["wa"] - bw * 0.1), 0, 0))
        S.add(f"leg_b{s}", None, "skin", (-1, 0, -1, 2, P["lh"], 2), (sx * bw * 0.25, yb + bh * 0.4, bd * 0.2), (0.3, 0, 0))
    return dict(sit=1.0, hip=yb)

def build_aqua(S, P):
    bw, bh, bd = P["bw"], P["bh"], P["bd"]
    yb = 16
    S.add("body", None, "skin", (-bw / 2, -bh / 2, -bd * 0.5, bw, bh, bd), (0, yb, 0))
    saddle(S, bh, bw, bd)
    neck(S, None, (0, yb - bh * 0.05, -bd * 0.5 + 2), P["neck"], P["nang"], P)
    L = P["tl"]
    tail(S, None, (0, yb, bd * 0.5 - 2), [L * 0.4, L * 0.35, L * 0.25], [P["tw"] * 0.9, P["tw"] * 0.6, P["tw"] * 0.25],
         [P["tt"], P["tt"] * 0.9, P["tt"] * 1.3], [0.0, 0.0, 0.0])
    for s, sx in (("l", -1), ("r", 1)):
        for tag, z in (("f", -bd * 0.28), ("b", bd * 0.28)):
            x0 = 0 if sx > 0 else -P["fl"]
            S.add(f"leg_{tag}{s}", None, "membrane", (x0, 0, -P["fw"] / 2, P["fl"], 1, P["fw"]), (sx * bw * 0.45, yb + bh * 0.3, z), (0, 0, 0))
    return dict(sit=2.0, hip=yb)

# --------------------------------------------------------------------------- decoraciones
def deco(S, kind, P):
    hw, hh, hd = P["hw"], P["hh"], P["hd"]
    if kind == "triceratops":
        S.add("frill", "head", "plate", (-hw * 1.2, -hh * 1.0, -2, hw * 2.4, hh * 1.7, 3), (0, -hh * 0.2, hd * 0.2), (-0.45, 0, 0))
        for s, sx in (("l", -1), ("r", 1)):
            S.add(f"brow_{s}", "head", "horn", (-1.5, -1.5, -P.get("hl", 20), 3, 3, P.get("hl", 20)), (sx * hw * 0.32, -hh * 0.4, -hd * 0.45), (-0.3, 0, sx * 0.12))
        S.add("nose_horn", "snout", "horn", (-1.5, -1.5, -7, 3, 3, 7), (0, -P["snh"] * 0.5, -P["sl"] * 0.8), (-0.5, 0, 0))
    elif kind == "protoceratops":
        S.add("frill", "head", "plate", (-hw * 1.0, -hh * 0.8, -2, hw * 2.0, hh * 1.4, 2), (0, -hh * 0.2, hd * 0.2), (-0.5, 0, 0))
    elif kind == "carnotaurus":
        for s, sx in (("l", -1), ("r", 1)):
            S.add(f"horn_{s}", "head", "horn", (-1.5, -7, -1.5, 3, 7, 3), (sx * hw * 0.4, -hh * 0.5, -hd * 0.3), (0.35, 0, sx * 0.25))
    elif kind == "brow":
        for s, sx in (("l", -1), ("r", 1)):
            S.add(f"brow_{s}", "head", "bone", (-1.5, -2, -4, 3, 2, 5), (sx * hw * 0.3, -hh * 0.5, -hd * 0.55))
    elif kind == "dilophosaurus":
        for s, sx in (("l", -1), ("r", 1)):
            S.add(f"hcrest_{s}", "head", "plate", (-0.5, -hh * 0.9, -hd * 0.55, 1, hh * 0.9, hd * 0.7), (sx * hw * 0.2, -hh * 0.5, 0), (0, 0, sx * 0.15))
    elif kind == "dome":
        S.add("dome", "head", "bone", (-hw * 0.46, -hh * 0.5, -hd * 0.55, hw * 0.92, hh * 0.5, hd * 0.65), (0, -hh * 0.5, 0))
    elif kind == "parasaur":
        S.add("tube", "head", "plate", (-hw * 0.25, -hw * 0.25, 0, hw * 0.5, hw * 0.5, P.get("cl", 26)), (0, -hh * 0.45, -hd * 0.3), (0.35, 0, 0))
    elif kind == "pteranodon":
        S.add("hcrest", "head", "plate", (-0.8, -hh * 0.6, 0, 2, hh * 0.6, P.get("cl", 22)), (0, -hh * 0.3, hd * 0.1), (0.4, 0, 0))
    elif kind == "dimo_frill":
        S.add("hcrest", "head", "plate", (-0.8, -4, -6, 2, 5, 10), (0, -hh * 0.5, -hd * 0.1))
    elif kind == "therizino":
        pass

def sail(S, P, n, hmax, z0, z1, kind="plate", prof=None, t=1.4, parent="body", y=None):
    ridge(S, parent, n, z0, z1, hmax, t, y if y is not None else -P["bh"] / 2 + 1, kind, prof)

def back_plates(S, P, n, hmax, rows2=False):
    bd, bh = P["bd"], P["bh"]
    for r in ((-1, 1) if rows2 else (0,)):
        for i in range(n):
            f = i / max(n - 1, 1)
            h = hmax * (0.45 + 0.55 * math.sin(math.pi * (0.1 + 0.8 * f)))
            z = -bd * 0.4 + bd * 0.95 * f
            S.add(f"plate_{r}_{i}", "body", "plate", (-1, -h, -3.2, 2, h, 6), (r * bd * 0.0 + r * 2.2, -bh / 2 + 1, z), (0, 0, r * 0.28))

def tail_spikes(S, n, ln, tail_name="tail3"):
    for i in range(n):
        s = -1 if i % 2 == 0 else 1
        S.add(f"spike{i}", tail_name, "bone", (-1, -ln, -1, 2, ln, 2), (0, -1, 3 + i * 3), (0, 0, s * 0.9))

def knobs(S, P, nz=4, nx=3):
    bw, bh, bd = P["bw"], P["bh"], P["bd"]
    for i in range(nz):
        for j in range(nx):
            x = (j - (nx - 1) / 2) * bw * 0.28
            z = -bd * 0.38 + i * bd * 0.24
            S.add(f"knob{i}_{j}", "body", "armor", (-2, -3, -2, 4, 3, 4), (x, -bh / 2 + 0.5, z))
    for s, sx in (("l", -1), ("r", 1)):
        S.add(f"flank_spike_{s}", "body", "bone", (-1, -1, -1, 2, 2, 5), (sx * bw * 0.5, -bh * 0.1, -bd * 0.3), (0, sx * 0.9, 0))

def club(S, w, h, d, tail_name="tail3", ln=14):
    S.add("club", tail_name, "armor", (-w / 2, -h / 2, 0, w, h, d), (0, 0, ln))

# --------------------------------------------------------------------------- parametros por especie
def H(hw, hh, hd, sl, sw, snh): return dict(hw=hw, hh=hh, hd=hd, sl=sl, sw=sw, snh=snh)
BIG_BIP = dict(a=(-0.7, 1.3))
SP = {}
def bip(id, **k): SP[id] = ("bip", k)
def quad(id, **k): SP[id] = ("quad", k)
def sauro(id, **k): SP[id] = ("sauro", k)
def fly(id, **k): SP[id] = ("fly", k)
def aqua(id, **k): SP[id] = ("aqua", k)

bip("trex", th=22, sn=26, ft=15, lw=9, bw=24, bh=26, bd=40, neck=[(9, 15), (9, 13)], nang=[0.85, -0.55], arm=(6, 5, 3, 3),
    tl=58, tw=15, tt=17, **H(15, 19, 24, 17, 11, 13), deco=[])
bip("allosaurus", th=18, sn=22, ft=13, lw=7, bw=18, bh=22, bd=36, neck=[(9, 12), (9, 10)], nang=[0.85, -0.55], arm=(8, 8, 3, 5),
    tl=50, tw=11, tt=14, **H(11, 15, 22, 17, 8, 10), deco=["brow"])
bip("giganotosaurus", th=22, sn=27, ft=15, lw=9, bw=22, bh=26, bd=44, neck=[(9, 14), (9, 12)], nang=[0.85, -0.55], arm=(7, 7, 3, 4),
    tl=62, tw=14, tt=17, **H(13, 18, 28, 22, 9, 12), deco=["brow"])
bip("carnotaurus", th=16, sn=22, ft=12, lw=7, bw=20, bh=22, bd=34, neck=[(9, 14), (8, 12)], nang=[0.85, -0.55], arm=(3, 3, 2, 0),
    tl=46, tw=12, tt=15, **H(13, 17, 15, 7, 11, 11), deco=["carnotaurus"])
bip("spinosaurus", th=17, sn=21, ft=13, lw=8, bw=22, bh=24, bd=44, neck=[(10, 12), (10, 10)], nang=[0.75, -0.5], arm=(10, 9, 4, 5),
    tl=58, tw=11, tt=17, **H(8, 11, 12, 30, 7, 8), deco=["sail"], a=(-0.55, 1.1), pitch=0.12)
bip("baryonyx", th=14, sn=18, ft=11, lw=6, bw=16, bh=18, bd=32, neck=[(9, 10), (8, 8)], nang=[0.8, -0.5], arm=(8, 8, 3, 4),
    tl=40, tw=9, tt=12, **H(8, 11, 13, 22, 6, 7), deco=[])
bip("velociraptor", th=9, sn=12, ft=9, lw=4, bw=9, bh=11, bd=18, neck=[(7, 5), (6, 4)], nang=[0.9, -0.6], arm=(5, 6, 2, 3),
    tl=40, tw=5, tt=7, **H(6, 7, 9, 11, 4, 4.5), deco=[], tr=-0.02)
bip("utahraptor", th=11, sn=14, ft=10, lw=5, bw=11, bh=13, bd=22, neck=[(7, 7), (6, 6)], nang=[0.9, -0.6], arm=(6, 7, 2, 4),
    tl=42, tw=6, tt=8, **H(7, 9, 11, 12, 5, 5.5), deco=[], tr=-0.02)
bip("compsognathus", th=6, sn=8, ft=6, lw=2, bw=6, bh=7, bd=12, neck=[(5, 3), (4, 3)], nang=[0.8, -0.5], arm=(3, 3, 1, 1),
    tl=26, tw=3, tt=4, **H(4, 4.5, 6, 7, 3, 3), deco=[], tr=-0.03)
bip("dilophosaurus", th=13, sn=16, ft=11, lw=5, bw=12, bh=14, bd=26, neck=[(9, 7), (8, 6)], nang=[0.85, -0.55], arm=(6, 6, 2, 3),
    tl=40, tw=7, tt=9, **H(7, 9, 12, 12, 5, 6), deco=["dilophosaurus"])
bip("gallimimus", th=14, sn=18, ft=11, lw=4, bw=11, bh=12, bd=20, neck=[(10, 4), (10, 4)], nang=[0.9, -0.6], arm=(4, 5, 2, 2),
    tl=32, tw=4, tt=5, **H(4.5, 5, 7, 8, 3.5, 3.5), deco=[], tr=-0.02)
bip("dryosaurus", th=8, sn=10, ft=7, lw=3, bw=8, bh=9, bd=16, neck=[(6, 4), (5, 4)], nang=[0.85, -0.55], arm=(3, 3, 1.5, 1),
    tl=22, tw=3.5, tt=5, **H(4.5, 5, 6, 5, 4, 3.5), deco=[])
bip("therizinosaurus", th=16, sn=19, ft=11, lw=8, bw=24, bh=26, bd=34, neck=[(12, 8), (11, 7)], nang=[0.6, -0.3], arm=(16, 15, 4, 16),
    tl=22, tw=11, tt=12, **H(7, 8, 11, 8, 6, 6), deco=[], pitch=-0.2)
bip("pachycephalosaurus", th=9, sn=12, ft=8, lw=4, bw=10, bh=12, bd=18, neck=[(5, 5), (4, 5)], nang=[0.8, -0.5], arm=(4, 4, 2, 1),
    tl=22, tw=5, tt=7, **H(7, 8, 9, 5, 5, 5), deco=["dome"])

quad("triceratops", bw=28, bh=24, bd=44, lf=22, lr=26, wf=9, wr=10, neck=[(6, 14)], nang=[1.2], tl=26, tw=10, tt=12,
     **H(15, 17, 20, 12, 10, 11), deco=["triceratops"], hl=20, af=(0, 0), ab=(-0.25, 0.5))
quad("stegosaurus", bw=24, bh=24, bd=44, lf=16, lr=26, wf=8, wr=10, neck=[(7, 8)], nang=[1.4], tl=38, tw=10, tt=12,
     **H(6, 7, 9, 9, 4, 4.5), deco=["plates", "spikes"], af=(0, 0), ab=(-0.3, 0.6))
quad("ankylosaurus", bw=34, bh=18, bd=44, lf=12, lr=14, wf=9, wr=10, neck=[(5, 12)], nang=[1.1], tl=34, tw=12, tt=9,
     **H(14, 9, 16, 7, 12, 7), deco=["knobs", "club"], af=(0, 0), ab=(-0.2, 0.4))
quad("kentrosaurus", bw=18, bh=18, bd=34, lf=12, lr=17, wf=6, wr=7, neck=[(6, 6)], nang=[1.3], tl=32, tw=7, tt=9,
     **H(5, 6, 8, 8, 3.5, 4), deco=["plates_small", "spikes"], af=(0, 0), ab=(-0.3, 0.6))
quad("parasaurolophus", bw=18, bh=20, bd=36, lf=18, lr=24, wf=6, wr=8, neck=[(9, 8), (8, 7)], nang=[0.9, -0.3], tl=38, tw=8, tt=10,
     **H(8, 9, 14, 12, 9, 5), deco=["parasaur"], af=(0, 0), ab=(-0.4, 0.8), cl=26)
quad("iguanodon", bw=16, bh=18, bd=34, lf=14, lr=22, wf=5, wr=7, neck=[(8, 7), (7, 6)], nang=[0.8, -0.3], tl=34, tw=7, tt=9,
     **H(6, 7, 11, 10, 6, 5), deco=[], af=(0, 0), ab=(-0.4, 0.8))
quad("protoceratops", bw=12, bh=11, bd=22, lf=8, lr=10, wf=4, wr=5, neck=[(4, 7)], nang=[1.1], tl=14, tw=5, tt=6,
     **H(7, 8, 10, 6, 5, 6), deco=["protoceratops"], af=(0, 0), ab=(-0.2, 0.4))
quad("dimetrodon", bw=12, bh=11, bd=30, lf=7, lr=7, wf=4, wr=4, neck=[(4, 7)], nang=[0.9], tl=26, tw=5, tt=6,
     **H(6, 7, 14, 9, 5, 6), deco=["sail"], af=(0.0, 0.0), ab=(0.0, 0.0), sprawl=True)

sauro("brachiosaurus", bw=30, bh=26, bd=46, lf=48, lr=34, wf=10, wr=11, neck=[(18, 10), (18, 8), (16, 7)], nang=[0.45, -0.15, -0.1], tl=38, tw=11, tt=12,
      **H(7, 8, 12, 7, 6, 6.5), deco=[])
sauro("diplodocus", bw=22, bh=22, bd=44, lf=28, lr=30, wf=7, wr=8, neck=[(18, 7), (18, 6), (16, 5)], nang=[0.5, -0.1, -0.15], tl=70, tw=8, tt=9,
      **H(4, 4.5, 9, 6, 3.5, 4), deco=[], tr=0.0)
sauro("apatosaurus", bw=26, bh=24, bd=44, lf=28, lr=30, wf=9, wr=10, neck=[(16, 9), (15, 8), (13, 6)], nang=[0.5, -0.1, -0.1], tl=56, tw=10, tt=11,
      **H(5, 6, 10, 7, 5, 5), deco=[])

fly("pteranodon", bw=7, bh=7, bd=14, lh=7, neck=[(7, 3), (6, 3)], nang=[0.9, -0.6], tl=4, tw=3, wa=18, wb=36, wc=16,
    **H(3.5, 4, 8, 28, 2.5, 3), deco=["pteranodon"], cl=22)
fly("dimorphodon", bw=5, bh=5, bd=9, lh=5, neck=[(3, 3), (3, 3)], nang=[0.9, -0.6], tl=22, tw=2, wa=8, wb=14, wc=8,
    **H(6, 7, 9, 5, 5, 5.5), deco=[], cl=0)
fly("quetzalcoatlus", bw=10, bh=10, bd=18, lh=22, neck=[(14, 4), (14, 4), (12, 3)], nang=[0.5, -0.1, -0.1], tl=4, tw=4, wa=26, wb=46, wc=18,
    **H(4, 5, 10, 34, 3, 3.5), deco=[], cl=0)

aqua("mosasaurus", bw=18, bh=18, bd=46, neck=[(4, 14)], nang=[0.0], tl=60, tw=16, tt=18, fl=16, fw=8,
     **H(13, 12, 14, 26, 9, 8), deco=[])
aqua("plesiosaurus", bw=18, bh=14, bd=30, neck=[(10, 6), (10, 5), (10, 5)], nang=[-0.1, -0.1, -0.1], tl=24, tw=7, tt=8, fl=20, fw=9,
     **H(5, 5, 8, 8, 4, 4), deco=[])

# --------------------------------------------------------------------------- ensamblado
def decorate(S, id, P):
    for d in P.get("deco", []):
        if d == "sail":
            if id == "spinosaurus": sail(S, P, 12, 26, -P["bd"] * 0.25, P["bd"] * 0.3, prof=lambda f: math.sin(math.pi * (0.05 + 0.9 * f)) ** 0.8, t=1.5)
            else: sail(S, P, 9, 14, -P["bd"] * 0.25, P["bd"] * 0.3, t=1.2)
        elif d == "plates": back_plates(S, P, 5, 17, rows2=True)
        elif d == "plates_small": back_plates(S, P, 5, 9, rows2=True)
        elif d == "spikes": tail_spikes(S, 4, 9)
        elif d == "knobs": knobs(S, P)
        elif d == "club": club(S, 14, 10, 10, ln=P["tl"] * 0.27)
        else: deco(S, d, P)

def fk_bounds(parts):
    """Cinematica directa (solo giros en X) para estimar la altura total del modelo en px."""
    idx = {p["name"]: p for p in parts}; cache = {}
    def tf(name):
        if name in cache: return cache[name]
        p = idx[name]; py, pz = p["pivot"][1], p["pivot"][2]; ang = p["rot"][0]
        if p["parent"]:
            (oy, oz, a) = tf(p["parent"]); c, s = math.cos(a), math.sin(a)
            y = oy + py * c - pz * s; z = oz + py * s + pz * c; ang = a + ang
        else: y, z = py, pz
        cache[name] = (y, z, ang); return cache[name]
    ymin, ymax = 1e9, -1e9
    for p in parts:
        y0, z0, a = tf(p["name"]); x, by, bz, w, h, d = p["box"]; c, s = math.cos(a), math.sin(a)
        for yy in (by, by + h):
            for zz in (bz, bz + d):
                Y = y0 + yy * c - zz * s
                ymin, ymax = min(ymin, Y), max(ymax, Y)
    return ymin, ymax, tf

def pack(parts):
    items = sorted(parts, key=lambda p: -(p["box"][5] + p["box"][4]))
    for TW, TH in ((256, 256), (512, 256), (512, 512), (1024, 512)):
        x = y = rowh = 0; ok = True
        for p in items:
            _, _, _, w, h, d = p["box"]; W, Hh = 2 * (d + w), d + h
            if x + W > TW: x, y, rowh = 0, y + rowh, 0
            if y + Hh > TH: ok = False; break
            p["u"], p["v"] = x, y; x += W; rowh = max(rowh, Hh)
        if ok: return TW, TH
    raise SystemExit("atlas demasiado grande")

for sid, (arch, P) in SP.items():
    S = Spec()
    P = dict(P)
    info = {"bip": build_bip, "quad": build_quad, "sauro": build_sauro, "fly": build_flyer, "aqua": build_aqua}[arch](S, P)
    decorate(S, sid, P)
    ymin, ymax, tf = fk_bounds(S.parts)
    seat_y = tf("saddle")[0] - 3 if any(p["name"] == "saddle" for p in S.parts) else ymin
    TW, TH = pack(S.parts)
    spec = dict(id=sid, tw=TW, th=TH, height_px=round(24 - ymin, 2), seat_px=round(24 - seat_y, 2), sit_drop=round(info["sit"], 2),
                sprawl=bool(P.get("sprawl")), parts=S.parts)
    json.dump(spec, open(f"{OUT}/{sid}.json", "w"), indent=1)
missing = set(rows) - set(SP)
assert not missing, missing
print("OK modelos:", len(SP), "| ejemplo trex partes:", len(json.load(open(f"{OUT}/trex.json"))["parts"]))
