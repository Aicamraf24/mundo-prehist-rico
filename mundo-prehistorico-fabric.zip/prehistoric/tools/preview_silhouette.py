#!/usr/bin/env python3
"""Vista lateral (silueta con los colores de la especie) de los modelos generados. Uso: preview_silhouette.py id [id...]"""
import json, math, os, sys, csv
from PIL import Image, ImageDraw
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
M = f"{ROOT}/src/main/resources/data/prehistoric/models"
rows = {r["id"]: r for r in csv.DictReader(open(f"{ROOT}/src/main/resources/data/prehistoric/species.csv"))}
ids = sys.argv[1:]
S = 3; CW, CH = 400, 330
sheet = Image.new("RGB", (CW * 3, CH * ((len(ids) + 2) // 3)), (62, 74, 96))
for n, sid in enumerate(ids):
    spec = json.load(open(f"{M}/{sid}.json")); idx = {p["name"]: p for p in spec["parts"]}; cache = {}
    def tf(name):
        if name in cache: return cache[name]
        p = idx[name]; py, pz = p["pivot"][1], p["pivot"][2]; a = p["rot"][0]
        if p["parent"]:
            oy, oz, pa = tf(p["parent"]); c, s = math.cos(pa), math.sin(pa)
            y, z, a = oy + py * c - pz * s, oz + py * s + pz * c, pa + a
        else: y, z = py, pz
        cache[name] = (y, z, a); return cache[name]
    img = Image.new("RGB", (CW, CH), (62, 74, 96)); d = ImageDraw.Draw(img)
    col = tuple(int(rows[sid]["color"][i:i + 2], 16) for i in (0, 2, 4)); acc = tuple(int(rows[sid]["accent"][i:i + 2], 16) for i in (0, 2, 4))
    d.line([(0, CH - 30), (CW, CH - 30)], fill=(40, 50, 40))
    for p in spec["parts"]:
        y0, z0, a = tf(p["name"]); x, by, bz, w, h, dd = p["box"]; c, s = math.cos(a), math.sin(a)
        pts = []
        for yy, zz in ((by, bz), (by, bz + dd), (by + h, bz + dd), (by + h, bz)):
            Y = y0 + yy * c - zz * s; Z = y0 * 0 + z0 + yy * s + zz * c
            pts.append((CW * 0.55 - Z * S, CH - 30 - (24 - Y) * S))
        k = p["kind"]; fill = col if k in ("skin", "head", "foot", "snout") else tuple(min(255, v + 60) for v in col) if k == "jaw" else acc if k in ("plate", "membrane") else (225, 215, 185) if k in ("bone", "horn") else (110, 80, 50) if k == "saddle" else (90, 84, 76)
        d.polygon(pts, fill=fill, outline=(15, 15, 15))
    d.text((6, 6), f"{sid}  {spec['height_px']:.0f}px", fill=(255, 255, 255))
    sheet.paste(img, ((n % 3) * CW, (n // 3) * CH))
sheet.save("/tmp/sil.png")
