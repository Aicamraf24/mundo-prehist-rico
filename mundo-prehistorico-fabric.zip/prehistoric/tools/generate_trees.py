#!/usr/bin/env python3
"""Arbol prehistorico: texturas pulidas, modelos, estados de bloque, recetas, botin, tags y generacion."""
import json, math, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A, D = f"{RES}/assets/prehistoric", f"{RES}/data/prehistoric"
MC = f"{RES}/data/minecraft"
for p in ["textures/block", "models/block", "models/item", "blockstates", "items", "lang"]: os.makedirs(f"{A}/{p}", exist_ok=True)
for p in ["loot_table/blocks", "recipe", "worldgen/configured_feature", "worldgen/placed_feature", "tags/item"]: os.makedirs(f"{D}/{p}", exist_ok=True)
for p in ["tags/block", "tags/block/mineable", "tags/item"]: os.makedirs(f"{MC}/{p}", exist_ok=True)

def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)
def hn(x, y, seed):
    n = (x * 73856093) ^ (y * 19349663) ^ (seed * 83492791); n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 255) / 255.0
def mix(a, b, t): return tuple(max(0, min(255, int(a[i] + (b[i] - a[i]) * t))) for i in range(3))

# ------------------------------------------------------------ paleta: madera gris (mas gris que el roble)
BARK = [(58, 56, 54), (84, 81, 77), (110, 105, 99), (136, 131, 123), (160, 154, 145)]
PLK = [(98, 86, 70), (126, 111, 90), (150, 133, 108), (170, 152, 124), (186, 168, 140)]   # tablones: como el roble pero mas grises
STR = [(120, 109, 94), (146, 133, 114), (170, 156, 134), (190, 176, 152), (206, 192, 168)]
LEAF = [(52, 72, 56), (70, 96, 74), (92, 120, 94), (116, 144, 114), (146, 170, 138)]

def save(name, img): img.save(f"{A}/textures/block/{name}.png")

def log_side(pal, seed, rough=True):
    img = Image.new("RGBA", (16, 16)); px = img.load()
    # franjas verticales de corteza con anchura variable
    cols = []; x = 0
    while x < 16:
        w = 1 + int(hn(x, 0, seed) * 3); tone = int(hn(x, 7, seed + 1) * 4)
        cols += [tone] * w; x += w
    cols = cols[:16]
    for y in range(16):
        for x in range(16):
            tone = cols[x] + (1 if hn(x, y // 3, seed + 2) > 0.75 else 0) - (1 if hn(x, y // 2, seed + 3) < 0.15 else 0)
            if rough and (x == 0 or cols[x] != cols[x - 1]): tone -= 1          # grietas entre franjas
            if hn(x, y, seed + 4) > 0.94: tone += 1
            px[x, y] = pal[max(0, min(4, tone))] + (255,)
    if rough:
        for yy in (3, 8, 12):                                                    # grietas horizontales cortas
            x0 = int(hn(yy, 1, seed) * 10)
            for k in range(3): px[(x0 + k) % 16, yy] = pal[0] + (255,)
    return img

def log_top(ring_pal, bark_pal, seed):
    img = Image.new("RGBA", (16, 16)); px = img.load()
    for y in range(16):
        for x in range(16):
            edge = min(x, y, 15 - x, 15 - y)
            if edge <= 1: c = bark_pal[1 + (1 if hn(x, y, seed) > 0.6 else 0)]; 
            elif edge == 2: c = bark_pal[0]
            else:
                r = math.hypot(x - 7.5, y - 7.5)
                tone = 3 if int(r * 1.1) % 2 == 0 else 2
                if hn(x, y, seed + 5) > 0.9: tone -= 1
                c = ring_pal[tone]
            px[x, y] = c + (255,)
    px[7, 7] = ring_pal[1]; px[8, 8] = ring_pal[1]
    return img

def planks(seed):
    img = Image.new("RGBA", (16, 16)); px = img.load()
    for y in range(16):
        board = y // 4
        for x in range(16):
            seam = (x + board * 7) % 16
            tone = 2 + (1 if hn(x // 4, board, seed) > 0.5 else 0) + (1 if hn(x, y, seed + 1) > 0.85 else 0) - (1 if hn(x, y // 2, seed + 2) < 0.18 else 0)
            if y % 4 == 0: tone = 0 if y > 0 else 0                    # junta horizontal oscura
            elif y % 4 == 1: tone = max(tone, 3)                       # borde superior claro
            if seam in (0, 1) and y % 4 != 0: tone = 1 if seam == 0 else tone
            if (seam in (2, 13)) and y % 4 == 2: tone = 0              # clavos
            px[x, y] = PLK[max(0, min(4, tone))] + (255,)
    return img

def leaves(seed):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); px = img.load()
    for y in range(16):
        for x in range(16):
            n = hn(x // 2, y // 2, seed)
            if n < 0.16: continue                                        # huecos (cutout)
            tone = 2 + int((hn(x, y, seed + 1) - 0.5) * 3)
            if (x + y) % 5 == 0: tone -= 1
            if hn(x, y, seed + 2) > 0.85: tone += 1
            if hn(x + 3, y, seed + 3) < 0.1: tone = 0
            px[x, y] = LEAF[max(0, min(4, tone))] + (255,)
    return img

def sapling(seed):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); px = img.load()
    for y in range(9, 16): px[7, y] = BARK[2] + (255,); px[8, y] = BARK[1] + (255,)       # tronquito
    px[6, 13] = BARK[1] + (255,); px[9, 12] = BARK[2] + (255,)
    for (cx, cy, r) in ((8, 6, 4.2), (5, 8, 2.6), (11, 8, 2.6), (8, 3, 2.4)):
        for y in range(16):
            for x in range(16):
                if math.hypot(x - cx, y - cy) <= r:
                    tone = 2 + (1 if (x + y) % 3 == 0 else 0) - (1 if y > cy + 1 else 0) + (1 if hn(x, y, seed) > 0.8 else 0)
                    px[x, y] = LEAF[max(0, min(4, tone))] + (255,)
    for y in range(16):                                                                   # contorno oscuro
        for x in range(16):
            if px[x, y][3] == 0 and any(0 <= x + a < 16 and 0 <= y + b < 16 and px[x + a, y + b][3] and px[x + a, y + b][:3] in LEAF for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                px[x, y] = (34, 48, 38, 255)
    return img

save("prehistoric_log", log_side(BARK, 11)); save("prehistoric_log_top", log_top(PLK, BARK, 12))
save("stripped_prehistoric_log", log_side(STR, 21, rough=False)); save("stripped_prehistoric_log_top", log_top(STR, STR, 22))
save("prehistoric_planks", planks(31)); save("prehistoric_leaves", leaves(41)); save("prehistoric_sapling", sapling(51))
sap = Image.open(f"{A}/textures/block/prehistoric_sapling.png"); os.makedirs(f"{A}/textures/item", exist_ok=True); sap.save(f"{A}/textures/item/prehistoric_sapling.png")

# ------------------------------------------------------------ modelos y estados
B = "prehistoric:block/"
def model(name, obj): wj(f"{A}/models/block/{name}.json", obj)
def item(name, model_id): wj(f"{A}/items/{name}.json", {"model": {"type": "minecraft:model", "model": model_id}})

model("prehistoric_log", {"parent": "minecraft:block/cube_column", "textures": {"end": B + "prehistoric_log_top", "side": B + "prehistoric_log"}})
model("stripped_prehistoric_log", {"parent": "minecraft:block/cube_column", "textures": {"end": B + "stripped_prehistoric_log_top", "side": B + "stripped_prehistoric_log"}})
model("prehistoric_wood", {"parent": "minecraft:block/cube_column", "textures": {"end": B + "prehistoric_log", "side": B + "prehistoric_log"}})
model("stripped_prehistoric_wood", {"parent": "minecraft:block/cube_column", "textures": {"end": B + "stripped_prehistoric_log", "side": B + "stripped_prehistoric_log"}})
model("prehistoric_planks", {"parent": "minecraft:block/cube_all", "textures": {"all": B + "prehistoric_planks"}})
model("prehistoric_leaves", {"parent": "minecraft:block/cube_all", "render_type": "minecraft:cutout_mipped", "textures": {"all": B + "prehistoric_leaves"}})
model("prehistoric_sapling", {"parent": "minecraft:block/cross", "render_type": "minecraft:cutout", "textures": {"cross": B + "prehistoric_sapling"}})
pt = {"bottom": B + "prehistoric_planks", "top": B + "prehistoric_planks", "side": B + "prehistoric_planks"}
model("prehistoric_stairs", {"parent": "minecraft:block/stairs", "textures": pt})
model("prehistoric_stairs_inner", {"parent": "minecraft:block/inner_stairs", "textures": pt})
model("prehistoric_stairs_outer", {"parent": "minecraft:block/outer_stairs", "textures": pt})
model("prehistoric_slab", {"parent": "minecraft:block/slab", "textures": pt})
model("prehistoric_slab_top", {"parent": "minecraft:block/slab_top", "textures": pt})
model("prehistoric_fence_post", {"parent": "minecraft:block/fence_post", "textures": {"texture": B + "prehistoric_planks"}})
model("prehistoric_fence_side", {"parent": "minecraft:block/fence_side", "textures": {"texture": B + "prehistoric_planks"}})
model("prehistoric_fence_inventory", {"parent": "minecraft:block/fence_inventory", "textures": {"texture": B + "prehistoric_planks"}})

def pillar(name):
    m = B + name
    wj(f"{A}/blockstates/{name}.json", {"variants": {"axis=y": {"model": m}, "axis=z": {"model": m, "x": 90}, "axis=x": {"model": m, "x": 90, "y": 90}}})
    item(name, m)
for n in ("prehistoric_log", "stripped_prehistoric_log", "prehistoric_wood", "stripped_prehistoric_wood"): pillar(n)
for n in ("prehistoric_planks", "prehistoric_leaves"):
    wj(f"{A}/blockstates/{n}.json", {"variants": {"": {"model": B + n}}}); item(n, B + n)
wj(f"{A}/blockstates/prehistoric_sapling.json", {"variants": {"": {"model": B + "prehistoric_sapling"}}})
wj(f"{A}/models/item/prehistoric_sapling.json", {"parent": "item/generated", "textures": {"layer0": "prehistoric:item/prehistoric_sapling"}})
item("prehistoric_sapling", "prehistoric:item/prehistoric_sapling")

# escaleras
st, inn, out = B + "prehistoric_stairs", B + "prehistoric_stairs_inner", B + "prehistoric_stairs_outer"
V = {}
rot = {"east": 0, "south": 90, "west": 180, "north": 270}
def ent(model_id, y=0, x=0, uv=True):
    e = {"model": model_id}
    if x: e["x"] = x
    if y: e["y"] = y
    if uv and (x or y): e["uvlock"] = True
    return e
for facing, y in rot.items():
    for half, x in (("bottom", 0), ("top", 180)):
        yy = (y + (90 if half == "top" else 0)) % 360 if False else y
        base = y if half == "bottom" else (y + 0) % 360
        V[f"facing={facing},half={half},shape=straight"] = ent(st, y if half == "bottom" else y, x)
        V[f"facing={facing},half={half},shape=outer_right"] = ent(out, y if half == "bottom" else (y + 90) % 360, x)
        V[f"facing={facing},half={half},shape=outer_left"] = ent(out, (y + 270) % 360 if half == "bottom" else y, x)
        V[f"facing={facing},half={half},shape=inner_right"] = ent(inn, y if half == "bottom" else (y + 90) % 360, x)
        V[f"facing={facing},half={half},shape=inner_left"] = ent(inn, (y + 270) % 360 if half == "bottom" else y, x)
wj(f"{A}/blockstates/prehistoric_stairs.json", {"variants": V}); item("prehistoric_stairs", st)
wj(f"{A}/blockstates/prehistoric_slab.json", {"variants": {"type=bottom": {"model": B + "prehistoric_slab"}, "type=top": {"model": B + "prehistoric_slab_top"}, "type=double": {"model": B + "prehistoric_planks"}}})
item("prehistoric_slab", B + "prehistoric_slab")
post, side = B + "prehistoric_fence_post", B + "prehistoric_fence_side"
wj(f"{A}/blockstates/prehistoric_fence.json", {"multipart": [
    {"apply": {"model": post}},
    {"when": {"north": "true"}, "apply": {"model": side, "uvlock": True}},
    {"when": {"east": "true"}, "apply": {"model": side, "y": 90, "uvlock": True}},
    {"when": {"south": "true"}, "apply": {"model": side, "y": 180, "uvlock": True}},
    {"when": {"west": "true"}, "apply": {"model": side, "y": 270, "uvlock": True}}]})
item("prehistoric_fence", B + "prehistoric_fence_inventory")

# ------------------------------------------------------------ botin
def drop_self(name, extra=None):
    pool = {"rolls": 1, "bonus_rolls": 0, "entries": [{"type": "minecraft:item", "name": f"prehistoric:{name}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}
    wj(f"{D}/loot_table/blocks/{name}.json", {"type": "minecraft:block", "pools": [pool]})
for n in ("prehistoric_log", "stripped_prehistoric_log", "prehistoric_wood", "stripped_prehistoric_wood", "prehistoric_planks", "prehistoric_stairs", "prehistoric_fence", "prehistoric_sapling"): drop_self(n)
wj(f"{D}/loot_table/blocks/prehistoric_slab.json", {"type": "minecraft:block", "pools": [{"rolls": 1, "bonus_rolls": 0, "entries": [{"type": "minecraft:item", "name": "prehistoric:prehistoric_slab", "functions": [
    {"function": "minecraft:set_count", "count": 2, "add": False, "conditions": [{"condition": "minecraft:block_state_property", "block": "prehistoric:prehistoric_slab", "properties": {"type": "double"}}]},
    {"function": "minecraft:explosion_decay"}]}]}]})
shears = {"condition": "minecraft:match_tool", "predicate": {"items": "minecraft:shears"}}
silk = {"condition": "minecraft:match_tool", "predicate": {"predicates": {"minecraft:enchantments": [{"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}
wj(f"{D}/loot_table/blocks/prehistoric_leaves.json", {"type": "minecraft:block", "pools": [
    {"rolls": 1, "bonus_rolls": 0, "entries": [{"type": "minecraft:alternatives", "children": [
        {"type": "minecraft:item", "name": "prehistoric:prehistoric_leaves", "conditions": [{"condition": "minecraft:any_of", "terms": [shears, silk]}]},
        {"type": "minecraft:item", "name": "prehistoric:prehistoric_sapling", "conditions": [{"condition": "minecraft:survives_explosion"},
            {"condition": "minecraft:table_bonus", "enchantment": "minecraft:fortune", "chances": [0.05, 0.0625, 0.083333336, 0.1]}]}]}]},
    {"rolls": 1, "bonus_rolls": 0, "conditions": [{"condition": "minecraft:inverted", "term": {"condition": "minecraft:any_of", "terms": [shears, silk]}}],
     "entries": [{"type": "minecraft:item", "name": "minecraft:stick", "conditions": [{"condition": "minecraft:table_bonus", "enchantment": "minecraft:fortune", "chances": [0.02, 0.022222223, 0.025, 0.033333335, 0.1]}],
                  "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1, "max": 2}}, {"function": "minecraft:explosion_decay"}]}]}]})

# ------------------------------------------------------------ recetas
P = "prehistoric:"
wj(f"{D}/tags/item/prehistoric_logs.json", {"values": [P + "prehistoric_log", P + "stripped_prehistoric_log", P + "prehistoric_wood", P + "stripped_prehistoric_wood"]})
wj(f"{D}/recipe/prehistoric_planks.json", {"type": "minecraft:crafting_shapeless", "category": "building", "group": "planks", "ingredients": ["#prehistoric:prehistoric_logs"], "result": {"id": P + "prehistoric_planks", "count": 4}})
wj(f"{D}/recipe/prehistoric_wood.json", {"type": "minecraft:crafting_shaped", "category": "building", "key": {"#": P + "prehistoric_log"}, "pattern": ["##", "##"], "result": {"id": P + "prehistoric_wood", "count": 3}})
wj(f"{D}/recipe/stripped_prehistoric_wood.json", {"type": "minecraft:crafting_shaped", "category": "building", "key": {"#": P + "stripped_prehistoric_log"}, "pattern": ["##", "##"], "result": {"id": P + "stripped_prehistoric_wood", "count": 3}})
wj(f"{D}/recipe/prehistoric_stairs.json", {"type": "minecraft:crafting_shaped", "category": "building", "group": "wooden_stairs", "key": {"#": P + "prehistoric_planks"}, "pattern": ["#  ", "## ", "###"], "result": {"id": P + "prehistoric_stairs", "count": 4}})
wj(f"{D}/recipe/prehistoric_slab.json", {"type": "minecraft:crafting_shaped", "category": "building", "group": "wooden_slab", "key": {"#": P + "prehistoric_planks"}, "pattern": ["###"], "result": {"id": P + "prehistoric_slab", "count": 6}})
wj(f"{D}/recipe/prehistoric_fence.json", {"type": "minecraft:crafting_shaped", "category": "misc", "group": "wooden_fence", "key": {"#": P + "prehistoric_planks", "S": "minecraft:stick"}, "pattern": ["#S#", "#S#"], "result": {"id": P + "prehistoric_fence", "count": 3}})

# ------------------------------------------------------------ tags de Minecraft (troncos, tablones, hojas, brotes...)
def tag(kind, name, values):
    path = f"{MC}/tags/{kind}/{name}.json"
    if os.path.exists(path):
        cur = json.load(open(path, encoding="utf-8")); values = sorted(set(cur.get("values", []) + values))
    wj(path, {"replace": False, "values": values})
logs = [P + "prehistoric_log", P + "stripped_prehistoric_log", P + "prehistoric_wood", P + "stripped_prehistoric_wood"]
for kind in ("block", "item"):
    tag(kind, "logs", logs); tag(kind, "logs_that_burn", logs); tag(kind, "planks", [P + "prehistoric_planks"])
    tag(kind, "leaves", [P + "prehistoric_leaves"]); tag(kind, "saplings", [P + "prehistoric_sapling"])
    tag(kind, "wooden_stairs", [P + "prehistoric_stairs"]); tag(kind, "wooden_slabs", [P + "prehistoric_slab"]); tag(kind, "wooden_fences", [P + "prehistoric_fence"])
tag("block", "overworld_natural_logs", [P + "prehistoric_log"]); tag("item", "overworld_natural_logs", [P + "prehistoric_log"]) if False else None
tag("block", "mineable/axe", logs + [P + "prehistoric_planks", P + "prehistoric_stairs", P + "prehistoric_slab", P + "prehistoric_fence"])
tag("block", "mineable/hoe", [P + "prehistoric_leaves"])
tag("block", "sword_efficient", [P + "prehistoric_leaves", P + "prehistoric_sapling"])

# ------------------------------------------------------------ generacion: arbol grande, 25 % por chunk en cualquier bioma
wj(f"{D}/worldgen/configured_feature/prehistoric_tree.json", {"type": "minecraft:tree", "config": {
    "ignore_vines": True, "force_dirt": False,
    "minimum_size": {"type": "minecraft:three_layers_feature_size", "limit": 1, "upper_limit": 1, "lower_size": 0, "middle_size": 1, "upper_size": 2},
    "dirt_provider": {"type": "minecraft:simple_state_provider", "state": {"Name": "minecraft:dirt"}},
    "trunk_provider": {"type": "minecraft:simple_state_provider", "state": {"Name": "prehistoric:prehistoric_log", "Properties": {"axis": "y"}}},
    "foliage_provider": {"type": "minecraft:simple_state_provider", "state": {"Name": "prehistoric:prehistoric_leaves", "Properties": {"distance": "7", "persistent": "false", "waterlogged": "false"}}},
    "trunk_placer": {"type": "minecraft:fancy_trunk_placer", "base_height": 4, "height_rand_a": 10, "height_rand_b": 0},
    "foliage_placer": {"type": "minecraft:fancy_foliage_placer", "radius": 3, "offset": 4, "height": 4},
    "decorators": []}})
wj(f"{D}/worldgen/placed_feature/prehistoric_tree.json", {"feature": "prehistoric:prehistoric_tree", "placement": [
    {"type": "minecraft:rarity_filter", "chance": 4},
    {"type": "minecraft:in_square"},
    {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"},
    {"type": "minecraft:block_predicate_filter", "predicate": {"type": "minecraft:would_survive", "state": {"Name": "prehistoric:prehistoric_sapling", "Properties": {"stage": "0"}}}},
    {"type": "minecraft:biome"}]})

# ------------------------------------------------------------ idiomas
es = {"block.prehistoric.prehistoric_log": "Tronco prehistórico", "block.prehistoric.stripped_prehistoric_log": "Tronco prehistórico sin corteza",
      "block.prehistoric.prehistoric_wood": "Madera prehistórica", "block.prehistoric.stripped_prehistoric_wood": "Madera prehistórica sin corteza",
      "block.prehistoric.prehistoric_planks": "Tablones prehistóricos", "block.prehistoric.prehistoric_stairs": "Escaleras prehistóricas",
      "block.prehistoric.prehistoric_slab": "Losa prehistórica", "block.prehistoric.prehistoric_fence": "Valla prehistórica",
      "block.prehistoric.prehistoric_leaves": "Hoja de árbol prehistórico", "block.prehistoric.prehistoric_sapling": "Brote de árbol prehistórico"}
en = {"block.prehistoric.prehistoric_log": "Prehistoric Log", "block.prehistoric.stripped_prehistoric_log": "Stripped Prehistoric Log",
      "block.prehistoric.prehistoric_wood": "Prehistoric Wood", "block.prehistoric.stripped_prehistoric_wood": "Stripped Prehistoric Wood",
      "block.prehistoric.prehistoric_planks": "Prehistoric Planks", "block.prehistoric.prehistoric_stairs": "Prehistoric Stairs",
      "block.prehistoric.prehistoric_slab": "Prehistoric Slab", "block.prehistoric.prehistoric_fence": "Prehistoric Fence",
      "block.prehistoric.prehistoric_leaves": "Prehistoric Tree Leaves", "block.prehistoric.prehistoric_sapling": "Prehistoric Tree Sapling"}
for code, d in (("es_es", es), ("en_us", en)):
    path = f"{A}/lang/{code}.json"; lang = json.load(open(path, encoding="utf-8")); lang.update(d); wj(path, lang)
print("OK arbol prehistorico")
