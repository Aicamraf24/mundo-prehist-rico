#!/usr/bin/env python3
"""Vista lateral aproximada (sin rotaciones) para revisar como se leen las texturas sobre el modelo. Uso: preview_side.py id [id...]"""
import csv, os, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX = f"{ROOT}/src/main/resources/assets/prehistoric/textures/entity"
CSV = f"{ROOT}/src/main/resources/data/prehistoric/species.csv"
LAYOUT = {"body": (0, 0), "neck": (100, 0), "head": (144, 0), "tail1": (0, 40), "tail2": (60, 40), "leg": (120, 40)}
# parte: (pivote_y, pivote_z, caja y0, z0, alto, fondo, u-dims ancho)
G = {
 "THEROPOD": [("tail2",8,18,-2.5,0,5,10,5),("tail1",8,8,-3,0,6,10,7),("leg",13,3,0,-2,11,4,4),("body",10,0,-5,-8,10,16,10),("neck",6,-7,-7,-3,7,6,6),("head",-1,-7,-4,-9,8,10,8)],
 "QUADRUPED": [("tail2",11,18,-2,0,4,8,4),("tail1",11,10,-2.5,0,5,8,6),("leg",16,6,0,-2,8,4,4),("leg",16,-6,0,-2,8,4,4),("body",13,0,-5,-10,10,20,12),("neck",12,-9,-3,-3,6,5,6),("head",12,-11,-4,-9,8,10,8)],
 "SAUROPOD": [("tail2",-12,26,-2.5,0,5,14,6),("tail1",-12,12,-3,0,6,14,8),("leg",-4,8,0,-2.5,28,5,5),("leg",-4,-8,0,-2.5,28,5,5),("body",-10,0,-6,-12,12,24,16),("neck",-14,-11,-26,-3,26,6,6),("head",-40,-11,-3,-6,5,8,5)],
}
rows = {r["id"]: r for r in csv.DictReader(open(CSV, encoding="utf-8"))}
ids = sys.argv[1:] or list(rows)
S, tiles = 6, []
for sid in ids:
    r = rows[sid]; plan = r["plan"]
    if plan not in G: continue
    tex = Image.open(f"{TEX}/{sid}.png")
    canvas = Image.new("RGBA", (70 * S, 70 * S), (60, 70, 90, 255))
    for part, py, pz, y0, z0, h, d, w in G[plan]:
        u, v = LAYOUT[part]
        face = tex.crop((u, v + d, u + d, v + d + h))   # cara 'west': frente a la derecha
        face = face.resize((int(d * S), int(h * S)), Image.NEAREST)
        x = int((-(pz + z0 + d) + 45) * S); y = int((py + y0 + 52) * S) if plan == "SAUROPOD" else int((py + y0 + 20) * S)
        canvas.paste(face, (x, y), face)
    tiles.append(canvas)
W = min(3, len(tiles)); H = (len(tiles) + W - 1) // W
sheet = Image.new("RGBA", (W * 70 * S, H * 70 * S))
for i, t in enumerate(tiles): sheet.paste(t, ((i % W) * 70 * S, (i // W) * 70 * S))
sheet.save("/tmp/side.png")
