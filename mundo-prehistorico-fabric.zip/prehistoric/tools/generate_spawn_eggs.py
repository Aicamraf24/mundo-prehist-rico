#!/usr/bin/env python3
"""Spawn eggs (huevos generadores) de cada dinosaurio: definicion de item con tintes + idiomas."""
import csv, json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"; A = f"{RES}/assets/prehistoric"
rows = list(csv.DictReader(open(f"{RES}/data/prehistoric/species.csv", encoding="utf-8")))
NAMES = {}
lang_es = json.load(open(f"{A}/lang/es_es.json", encoding="utf-8")); lang_en = json.load(open(f"{A}/lang/en_us.json", encoding="utf-8"))
for r in rows:
    i = r["id"]
    with open(f"{A}/items/{i}_spawn_egg.json", "w", encoding="utf-8") as f:
        json.dump({"model": {"type": "minecraft:model", "model": f"prehistoric:item/{i}_spawn_egg"}}, f, indent=2)
    with open(f"{A}/models/item/{i}_spawn_egg.json", "w", encoding="utf-8") as f:
        json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": f"prehistoric:item/{i}_spawn_egg"}}, f, indent=2)
    name = lang_es[f"entity.prehistoric.{i}"]
    lang_es[f"item.prehistoric.{i}_spawn_egg"] = f"Generar {name}"
    lang_en[f"item.prehistoric.{i}_spawn_egg"] = f"{name} Spawn Egg"
for code, d in (("es_es", lang_es), ("en_us", lang_en)):
    with open(f"{A}/lang/{code}.json", "w", encoding="utf-8") as f: json.dump(d, f, ensure_ascii=False, indent=2)
print("OK spawn eggs:", len(rows))
