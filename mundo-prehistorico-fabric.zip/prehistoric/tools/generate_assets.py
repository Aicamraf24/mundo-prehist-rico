#!/usr/bin/env python3
"""Genera texturas (con la silla de montar incluida), modelos JSON, idiomas, loot, recetas y tags de biomas
a partir de src/main/resources/data/prehistoric/species.csv. Requiere Pillow."""
import csv, json, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = f"{ROOT}/src/main/resources/data/prehistoric/species.csv"
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/prehistoric"
D = f"{RES}/data/prehistoric"
for p in ["textures/entity", "textures/block", "textures/item", "models/block", "models/item", "items", "blockstates", "lang"]:
    os.makedirs(f"{A}/{p}", exist_ok=True)
for p in ["loot_table/entities", "loot_table/blocks", "recipe", "tags/worldgen/biome/habitat"]:
    os.makedirs(f"{D}/{p}", exist_ok=True)

def rgb(h): return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def shade(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)

# Cabeza por plan: (d, ancho) -> cara frontal en (88+d, d), tamano w x h
HEAD = {"THEROPOD": (10, 8, 8), "QUADRUPED": (10, 8, 8), "AQUATIC": (12, 8, 8), "SAUROPOD": (8, 5, 5), "FLYER": (8, 5, 5)}

SADDLE_UV = (0, 72, 44, 15)   # x, y, w, h  -> caja 10x3x12 desplegada

def draw_saddle(img):
    """Textura de la silla de montar (cuero marron con correas y hebillas). Es la misma que se ve puesta sobre el dinosaurio."""
    x0, y0, w, h = SADDLE_UV
    d = ImageDraw.Draw(img)
    leather, dark, light, metal = (120, 72, 38), (78, 44, 22), (150, 98, 54), (205, 205, 205)
    d.rectangle([x0, y0, x0 + w - 1, y0 + h - 1], fill=leather)
    rnd = random.Random(7)
    for _ in range(90):
        px, py = x0 + rnd.randrange(w), y0 + rnd.randrange(h)
        d.point((px, py), fill=rnd.choice([dark, light, leather]))
    d.rectangle([x0, y0 + 12, x0 + w - 1, y0 + 14], fill=dark)       # borde inferior
    for sx in (x0 + 12, x0 + 22, x0 + 33):                            # correas
        d.rectangle([sx, y0, sx + 1, y0 + h - 1], fill=dark)
        d.point((sx, y0 + 7), fill=metal)                             # hebilla
    d.rectangle([x0 + 12, y0, x0 + 33, y0 + 11], outline=light)       # cara superior acolchada

def make_entity(row):
    base, acc = rgb(row["color"]), rgb(row["accent"])
    rnd = random.Random(row["id"])
    img = Image.new("RGBA", (128, 128), base + (255,))
    d = ImageDraw.Draw(img)
    # ruido de escamas
    for y in range(128):
        for x in range(128):
            f = 1.0 + rnd.uniform(-0.10, 0.10) + (0.05 if (x // 3 + y // 3) % 2 else -0.03)
            d.point((x, y), fill=shade(base, f) + (255,))
    # franjas / manchas de acento
    for _ in range(26):
        x, y = rnd.randrange(128), rnd.randrange(128)
        w, h = rnd.randint(1, 3), rnd.randint(4, 9)
        d.rectangle([x, y, x + w, y + h], fill=shade(acc, rnd.uniform(0.85, 1.15)) + (255,))
    # vientre mas claro en la parte inferior del cuerpo (zona de la cara inferior de la caja)
    d.rectangle([32, 20, 63, 31], fill=shade(base, 1.3) + (255,))
    # ojos en la cara frontal de la cabeza
    dd, w, h = HEAD[row["plan"]]
    fx, fy = 88 + dd, dd
    d.rectangle([fx + 1, fy + 2, fx + 1, fy + 3], fill=(250, 220, 40, 255))
    d.rectangle([fx + w - 2, fy + 2, fx + w - 2, fy + 3], fill=(250, 220, 40, 255))
    d.point((fx + 1, fy + 3), fill=(20, 20, 20, 255)); d.point((fx + w - 2, fy + 3), fill=(20, 20, 20, 255))
    d.rectangle([fx + 2, fy + h - 2, fx + w - 3, fy + h - 2], fill=(40, 25, 20, 255))   # boca
    draw_saddle(img)
    img.save(f"{A}/textures/entity/{row['id']}.png")

def make_egg(row):
    base, acc = rgb(row["color"]), rgb(row["accent"])
    shell = tuple(min(255, int(v * 0.35 + 170)) for v in base)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rnd = random.Random("egg" + row["id"])
    d.ellipse([3, 1, 12, 14], fill=shell + (255,), outline=shade(shell, 0.7) + (255,))
    for _ in range(9):
        x, y = rnd.randint(4, 11), rnd.randint(3, 12)
        if d.im.getpixel((x, y))[3]:
            d.rectangle([x, y, x + 1, y + 1], fill=shade(acc, 1.0) + (255,))
    d.line([(5, 3), (6, 2)], fill=(255, 255, 255, 200))
    img.save(f"{A}/textures/item/egg_{row['id']}.png")
    img.save(f"{A}/textures/block/egg_{row['id']}.png")

def make_meat():
    for name, c1, c2 in (("dino_meat", (190, 50, 55), (230, 120, 120)), ("cooked_dino_meat", (120, 70, 35), (170, 110, 60))):
        img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
        d.ellipse([2, 4, 13, 13], fill=c1 + (255,), outline=shade(c1, 0.6) + (255,))
        d.ellipse([5, 6, 9, 9], fill=c2 + (255,))
        d.line([(10, 5), (14, 2)], fill=(235, 230, 215, 255), width=2)
        img.save(f"{A}/textures/item/{name}.png")

def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=2)

def make_json(row):
    i = row["id"]; e = f"egg_{i}"
    cube = lambda a, b: {"from": a, "to": b, "faces": {k: {"texture": "#egg"} for k in ("down", "up", "north", "south", "east", "west")}}
    wj(f"{A}/models/block/{e}.json", {"textures": {"particle": f"prehistoric:block/{e}", "egg": f"prehistoric:block/{e}"},
        "elements": [cube([5, 0, 5], [11, 3, 11]), cube([4, 3, 4], [12, 9, 12]), cube([6, 9, 6], [10, 11, 10])]})
    wj(f"{A}/blockstates/{e}.json", {"variants": {"": {"model": f"prehistoric:block/{e}"}}})
    wj(f"{A}/models/item/{e}.json", {"parent": "item/generated", "textures": {"layer0": f"prehistoric:item/{e}"}})
    wj(f"{A}/items/{e}.json", {"model": {"type": "minecraft:model", "model": f"prehistoric:item/{e}"}})
    wj(f"{D}/loot_table/entities/{i}.json", {"type": "minecraft:entity", "pools": [{"rolls": 1, "entries": [{
        "type": "minecraft:item", "name": "prehistoric:dino_meat", "functions": [
            {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 1, "max": 3}}]}]}]})
    wj(f"{D}/loot_table/blocks/{e}.json", {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{
        "type": "minecraft:item", "name": f"prehistoric:{e}"}]}]})

HABITATS = {
    "jungle":   ["minecraft:jungle", "minecraft:sparse_jungle", "minecraft:bamboo_jungle"],
    "forest":   ["minecraft:forest", "minecraft:flower_forest", "minecraft:birch_forest", "minecraft:dark_forest", "minecraft:taiga"],
    "swamp":    ["minecraft:swamp", "minecraft:mangrove_swamp"],
    "plains":   ["minecraft:plains", "minecraft:sunflower_plains", "minecraft:meadow"],
    "savanna":  ["minecraft:savanna", "minecraft:savanna_plateau", "minecraft:windswept_savanna"],
    "badlands": ["minecraft:badlands", "minecraft:eroded_badlands", "minecraft:wooded_badlands"],
    "river":    ["minecraft:river"],
    "ocean":    ["minecraft:ocean", "minecraft:deep_ocean", "minecraft:lukewarm_ocean", "minecraft:warm_ocean"],
}

rows = list(csv.DictReader(open(CSV, encoding="utf-8")))
for r in rows:
    make_entity(r); make_egg(r); make_json(r)
make_meat()
for h, biomes in HABITATS.items():
    wj(f"{D}/tags/worldgen/biome/habitat/{h}.json", {"replace": False, "values": biomes})

# Receta: carne cruda -> cocinada (horno, ahumador y fogata)
for kind, t in (("smelting", 200), ("smoking", 100), ("campfire_cooking", 600)):
    wj(f"{D}/recipe/cooked_dino_meat_{kind}.json", {"type": f"minecraft:{kind}", "category": "food",
        "ingredient": "prehistoric:dino_meat", "result": {"id": "prehistoric:cooked_dino_meat"}, "experience": 0.35, "cookingtime": t})

# Idiomas
NAMES = {"trex": "Tyrannosaurus Rex", "allosaurus": "Allosaurus", "spinosaurus": "Spinosaurus", "velociraptor": "Velociraptor",
    "compsognathus": "Compsognathus", "dilophosaurus": "Dilophosaurus", "carnotaurus": "Carnotaurus", "baryonyx": "Baryonyx",
    "utahraptor": "Utahraptor", "giganotosaurus": "Giganotosaurus", "triceratops": "Triceratops", "stegosaurus": "Stegosaurus",
    "ankylosaurus": "Ankylosaurus", "parasaurolophus": "Parasaurolophus", "pachycephalosaurus": "Pachycephalosaurus",
    "iguanodon": "Iguanodon", "brachiosaurus": "Brachiosaurus", "diplodocus": "Diplodocus", "apatosaurus": "Apatosaurus",
    "gallimimus": "Gallimimus", "therizinosaurus": "Therizinosaurus", "dryosaurus": "Dryosaurus", "pteranodon": "Pteranodon",
    "dimorphodon": "Dimorphodon", "quetzalcoatlus": "Quetzalcoatlus", "mosasaurus": "Mosasaurus", "plesiosaurus": "Plesiosaurus",
    "dimetrodon": "Dimetrodon", "kentrosaurus": "Kentrosaurus", "protoceratops": "Protoceratops"}
for code, egg, meat, cooked, tab in (("es_es", "Huevo de %s", "Carne de dinosaurio", "Carne de dinosaurio cocinada", "Mundo Prehistórico"),
                                     ("en_us", "%s Egg", "Dinosaur Meat", "Cooked Dinosaur Meat", "Prehistoric World")):
    lang = {"item.prehistoric.dino_meat": meat, "item.prehistoric.cooked_dino_meat": cooked, "itemGroup.prehistoric": tab}
    for r in rows:
        n = NAMES[r["id"]]
        lang[f"entity.prehistoric.{r['id']}"] = n
        lang[f"block.prehistoric.egg_{r['id']}"] = egg % n
    wj(f"{A}/lang/{code}.json", lang)
print(f"OK: {len(rows)} especies")
