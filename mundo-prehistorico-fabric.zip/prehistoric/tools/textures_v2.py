#!/usr/bin/env python3
"""Texturas mejoradas: dinosaurios pintados cara por cara (dorso/vientre, escamas, patrones, ojos, boca, dientes, garras),
silla de cuero, huevos, items y armaduras. Ejecutar al final (sobrescribe las texturas simples)."""
import csv, math, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/prehistoric/textures"

def rgb(h): return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def mix(a, b, t): return tuple(max(0, min(255, int(a[i] + (b[i] - a[i]) * t))) for i in range(3))
def mul(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)
def hnoise(x, y, seed):
    n = (x * 73856093) ^ (y * 19349663) ^ (seed * 83492791)
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 255) / 255.0
def sstep(a, b, x):
    t = max(0.0, min(1.0, (x - a) / (b - a))); return t * t * (3 - 2 * t)

# ----------------------------------------------------------------- geometria (espejo de DinoModel.java)
LAYOUT = {"body": (0, 0), "neck": (100, 0), "head": (144, 0), "tail1": (0, 40), "tail2": (60, 40), "leg": (120, 40),
          "wing": (0, 70), "crest": (60, 70), "horns": (100, 70), "saddle": (0, 90)}
DIMS = {  # parte: (ancho, alto, fondo)
    "THEROPOD": {"body": (10, 10, 16), "neck": (6, 7, 6), "head": (8, 8, 10), "tail1": (7, 6, 10), "tail2": (5, 5, 10), "leg": (4, 11, 4), "saddle": (10, 3, 12), "crest": (2, 5, 14), "horns": (10, 2, 4)},
    "QUADRUPED": {"body": (12, 10, 20), "neck": (6, 6, 5), "head": (8, 8, 10), "tail1": (6, 5, 8), "tail2": (4, 4, 8), "leg": (4, 8, 4), "saddle": (10, 3, 12), "crest": (2, 5, 14), "horns": (10, 2, 4)},
    "SAUROPOD": {"body": (16, 12, 24), "neck": (6, 26, 6), "head": (5, 5, 8), "tail1": (8, 6, 14), "tail2": (6, 5, 14), "leg": (5, 28, 5), "saddle": (10, 3, 12), "crest": (2, 5, 14), "horns": (10, 2, 4)},
    "FLYER": {"body": (6, 6, 12), "neck": (3, 3, 4), "head": (5, 5, 8), "tail1": (3, 3, 8), "leg": (2, 6, 2), "wing": (16, 1, 10), "saddle": (8, 2, 8), "crest": (2, 5, 14), "horns": (10, 2, 4)},
    "AQUATIC": {"body": (10, 10, 24), "head": (8, 8, 12), "tail1": (8, 7, 14), "tail2": (5, 6, 12), "leg": (8, 1, 5), "saddle": (10, 3, 12), "crest": (2, 5, 14), "horns": (10, 2, 4)},
}
PATTERN = {"trex": "mottle", "allosaurus": "stripes", "spinosaurus": "mottle", "velociraptor": "stripes", "compsognathus": "spots",
    "dilophosaurus": "mottle", "carnotaurus": "bands", "baryonyx": "spots", "utahraptor": "stripes", "giganotosaurus": "mottle",
    "triceratops": "mottle", "stegosaurus": "spots", "ankylosaurus": "knobs", "parasaurolophus": "stripes", "pachycephalosaurus": "mottle",
    "iguanodon": "spots", "brachiosaurus": "mottle", "diplodocus": "spots", "apatosaurus": "bands", "gallimimus": "stripes",
    "therizinosaurus": "spots", "dryosaurus": "mottle", "pteranodon": "mottle", "dimorphodon": "bands", "quetzalcoatlus": "mottle",
    "mosasaurus": "mottle", "plesiosaurus": "spots", "ichthyosaurus": "mottle", "dimetrodon": "bands", "kentrosaurus": "spots", "protoceratops": "mottle"}

def faces(u, v, w, h, d):
    return {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "west": (u, v + d, d, h), "north": (u + d, v + d, w, h),
            "east": (u + d + w, v + d, d, h), "south": (u + 2 * d + w, v + d, w, h)}

BONE, LEATHER, LDARK, LLIGHT, GOLD, STITCH = (236, 226, 196), (128, 78, 40), (84, 48, 24), (164, 108, 60), (224, 186, 72), (214, 194, 152)

BAYER = [[0.125, 0.625], [0.875, 0.375]]
def make_ramp(c, light):
    sh = (28, 20, 46)   # sombras algo frias/violetas: da mas vida que simplemente oscurecer
    return [mix(mul(c, 0.36), sh, 0.35), mix(mul(c, 0.54), sh, 0.18), mul(c, 0.76), c, mix(c, light, 0.5), light]
def pick(ramp, v, x, y):
    """Paleta de 6 tonos con tramado ordenado: pixel-art limpio en lugar de ruido."""
    v = max(0.0, min(5.0, v)); lo = int(v)
    if lo >= 5: return ramp[5]
    return ramp[lo + 1] if (v - lo) > BAYER[y & 1][x & 1] else ramp[lo]

import json
MODELS = f"{RES}/data/prehistoric/models"

import colorsys
def hsv_shift(c, dh=0.0, ds=1.0, dv=1.0):
    h, sa, v = colorsys.rgb_to_hsv(*[x / 255 for x in c])
    return tuple(int(x * 255) for x in colorsys.hsv_to_rgb((h + dh) % 1.0, min(1, sa * ds), min(1, v * dv)))
def variant_colors(row, i):
    """6 recolores por especie: original, calido, frio, melanico (oscuro), arenoso y raro (tono complementario)."""
    d, a = rgb(row["color"]), rgb(row["accent"])
    if i == 1: return hsv_shift(d, 0.07, 1.15, 1.08), hsv_shift(a, 0.07, 1.1)
    if i == 2: return hsv_shift(d, -0.09, 1.05, 1.0), hsv_shift(a, -0.1, 1.15)
    if i == 3: return hsv_shift(d, 0.0, 0.75, 0.55), hsv_shift(a, 0.0, 1.0, 1.25)
    if i == 4: return mix(d, (216, 198, 160), 0.55), hsv_shift(a, 0.03, 0.9, 0.78)
    if i == 5: return hsv_shift(d, 0.5, 1.25, 1.1), hsv_shift(a, 0.5, 1.1, 1.1)
    return d, a

def paint_species(row, vidx=0):
    sid = row["id"]
    spec = json.load(open(f"{MODELS}/{sid}.json"))
    dorsal, acc = variant_colors(row, vidx)
    belly = mix(dorsal, BONE, 0.6)
    carn = row["carnivore"] == "1"
    seed = sum(ord(c) * (i + 3) for i, c in enumerate(sid))
    pattern = PATTERN[sid]
    R, RA = make_ramp(dorsal, belly), make_ramp(acc, mix(acc, BONE, 0.55))
    RM = make_ramp(mix(dorsal, acc, 0.5), belly)
    RS = make_ramp(mix(dorsal, acc, 0.72), belly)
    RB = make_ramp((196, 180, 140), (246, 240, 220))                 # hueso / cuernos
    RK = make_ramp(mix(dorsal, (70, 62, 56), 0.55), mix(dorsal, BONE, 0.3))   # armadura
    RW = make_ramp(mix(dorsal, acc, 0.5), mix(acc, BONE, 0.4))       # membrana de alas
    img = Image.new("RGBA", (spec["tw"], spec["th"]), (0, 0, 0, 0)); px = img.load()
    TW, TH = spec["tw"], spec["th"]
    def put(x, y, c):
        if 0 <= x < TW and 0 <= y < TH: px[x, y] = tuple(c) + (255,)

    spots_cache = {}
    def spots(key, fw, fh):
        if key not in spots_cache:
            r = random.Random(hash((seed, key)) & 0xFFFF)
            spots_cache[key] = [(r.uniform(0, fw), r.uniform(0, fh * 0.7), r.uniform(0.9, 1.9)) for _ in range(max(2, fw * fh // 16))]
        return spots_cache[key]

    def skin_px(name, face, x, y, fw, fh, gx, gy, shift=0.0):
        t = 0.0 if face == "top" else 1.0 if face == "bottom" else y / max(fh - 1, 1)
        if face == "top": v = 2.3
        elif face == "bottom": v = 4.9
        else: v = 2.5 + 2.5 * sstep(0.45, 0.95, t) - (0.45 if t < 0.18 else 0.0)
        v += shift
        if face == "top" and abs(x - (fw - 1) / 2) <= 0.6: v -= 0.9
        if face == "bottom" and y % 2 == 0: v -= 0.4
        row_i = gy // 3
        if gy % 3 == 0 or (gx + row_i * 2) % 4 == 0: v -= 0.18
        elif (gx + row_i * 2) % 4 == 1 and gy % 3 == 1: v += 0.22
        v += (hnoise(gx, gy, seed) - 0.5) * 0.18
        ramp = R
        if face != "bottom":
            if pattern == "stripes" and t < 0.88:
                sh = int(hnoise(gx // 5, gy // 7, seed + 3) * 3)
                if (gx + sh) % 5 in (0, 1) and hnoise(gx, gy // 4, seed + 7) > 0.25: v -= 2.1
            elif pattern == "bands" and t < 0.92:
                if (gy + int(hnoise(gx // 4, 0, seed) * 2)) % 7 in (0, 1): v -= 1.8
            elif pattern == "spots":
                for sx, sy, sr in spots((name, face), fw, fh):
                    d2 = math.hypot(x - sx, y - sy)
                    if d2 < sr: ramp, v = RS, 2.4 + (0.5 if d2 < sr * 0.5 else 0.0)
            elif pattern == "knobs":
                if x % 4 == 1 and y % 4 == 1: v += 1.0
                elif x % 4 == 2 and y % 4 == 2: v -= 0.8
            else:
                m = hnoise(gx // 3, gy // 3, seed + 11)
                if m > 0.88: ramp, v = RM, 3.0
        return pick(ramp, v, gx, gy)

    TOOTH, MOUTH = (250, 250, 242), (52, 24, 22)
    for part in spec["parts"]:
        kind, name = part["kind"], part["name"]
        _, _, _, w, h, d = part["box"]; u, v = part["u"], part["v"]
        for face, (fx0, fy0, fw, fh) in faces(u, v, w, h, d).items():
            for yy in range(fh):
                for xx in range(fw):
                    gx, gy = fx0 + xx, fy0 + yy
                    if kind in ("skin", "head"):
                        c = skin_px(name, face, xx, yy, fw, fh, gx, gy)
                    elif kind == "foot":
                        c = skin_px(name, face, xx, yy, fw, fh, gx, gy, 0.0)
                        if face == "bottom": c = R[0]
                        elif face == "north": c = pick(RB, 3.5 - (yy / max(fh - 1, 1)) * 2, gx, gy)   # garras al frente
                        elif yy >= fh - 1: c = R[1]
                    elif kind == "snout":
                        c = skin_px(name, face, xx, yy, fw, fh, gx, gy, -0.2 if face == "top" else 0.0)
                        if face == "bottom": c = (214, 120, 122) if hnoise(gx, gy, 5) > 0.2 else (190, 100, 104)
                    elif kind == "jaw":
                        c = skin_px(name, face, xx, yy, fw, fh, gx, gy, 1.3)
                        if face == "top": c = (205, 100, 104)
                    elif kind in ("bone", "horn"):
                        along = xx if face in ("top", "bottom") else yy
                        c = pick(RB, 4.4 - 2.4 * (along % 8) / 8 - (0.8 if (xx + yy) % 5 == 0 else 0), gx, gy)
                    elif kind == "plate":
                        tt = yy / max(fh - 1, 1)
                        vcol = 4.6 - 3.2 * tt if face not in ("top", "bottom") else 2.4
                        if (gx % 3 == 0) and face not in ("top", "bottom"): vcol -= 0.9
                        c = pick(RA, vcol, gx, gy)
                    elif kind == "armor":
                        vcol = 2.8 + (0.9 if (xx + yy) % 4 == 0 else -0.3) + (hnoise(gx, gy, seed) - 0.5) * 0.4
                        c = pick(RK, vcol, gx, gy)
                    elif kind == "membrane":
                        vcol = 3.2 + 0.9 * (yy / max(fh - 1, 1))
                        if face in ("top", "bottom"):
                            for fx in range(2, fw, 5):
                                if abs(xx - fx) < 0.6: vcol = 0.8
                            if yy == 0: vcol = 0.6
                        c = pick(RW, vcol, gx, gy)
                    elif kind == "saddle":
                        c = LLIGHT if face == "top" else LEATHER if face != "bottom" else LDARK
                        c = mul(c, 1.0 + (hnoise(gx, gy, 91) - 0.5) * 0.14)
                        border = xx == 0 or yy == 0 or xx == fw - 1 or yy == fh - 1
                        inner = xx == 1 or yy == 1 or xx == fw - 2 or yy == fh - 2
                        if border: c = LDARK
                        elif inner and (xx + yy) % 2 == 0: c = STITCH
                        if face == "top" and fw > 4 and xx == fw // 2 and 1 < yy < fh - 2: c = LDARK
                        if face in ("west", "east", "north", "south") and fw > 3 and xx == fw // 2 and yy > 0:
                            c = LDARK
                            if yy == fh // 2: c = GOLD
                    else:
                        c = skin_px(name, face, xx, yy, fw, fh, gx, gy)
                    put(gx, gy, c)

        # ---- detalles de cara
        F = faces(u, v, w, h, d)
        if kind == "head":
            iris = (246, 196, 40) if carn else (58, 38, 26)
            if row["plan"] == "FLYER": iris = (246, 120, 30)
            for side, ex in (("west", F["west"][0] + d - 4), ("east", F["east"][0] + 1)):
                ey = F["west"][1] + max(1, int(h * 0.3))
                for dx in range(3): put(ex + dx, ey - 1, R[0])
                for dx in range(3):
                    for dy in range(2): put(ex + dx, ey + dy, iris)
                if carn: put(ex + 1, ey, (10, 8, 8)); put(ex + 1, ey + 1, (10, 8, 8))
                else: put(ex + 1, ey + 1, (12, 10, 10)); put(ex, ey, (255, 255, 255))
        if kind == "snout":
            nx0, ny0, nw, nh = F["north"]
            for nxp in (nx0 + 1, nx0 + max(1, nw - 2)): put(nxp, ny0 + max(0, int(nh * 0.3)), R[0])       # fosas nasales
            for side in ("west", "east"):
                sx0, sy0, sw, sh = F[side]
                for xx in range(sw):
                    put(sx0 + xx, sy0 + sh - 1, MOUTH)
                    if carn and sh >= 3 and xx % 2 == 0: put(sx0 + xx, sy0 + sh - 2, TOOTH)
            for xx in range(nw):
                put(nx0 + xx, ny0 + nh - 1, MOUTH)
                if carn and nh >= 3 and xx % 2 == 0: put(nx0 + xx, ny0 + nh - 2, TOOTH)
        if kind == "jaw":
            for side in ("west", "east"):
                sx0, sy0, sw, sh = F[side]
                for xx in range(sw):
                    put(sx0 + xx, sy0, MOUTH)
                    if carn and sh >= 3 and xx % 2 == 1 and xx > 1: put(sx0 + xx, sy0 + 1, TOOTH)
            nx0, ny0, nw, nh = F["north"]
            for xx in range(nw): put(nx0 + xx, ny0, MOUTH)
    img.save(f"{A}/entity/{sid}_{vidx}.png")

# ----------------------------------------------------------------- items 16x16 (plantillas ASCII)
def ascii_icon(path, tpl, pal):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); px = img.load()
    lines = (tpl.strip("\n").split("\n") + ["." * 16] * 16)[:16]
    for y, line in enumerate(lines):
        for x, ch in enumerate(line.ljust(16, ".")[:16]):
            if ch in pal: px[x, y] = pal[ch] + (255,)
    img.save(path)

SCALE = {"o": (58, 22, 18), "d": (112, 46, 36), "m": (162, 76, 58), "l": (206, 116, 88), "h": (238, 166, 128), "s": (143, 98, 52), "S": (92, 60, 30)}
MOTHER = {"o": (16, 10, 26), "d": (40, 28, 62), "m": (74, 52, 114), "l": (132, 82, 204), "h": (210, 154, 255), "s": (143, 98, 52), "S": (92, 60, 30)}
T = {}
T["helmet"] = """
................
................
....oooooooo....
...ommmmmmmmo...
..ommllllllmmo..
..omllhhhhllmo..
..ommllllllmmo..
..ommmmmmmmmmo..
..omm.oooo.mmo..
..omo......omo..
..ooo......ooo..
"""
T["chestplate"] = """
................
..oooo....oooo..
.ommmmoooommmmo.
.ommllmmmmllmmo.
.ommllmmmmllmmo.
.oommmmmmmmmmoo.
..ommmllllmmmo..
..ommllhhllmmo..
..ommmllllmmmo..
..ommmmmmmmmmo..
..ommmmmmmmmmo..
..ooommmmmmooo..
.....oooooo.....
"""
T["leggings"] = """
................
...oooooooooo...
..odmmmmmmmmdo..
..odmmllllmmmdo.
..odmmmmmmmmmdo.
..odmmdooodmmdo.
..odmmdo..odmdo.
..odmmdo..odmdo.
..odmldo..odmdo.
..odmmdo..odmdo.
..odmmdo..odmdo.
..oddddo..oddddo
..ooooo....ooooo
"""
T["boots"] = """
................
................
................
..oooo....oooo..
..odmo....odmo..
..odmo....odmo..
..odmo....odmo..
..odmlo...odmlo.
.oodmmo..oodmmo.
.odmmmoo.odmmmoo
.oddddoo.odddddo
.oooooo..oooooo.
"""
T["sword"] = """
..............oo
.............ohl
............ohlo
...........ohlmo
..........ohlmdo
.........ohlmdo.
........ohlmdo..
.o.....ohlmdo...
.oso..ohlmdo....
..osoohlmdo.....
...osoodo.......
....osSo........
...osSSo........
..osSSo.........
.osSSo..........
.oooo...........
"""
T["pickaxe"] = """
................
...oooooo.......
..ollhhmmdoo....
.olhmoooommdo...
.olmdo...osmdo..
.omdo...osSo.dmo
.odo...osSo..odo
.oo...osSo....oo
.....osSo.......
....osSo........
...osSo.........
..osSo..........
.osSo...........
.oSo............
.oo.............
"""
T["axe"] = """
................
.....ooooo......
....ollhhmo.....
...olhmmmmdo....
...olmmmmmdo....
...omdoomddo....
....oo.osdo.....
......osSo......
.....osSo.......
....osSo........
...osSo.........
..osSo..........
.osSo...........
.oSo............
.oo.............
"""
T["shovel"] = """
..........ooo...
.........olhmo..
........olhmmdo.
........omllmdo.
.........omddo..
........osdoo...
.......osSo.....
......osSo......
.....osSo.......
....osSo........
...osSo.........
..osSo..........
.osSo...........
.oSo............
.oo.............
"""
T["hoe"] = """
................
......ooooo.....
....oolhhmmo....
...olhmmmmddo...
...omdoooodo....
...odo.osdo.....
...oo.osSo......
.....osSo.......
....osSo........
...osSo.........
..osSo..........
.osSo...........
.oSo............
.oo.............
"""
T["scale"] = """
................
.......oo.......
.....oolhoo.....
....olhlmmdo....
...olhlmmmmdo...
...olmmmmmmdo...
..olmmmmmmmmdo..
..omllmmmmmmdo..
..ommmmmmmmmdo..
..omdmmmmmmddo..
...omdmmmmmdo...
...oodmmmmddo...
....oodddddo....
......oooo......
"""
T["fragment"] = """
................
.......o........
......olo.......
.....olhlo......
.....olmmo......
....olmmmdo.....
....olmmmdo.....
...olmmmmmdo....
...olmmmmmmdo...
...omllmmmmdo...
...ommmmmmddo...
....omdmmddo....
.....oodddoo....
.......ooo......
"""
T["ingot"] = """
................
................
................
................
....oooooooooo..
...olllhhhhmmdo.
..olmmmmmmmmmmdo
..olmmmmmmmmmdo.
..omdddddddddo..
...ooooooooooo..
"""
T["meat"] = """
................
................
....oooooooo....
..oopppppppooo..
.oppmmmmmmmmppo.
.opmmmllllmmmpo.
.opmmlhhhllmmpo.
.opmmlhhhllmmpo.
.opmmmllllmmmdo.
.oppmmmmmmmmddo.
..ooddmmmmmdooo.
....oooooooo....
"""
T["amber"] = """
................
.......oo.......
.....oolloo.....
....olhllmdo....
...olhllmmmdo...
..olhlmmkmmmdo..
..olmmmkkkmmdo..
..olmmmkkmmmdo..
..olmmkmkmmmdo..
..omllmmmmmmdo..
...omdmmmmmddo..
....oddmmmddo...
.....oodddoo....
.......ooo......
"""
RAW = {"o": (84, 22, 28), "d": (148, 38, 44), "m": (196, 64, 70), "l": (226, 104, 108), "h": (246, 154, 154), "p": (244, 206, 204)}
COOKED = {"o": (58, 32, 18), "d": (112, 62, 30), "m": (152, 92, 46), "l": (186, 126, 72), "h": (216, 162, 98), "p": (214, 176, 118)}
AMBER = {"o": (110, 55, 10), "d": (180, 95, 15), "m": (230, 150, 30), "l": (250, 195, 70), "h": (255, 235, 150), "k": (60, 35, 10)}

def items():
    I = f"{A}/item"
    for n in ("helmet", "chestplate", "leggings", "boots"):
        ascii_icon(f"{I}/scale_{n}.png", T[n], SCALE); ascii_icon(f"{I}/mother_rock_{n}.png", T[n], MOTHER)
    for n in ("sword", "pickaxe", "axe", "shovel", "hoe"):
        ascii_icon(f"{I}/mother_rock_{n}.png", T[n], MOTHER)
    ascii_icon(f"{I}/dino_scale.png", T["scale"], SCALE)
    ascii_icon(f"{I}/mother_rock_fragment.png", T["fragment"], MOTHER)
    ascii_icon(f"{I}/mother_rock_ingot.png", T["ingot"], MOTHER)
    ascii_icon(f"{I}/dino_meat.png", T["meat"], RAW)
    ascii_icon(f"{I}/cooked_dino_meat.png", T["meat"], COOKED)
    im = Image.open(f"{I}/cooked_dino_meat.png"); pxm = im.load()
    for y in range(16):
        for x in range(16):
            if pxm[x, y][3] and (x + y) % 5 == 0 and pxm[x, y][:3] not in ((58, 32, 18),) and 4 <= y <= 10: pxm[x, y] = (96, 50, 24, 255)
    im.save(f"{I}/cooked_dino_meat.png")
    ascii_icon(f"{I}/jurassic_amber.png", T["amber"], AMBER)

# ----------------------------------------------------------------- huevos: item con luz y manchas, bloque con cascara moteada
def egg_item(row):
    base, acc = rgb(row["color"]), rgb(row["accent"])
    shell = mix(base, (240, 232, 210), 0.72)
    seed = sum(map(ord, row["id"]))
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); px = img.load()
    cx, cy, rx, ry = 7.5, 8.6, 5.0, 6.9
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / rx, (y - cy) / ry
            if dy < 0: dx *= 1.0 + dy * 0.28   # mas estrecho arriba (forma de huevo)
            r = dx * dx + dy * dy
            if r <= 1.0:
                light = 1.12 - 0.5 * ((dx * 0.7 + dy * 0.8 + 1) / 2)
                c = mul(shell, light)
                n = hnoise(x, y, seed)
                if n > 0.78: c = mix(c, acc, 0.78)
                elif n > 0.68: c = mix(c, acc, 0.35)
                if r > 0.78: c = mul(c, 0.82)
                px[x, y] = c + (255,)
    for y in range(16):          # contorno
        for x in range(16):
            if px[x, y][3] == 0 and any(0 <= x + a < 16 and 0 <= y + b < 16 and px[x + a, y + b][3] for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                px[x, y] = mul(mix(shell, acc, 0.5), 0.4) + (255,)
    px[5, 4] = (255, 255, 255, 255); px[5, 5] = (250, 250, 245, 255)   # brillo
    img.save(f"{A}/item/egg_{row['id']}.png")
    tile = Image.new("RGBA", (16, 16)); tp = tile.load()
    for y in range(16):
        for x in range(16):
            c = mul(shell, 0.93 + hnoise(x, y, seed + 1) * 0.12)
            n = hnoise(x // 2, y // 2, seed + 2)
            if n > 0.66: c = mix(c, acc, 0.7)
            elif n > 0.58: c = mix(c, acc, 0.3)
            if (x + y) % 7 == 0: c = mul(c, 0.94)
            tp[x, y] = c + (255,)
    tile.save(f"{A}/block/egg_{row['id']}.png")

def spawn_egg(row):
    """Huevo generador: huevo del color de la especie con manchas del color de acento (distinto del huevo fertil, que es de cascara clara)."""
    base, acc = rgb(row["color"]), rgb(row["accent"])
    seed = sum(map(ord, row["id"])) * 7
    base = hsv_shift(base, 0, 1.15, 1.1)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); px = img.load()
    cx, cy, rx, ry = 7.5, 8.4, 5.4, 7.0
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / rx, (y - cy) / ry
            if dy < 0: dx *= 1.0 + dy * 0.22
            r = dx * dx + dy * dy
            if r <= 1.0:
                light = 1.18 - 0.62 * ((dx * 0.75 + dy * 0.7 + 1.4) / 2.8)
                c = mul(base, light)
                n = hnoise(x // 2, y // 2, seed)
                if n > 0.70: c = mul(acc, 0.9 + 0.25 * (1.0 - r))
                elif n > 0.62: c = mix(c, acc, 0.4)
                if r > 0.8: c = mul(c, 0.8)
                px[x, y] = tuple(c) + (255,)
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0 and any(0 <= x + a < 16 and 0 <= y + b < 16 and px[x + a, y + b][3] for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                px[x, y] = tuple(mul(base, 0.35)) + (255,)
    px[5, 4] = (255, 255, 255, 255); px[6, 3] = (255, 255, 255, 230); px[5, 5] = (255, 255, 255, 200)
    img.save(f"{A}/item/{row['id']}_spawn_egg.png")

# ----------------------------------------------------------------- mena de roca madre
def ore():
    img = Image.new("RGBA", (16, 16)); px = img.load(); r = random.Random(11)
    for y in range(16):
        for x in range(16):
            n = hnoise(x, y, 5)
            g = 112 + int((n - 0.5) * 34) + (6 if (x // 4 + y // 4) % 2 else 0)
            px[x, y] = (g, g, g + 3, 255)
    for _ in range(5):
        cx, cy = r.randint(2, 13), r.randint(2, 13)
        for dx, dy in ((0, 0), (1, 0), (0, 1), (-1, 0), (0, -1), (1, 1)):
            x, y = cx + dx, cy + dy
            if 0 <= x < 16 and 0 <= y < 16: px[x, y] = (46, 30, 78, 255)
        px[cx, cy] = (150, 80, 230, 255)
        if cx + 1 < 16: px[cx + 1, cy] = (110, 60, 190, 255)
        if cy - 1 >= 0: px[cx, cy - 1] = (210, 150, 255, 255)
    img.save(f"{A}/block/mother_rock_ore.png")

# ----------------------------------------------------------------- armadura puesta (64x32)
NP = {"dk": (30, 20, 46), "d": (46, 30, 70), "m": (66, 42, 100), "l": (92, 60, 134), "h": (132, 94, 182), "g": (176, 130, 230)}
def rect(px, x0, y0, w, h):
    return [(x, y) for y in range(y0, y0 + h) for x in range(x0, x0 + w)]
def plate(px, x0, y0, w, h, rivets=True):
    """Placa biselada estilo netherita: degradado metalico, borde claro arriba/izquierda y oscuro abajo/derecha."""
    for y in range(h):
        for x in range(w):
            t = y / max(h - 1, 1)
            c = mix(NP["l"], NP["d"], t * 0.85)
            c = mul(c, 0.96 + hnoise(x0 + x, y0 + y, 3) * 0.08)
            if y == 0 or x == 0: c = NP["h"]
            if y == h - 1 or x == w - 1: c = NP["dk"]
            if rivets and w >= 4 and h >= 4 and (x, y) in ((1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)): c = NP["g"]
            px[x0 + x, y0 + y] = tuple(c) + (255,)
def box_faces(px, u, v, w, h, d, **kw):
    for (fx, fy, fw, fh) in ((u + d, v, w, d), (u + d + w, v, w, d), (u, v + d, d, h), (u + d, v + d, w, h), (u + d + w, v + d, d, h), (u + 2 * d + w, v + d, w, h)):
        plate(px, fx, fy, fw, fh, **kw)

def netherite_style(layer2):
    img = Image.new("RGBA", (64, 32), (0, 0, 0, 0)); px = img.load()
    box_faces(px, 0, 0, 8, 8, 8)       # cabeza
    box_faces(px, 16, 16, 8, 12, 4)    # torso
    box_faces(px, 40, 16, 4, 12, 4)    # brazo
    box_faces(px, 0, 16, 4, 12, 4)     # pierna
    if not layer2:
        for x in range(8, 16): px[x, 14 - 0] = tuple(NP["dk"]) + (255,)
        for x in range(10, 14): px[x, 11] = (8, 6, 12, 255)                            # visor del casco (cara frontal)
        for y in range(20, 32): px[23, y] = tuple(NP["h"]) + (255,); px[24, y] = tuple(NP["dk"]) + (255,)  # cresta del peto
        for x in range(4, 8): px[x, 24] = tuple(NP["g"]) + (255,)                        # puño de las botas
        for x in range(0, 4): px[x, 24] = tuple(NP["g"]) + (255,)
        for x in range(8, 12): px[x, 24] = tuple(NP["g"]) + (255,)
        for x in range(12, 16): px[x, 24] = tuple(NP["g"]) + (255,)
    else:
        for x in range(20, 28): px[x, 20] = tuple(NP["g"]) + (255,)                      # cinturon
        for x in range(32, 40): px[x, 20] = tuple(NP["g"]) + (255,)
    return img

def armor_layers():
    # armadura de escamas (ladrillo de escamas con brillo)
    img = Image.new("RGBA", (64, 32)); px = img.load()
    for y in range(32):
        for x in range(64):
            n = hnoise(x, y, 17); row_i = y // 3
            edge = (x + row_i * 2) % 4 == 0 or y % 3 == 0
            c = SCALE["d"] if edge else SCALE["m"]
            if not edge and (x + row_i * 2) % 4 == 1 and y % 3 == 1: c = SCALE["l"]
            px[x, y] = mul(c, 0.94 + n * 0.12) + (255,)
    for sub in ("humanoid", "humanoid_leggings"): img.save(f"{A}/entity/equipment/{sub}/scale.png")
    # armadura de roca madre: recolor morado de la netherita
    netherite_style(False).save(f"{A}/entity/equipment/humanoid/mother_rock.png")
    netherite_style(True).save(f"{A}/entity/equipment/humanoid_leggings/mother_rock.png")

rows = list(csv.DictReader(open(f"{RES}/data/prehistoric/species.csv", encoding="utf-8")))
import glob
for old in glob.glob(f"{A}/entity/*.png"):
    if "equipment" not in old: os.remove(old)
for row in rows:
    for vidx in range(6): paint_species(row, vidx)
    egg_item(row); spawn_egg(row)
items(); ore(); armor_layers()
print("OK texturas v2:", len(rows), "especies")
