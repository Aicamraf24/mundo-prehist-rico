# Mundo Prehistórico (Fabric, Minecraft Java 26.1.2)

## Compilar
1. JDK 25 y Gradle 9.3+ (`gradle wrapper --gradle-version 9.4.1` para generar el wrapper).
2. Edita `gradle.properties` y pon la versión de Fabric API para 26.1.2 (https://fabricmc.net/develop).
3. `./gradlew build` → el .jar queda en `build/libs/`. `./gradlew runClient` para probarlo.

Las texturas/modelos/idiomas se regeneran con `python3 tools/generate_assets.py` (necesita Pillow).
La tabla de especies (`src/main/resources/data/prehistoric/species.csv`) es la única fuente de datos:
tamaño, vida, velocidad, velocidad de monta, si es montable, tamaño de manada, hábitat, colores…

## Qué hace (sección 14)
- **Manadas 2–5**: cada especie con su rango (`pack_min/pack_max`) y su hábitat (tags de bioma `data/prehistoric/tags/worldgen/biome/habitat/*.json`). Los miembros se mantienen cerca (FollowPackGoal) y reaccionan si atacan a uno: los combativos atacan, los demás huyen.
- **Reproducción natural**: cada 60 s, el "líder" de la manada tira un 10 %. Dos adultos de la manada hacen la animación (corazones, cabeceo, 4 s) y uno deja un huevo. Cooldown de 10 min por manada y tope de 8 ejemplares de la especie en 48 bloques.
- **Huevos**: un bloque + item por especie, textura propia. Clic derecho con la mano → lo recoges, conserva especie y progreso. Al colocarlo, quien lo coloca será el dueño.
- **Incubación/domesticación**: sobre un bloque de magma avanza 5 min (6000 ticks). Al eclosionar nace un bebé domesticado del jugador que lo colocó (propietario guardado en el NBT de la entidad, vía TamableAnimal).
- **Crianza manual**: dos adultos de la misma especie alimentados con chuleta de cerdo ponen huevo.
- **Crecimiento**: la chuleta (cruda o cocinada) a un bebé reduce su tiempo restante (10 % del restante por chuleta, nunca instantáneo). La escala y la hitbox crecen de forma continua de 35 % a 100 %.
- **Monturas**: se usa la **silla de montar vanilla**. Clic derecho con la silla sobre un adulto domesticado y montable → la lleva puesta (textura de silla incluida en cada textura de especie, región (0,72), también se ve en el modelo). Clic derecho con la mano vacía → montas. Velocidad propia por especie. Voladores vuelan y acuáticos nadan según hacia dónde mires. Al morir suelta la silla.
- **Sentarse**: clic derecho con la mano vacía (o agachado si lleva silla). Animación por plan corporal (teropodo grande, teropodo pequeño que se acurruca, cuadrúpedo, saurópodo, volador con alas plegadas, acuático flotando). **Son 5 familias + variante pequeña, no 30 animaciones únicas.**
- Carne de dinosaurio cruda/cocinada y loot de los 30.

## Añadido en la segunda entrega
- **Dimensión `prehistoric:jurassic`**: usa el tipo y el ruido del Overworld con 6 biomas propios (Jungla Jurásica, Bosque Fósil, Volcán, Pantano Jurásico, Llanuras Prehistóricas, Mar Prehistórico). Los dinosaurios ahora solo aparecen ahí (tags `habitat/*.json`).
- **Entrada**: craftea el **Ámbar Jurásico** (2 escamas + lingote de oro + polvo de piedra luminosa, sin forma). Clic derecho = viajar a la dimensión; dentro, clic derecho = volver al Overworld. También sirve `/execute in prehistoric:jurassic run tp @s ~ ~ ~`.
- **Volcán**: feature propia (`VolcanoFeature`) en el bioma Volcán: cono de basalto con cráter de lava.
- **Escamas y armadura**: los dinosaurios sueltan Escama de dinosaurio; casco, peto, pantalones y botas de escamas (recetas tipo cuero, protección entre cuero y hierro, se repara con escamas).

## Roca madre (tercera entrega)
- **Mena de roca madre**: en la dimensión, mismas vetas, tamaño y altura que el diamante (7 vetas de tamaño 4 por chunk, entre las alturas del diamante). Se pica con pico de diamante o mejor; suelta Fragmento de roca madre (Fortuna funciona, Toque de seda da el bloque). 2 fragmentos = 1 Lingote.
- **Mejora en la mesa de herrería**: plantilla de mejora de netherita + pieza de netherita + lingote de roca madre = pieza de roca madre (conserva encantamientos). Cubre casco, peto, pantalones, botas, espada, pico, hacha, pala y azada.
- **Estadísticas = netherita x1.5**: durabilidad armadura 56 (37), herramientas 3046 (2031); protección casco 5, peto 12, pantalones 9, botas 5 (3/8/6/3); dureza 4.5 (3); resistencia al empuje 0.15 (0.1); velocidad de minería 13.5 (9); bonificación de daño 6 (4). Resiste fuego y lava. El conjunto completo supera el tope de 30 de armadura de Minecraft.
- **Spawn**: todas las especies con peso 10, igual que el cerdo en llanura (que además sale en grupos).

## Cuarta entrega: texturas, agua y spawn eggs
- **Texturas rehechas** (`tools/textures_v2.py`): dinosaurios pintados cara por cara (dorso oscuro, vientre claro, escamas, patrones por especie: rayas, manchas, bandas, nudos; ojos, fosas, boca y dientes en carnívoros, garras, alas con venas, cresta y cuernos), silla de cuero con cosidos y hebilla, huevos con luz y manchas, items con sombreado, armaduras puestas. El atlas del modelo pasa a 256x256 sin solapes.
- **Agua invisible arreglada**: el `water_color` de los biomas iba sin canal alfa (transparente). Ahora es ARGB opaco y cada bioma tiene su tono de agua.
- **Spawn eggs**: uno por dinosaurio (30), con los colores de la especie, en la pestaña creativa junto a los huevos fértiles.
- `tools/run_all.sh` regenera todo en orden.

## Quinta entrega: anatomía por especie y depredadores
- **Un modelo propio por especie** (`tools/build_models.py` → `data/prehistoric/models/<id>.json`, lo leen Java y el pintor de texturas): cráneo + hocico alargado + mandíbula articulada, cuello y cola en tramos, patas de 3 tramos (muslo, pierna, pie plano con garras), brazos, y rasgos propios: gola y cuernos del Triceratops, vela del Spinosaurus, placas y púas del Stegosaurus, maza del Ankylosaurus, cresta del Parasaurolophus, cuernos del Carnotaurus, cúpula del Paquicefalosaurio, garras del Therizinosaurus, alas con membrana, aletas, etc. Proporciones basadas en la paleontología que usan las películas de Jurassic World; no son copias de sus modelos.
- **Hitboxes** ajustadas a escalas cinematográficas (T-rex 3.6 x 5.2, Brachiosaurus 3.6 x 9.5...). Un hitbox de Minecraft es un cuadrado, así que el cuerpo largo sobresale por delante y por detrás.
- **Depredadores**: los carnívoros cazan herbivoros salvajes de tamaño parecido (no a domesticados ni a otros carnívoros); los herbivoros indefensos huyen de ellos y los combativos se defienden. Los carnívoros también atacan a jugadores.
- Mandíbula que se abre al atacar, patas que levantan y mantienen el pie plano, cola y cuello en oleaje, asiento calculado de la anatomía.

## Sexta entrega
- **Carne de dinosaurio**: arreglada (faltaban las definiciones de modelo del ítem, por eso se veía rota) y redibujada.
- **Spawn eggs** con textura propia por especie según su color (distintos del huevo fértil). **6 recolores por dinosaurio** (original, cálido, frío, melánico, arenoso y raro) con probabilidades 40/20/15/11/9/5 %; se guarda en el NBT.
- **Tamaños**: T-rex x2 (7.2 x 10.4), Protoceratops x3 (3 x 3), Quetzalcoatlus 6 bloques de alto (3 x Steve).
- **Therizinosaurus** con 3 garras por mano (T-rex 2).
- **Fauna marina**: arreglado el spawn de Mosasaurus y Plesiosaurus (la clase base rechaza cualquier hitbox con líquido; ahora las criaturas acuáticas lo permiten y usan la categoría de agua). Nuevo **Ictiosaurio** con las mismas reglas (manada, huevo, domesticable, montable).
- **Vegetación marina** en el Mar Prehistórico (hierba marina, algas, pepinos de mar, vegetación cálida).
- **Volcán**: suelo rojizo volcánico (nylium carmesí, netherrack, tierra gruesa, basalto) y árboles carmesí del Nether.
- **Ámbar Jurásico** ahora se craftea con 2 cuero + lingote de oro + polvo de piedra luminosa.
- **Armadura de roca madre** rediseñada como recolor morado de la netherita y **compatible con las plantillas de ornamento** (también la de escamas).
- **Árbol prehistórico** (aparece con 25 % por chunk en cualquier bioma salvo Nether/End): Tronco prehistórico, madera, sin corteza, tablones (tono de roble más gris), escaleras, losa, valla, Hoja de árbol prehistórico y Brote de árbol prehistórico, con recetas, botín y tags de Minecraft. Sin puertas, trampillas, botones, placas, carteles ni botes.

## Límites actuales
- Los modelos son 5 formas escaladas, no 30 modelos distintos.
- El terreno es el del Overworld con otros biomas (sin árboles gigantes propios, ríos ni lagos específicos). Los árboles son los vanilla de jungla/sabana/pantano/llanura.
- No pude compilar ni cargar un mundo: los formatos JSON de bioma/dimensión de 26.1.2 los saqué de la wiki. Si Minecraft se queja al crear el mundo, copia el error del log.
