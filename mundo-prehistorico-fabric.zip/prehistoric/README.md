# Mundo Prehistórico (Fabric, Minecraft Java 26.1.2)

## Compilar
1. JDK 25 y Gradle 9.3+ (`gradle wrapper --gradle-version 9.4.1` para generar el wrapper).
2. Edita `gradle.properties` y pon la versión de Fabric API para 26.1.2 (https://fabricmc.net/develop).
3. `./gradlew build` → el .jar queda en `build/libs/`. `./gradlew runClient` para probarlo.

Las texturas/modelos/idiomas se regeneran con `python3 tools/generate_assets.py` (necesita Pillow).
La tabla de especies (`src/main/resources/data/prehistoric/species.csv`) es la única fuente de datos:
tamaño, vida, velocidad, velocidad de monta, si es montable, tamaño de manada, hábitat, colores…

## Qué hace (sección 14)
- **Manadas 2–5**: cada especie con su rango (`pack_min/pack_max`) y su hábitat (tags de bioma `data/prehistoric/tags/worldgen/biome/habitat/*.json`). Los miembros se mantienen cerca (FollowPackGoal) y reaccionan si atacan a uno: los combativos atacan, los demás huyen.
- **Reproducción natural**: cada 60 s, el "líder" de la manada tira un 10 %. Dos adultos de la manada hacen la animación (corazones, cabeceo, 4 s) y uno deja un huevo. Cooldown de 10 min por manada y tope de 8 ejemplares de la especie en 48 bloques.
- **Huevos**: un bloque + item por especie, textura propia. Clic derecho con la mano → lo recoges, conserva especie y progreso. Al colocarlo, quien lo coloca será el dueño.
- **Incubación/domesticación**: sobre un bloque de magma avanza 5 min (6000 ticks). Al eclosionar nace un bebé domesticado del jugador que lo colocó (propietario guardado en el NBT de la entidad, vía TamableAnimal).
- **Crianza manual**: dos adultos de la misma especie alimentados con chuleta de cerdo ponen huevo.
- **Crecimiento**: la chuleta (cruda o cocinada) a un bebé reduce su tiempo restante (10 % del restante por chuleta, nunca instantáneo). La escala y la hitbox crecen de forma continua de 35 % a 100 %.
- **Monturas**: se usa la **silla de montar vanilla**. Clic derecho con la silla sobre un adulto domesticado y montable → la lleva puesta (textura de silla incluida en cada textura de especie, región (0,72), también se ve en el modelo). Clic derecho con la mano vacía → montas. Velocidad propia por especie. Voladores vuelan y acuáticos nadan según hacia dónde mires. Al morir suelta la silla.
- **Sentarse**: clic derecho con la mano vacía (o agachado si lleva silla). Animación por plan corporal (teropodo grande, teropodo pequeño que se acurruca, cuadrúpedo, saurópodo, volador con alas plegadas, acuático flotando). **Son 5 familias + variante pequeña, no 30 animaciones únicas.**
- Carne de dinosaurio cruda/cocinada y loot de los 30.

## Añadido en la segunda entrega
- **Dimensión `prehistoric:jurassic`**: usa el tipo y el ruido del Overworld con 6 biomas propios (Jungla Jurásica, Bosque Fósil, Volcán, Pantano Jurásico, Llanuras Prehistóricas, Mar Prehistórico). Los dinosaurios ahora solo aparecen ahí (tags `habitat/*.json`).
- **Entrada**: craftea el **Ámbar Jurásico** (2 escamas + lingote de oro + polvo de piedra luminosa, sin forma). Clic derecho = viajar a la dimensión; dentro, clic derecho = volver al Overworld. También sirve `/execute in prehistoric:jurassic run tp @s ~ ~ ~`.
- **Volcán**: feature propia (`VolcanoFeature`) en el bioma Volcán: cono de basalto con cráter de lava.
- **Escamas y armadura**: los dinosaurios sueltan Escama de dinosaurio; casco, peto, pantalones y botas de escamas (recetas tipo cuero, protección entre cuero y hierro, se repara con escamas).

## Roca madre (tercera entrega)
- **Mena de roca madre**: en la dimensión, mismas vetas, tamaño y altura que el diamante (7 vetas de tamaño 4 por chunk, entre las alturas del diamante). Se pica con pico de diamante o mejor; suelta Fragmento de roca madre (Fortuna funciona, Toque de seda da el bloque). 2 fragmentos = 1 Lingote.
- **Mejora en la mesa de herrería**: plantilla de mejora de netherita + pieza de netherita + lingote de roca madre = pieza de roca madre (conserva encantamientos). Cubre casco, peto, pantalones, botas, espada, pico, hacha, pala y azada.
- **Estadísticas = netherita x1.5**: durabilidad armadura 56 (37), herramientas 3046 (2031); protección casco 5, peto 12, pantalones 9, botas 5 (3/8/6/3); dureza 4.5 (3); resistencia al empuje 0.15 (0.1); velocidad de minería 13.5 (9); bonificación de daño 6 (4). Resiste fuego y lava. El conjunto completo supera el tope de 30 de armadura de Minecraft.
- **Spawn**: todas las especies con peso 10, igual que el cerdo en llanura (que además sale en grupos).

## Límites actuales
- Los modelos son 5 formas escaladas, no 30 modelos distintos.
- El terreno es el del Overworld con otros biomas (sin árboles gigantes propios, ríos ni lagos específicos). Los árboles son los vanilla de jungla/sabana/pantano/llanura.
- No pude compilar ni cargar un mundo: los formatos JSON de bioma/dimensión de 26.1.2 los saqué de la wiki. Si Minecraft se queja al crear el mundo, copia el error del log.
