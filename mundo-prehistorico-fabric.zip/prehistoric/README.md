# Mundo Prehistórico (Fabric, Minecraft Java 26.1.2)

## Compilar
1. JDK 25 y Gradle 9.3+ (`gradle wrapper --gradle-version 9.4.1` para generar el wrapper).
2. Edita `gradle.properties` y pon la versión de Fabric API para 26.1.2 (https://fabricmc.net/develop).
3. `./gradlew build` → el .jar queda en `build/libs/`. `./gradlew runClient` para probarlo.

Las texturas/modelos/idiomas se regeneran con `python3 tools/generate_assets.py` (necesita Pillow).
La tabla de especies (`src/main/resources/data/prehistoric/species.csv`) es la única fuente de datos:
tamaño, vida, velocidad, velocidad de monta, si es montable, tamaño de manada, hábitat, colores…

## Qué hace (sección 14)
- **Manadas 2–5**: cada especie con su rango (`pack_min/pack_max`) y su hábitat (tags de bioma `data/prehistoric/tags/worldgen/biome/habitat/*.json`). Los miembros se mantienen cerca (FollowPackGoal) y reaccionan si atacan a uno: los combativos atacan, los demás huyen.
- **Reproducción natural**: cada 60 s, el "líder" de la manada tira un 10 %. Dos adultos de la manada hacen la animación (corazones, cabeceo, 4 s) y uno deja un huevo. Cooldown de 10 min por manada y tope de 8 ejemplares de la especie en 48 bloques.
- **Huevos**: un bloque + item por especie, textura propia. Clic derecho con la mano → lo recoges, conserva especie y progreso. Al colocarlo, quien lo coloca será el dueño.
- **Incubación/domesticación**: sobre un bloque de magma avanza 5 min (6000 ticks). Al eclosionar nace un bebé domesticado del jugador que lo colocó (propietario guardado en el NBT de la entidad, vía TamableAnimal).
- **Crianza manual**: dos adultos de la misma especie alimentados con chuleta de cerdo ponen huevo.
- **Crecimiento**: la chuleta (cruda o cocinada) a un bebé reduce su tiempo restante (10 % del restante por chuleta, nunca instantáneo). La escala y la hitbox crecen de forma continua de 35 % a 100 %.
- **Monturas**: se usa la **silla de montar vanilla**. Clic derecho con la silla sobre un adulto domesticado y montable → la lleva puesta (textura de silla incluida en cada textura de especie, región (0,72), también se ve en el modelo). Clic derecho con la mano vacía → montas. Velocidad propia por especie. Voladores vuelan y acuáticos nadan según hacia dónde mires. Al morir suelta la silla.
- **Sentarse**: clic derecho con la mano vacía (o agachado si lleva silla). Animación por plan corporal (teropodo grande, teropodo pequeño que se acurruca, cuadrúpedo, saurópodo, volador con alas plegadas, acuático flotando). **Son 5 familias + variante pequeña, no 30 animaciones únicas.**
- Carne de dinosaurio cruda/cocinada y loot de los 30.

## Límites actuales (no hechos)
- No hay dimensión propia ni biomas custom, volcanes, ni armaduras de escamas. Por ahora aparecen en biomas vanilla; cuando existan tus biomas, añádelos a los tags `habitat/*.json`.
- Los modelos son procedurales por plan corporal (5 formas escaladas), no 30 modelos distintos; la diferencia entre especies es tamaño, textura y adornos (cresta/cuernos).
- Los nombres de API de 26.1.2 los escribí de memoria + documentación de Fabric: **no pude compilar aquí** (sin red). Si Gradle da errores, pásamelos y los corrijo. Puntos más probables: `FabricBlockEntityTypeBuilder`, `ModelLayerRegistry`, `EntityReference.of`, `MobRenderer.scale`, `getAgeScale`.
